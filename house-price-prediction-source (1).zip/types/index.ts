export type UserRole = 'SUPER_ADMIN' | 'ADMIN' | 'ANALYST';

export interface AuthUser {
  id: number;
  email: string;
  name: string;
  role: UserRole;
  phone?: string | null;
}

export type PropertyType =
  | 'Apartment'
  | 'Villa/House'
  | 'Plot/Land'
  | 'Commercial'
  | 'Penthouse';

export type ListingType = 'SALE' | 'RENT';

export type PropertyStatus = 'ACTIVE' | 'PENDING' | 'SOLD' | 'INACTIVE';

export type LeadStatus =
  | 'NEW'
  | 'CONTACTED'
  | 'QUALIFIED'
  | 'SITE_VISIT'
  | 'NEGOTIATION'
  | 'CONVERTED'
  | 'CLOSED';

export interface LocationData {
  id: number;
  city: string;
  area: string;
  locality: string;
  pincode?: string | null;
  state: string;
  avgPricePerSqFt: number;
  marketTier: string;
  latitude?: number | null;
  longitude?: number | null;
  isActive: boolean;
}

export interface PropertyData {
  id: number;
  propertyCode: string;
  propertyType: PropertyType;
  listingType: ListingType;
  title: string;
  description: string;
  locationId: number;
  location?: LocationData;
  address: string;
  areaSqFt: number;
  bedrooms: number;
  bathrooms: number;
  balconies: number;
  floor: number;
  totalFloors: number;
  propertyAge: number;
  parking: string;
  furnishing: string;
  constructionStatus: string;
  amenities: string[];
  expectedPrice: number;
  status: PropertyStatus;
  isFeatured: boolean;
  createdAt: string | Date;
  updatedAt: string | Date;
  images?: { id: number; imageUrl: string; isPrimary: boolean; caption?: string | null }[];
}

export interface ValuationInput {
  propertyType: PropertyType;
  city: string;
  locality: string;
  pincode?: string;
  areaSqFt: number;
  bedrooms: number;
  bathrooms: number;
  balconies: number;
  propertyAge: number;
  floor: number;
  totalFloors: number;
  parking: string;
  furnishing: string;
  constructionStatus: string;
  amenities: string[];
  contactName: string;
  contactEmail: string;
  contactPhone: string;
}

export interface ValuationFactor {
  factor: string;
  impact: 'positive' | 'negative' | 'neutral';
  impactPercent: number;
  description: string;
}

export interface ComparableProperty {
  id: number;
  propertyCode?: string;
  propertyType: string;
  locality: string;
  areaSqFt: number;
  bedrooms: number;
  price: number;
  pricePerSqFt: number;
  date: string;
  type: 'listing' | 'transaction';
}

export interface ValuationResult {
  estimatedPrice: number;
  lowEstimate: number;
  highEstimate: number;
  pricePerSqFt: number;
  confidenceLevel: 'High' | 'Medium' | 'Moderate';
  factors: ValuationFactor[];
  comparables: ComparableProperty[];
  dataPointsUsed: number;
  modelVersion: string;
  valuationDate: string;
  requestRef: string;
  leadCode?: string;
}

import { z } from 'zod';

export const PropertySchema = z.object({
  title: z.string().min(5, 'Title must be at least 5 characters').max(150),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  propertyType: z.enum(['Apartment', 'Villa/House', 'Plot/Land', 'Commercial', 'Penthouse']),
  listingType: z.enum(['SALE', 'RENT']).default('SALE'),
  locationId: z.number().int().positive('Please select a valid location'),
  address: z.string().min(5, 'Address is required'),
  areaSqFt: z.number().positive('Area must be a positive number'),
  bedrooms: z.number().int().min(0).max(20).default(0),
  bathrooms: z.number().int().min(0).max(20).default(0),
  balconies: z.number().int().min(0).max(10).default(0),
  floor: z.number().int().min(0).max(100).default(0),
  totalFloors: z.number().int().min(1).max(100).default(1),
  propertyAge: z.number().int().min(0).max(100).default(0),
  parking: z.enum(['Yes', 'No', 'Covered', 'Open']).default('Yes'),
  furnishing: z.enum(['Unfurnished', 'Semi-Furnished', 'Fully-Furnished']).default('Semi-Furnished'),
  constructionStatus: z.enum(['Ready to Move', 'Under Construction']).default('Ready to Move'),
  amenities: z.array(z.string()).default([]),
  expectedPrice: z.number().positive('Price must be greater than 0'),
  status: z.enum(['ACTIVE', 'PENDING', 'SOLD', 'INACTIVE']).default('ACTIVE'),
  isFeatured: z.boolean().default(false),
});

export const ValuationWizardSchema = z.object({
  propertyType: z.enum(['Apartment', 'Villa/House', 'Plot/Land', 'Commercial', 'Penthouse']),
  city: z.string().min(2, 'City is required'),
  locality: z.string().min(2, 'Locality is required'),
  pincode: z.string().optional(),
  areaSqFt: z.number().min(100, 'Minimum area is 100 Sq.Ft').max(100000, 'Maximum area is 100,000 Sq.Ft'),
  bedrooms: z.number().int().min(0).max(15).default(1),
  bathrooms: z.number().int().min(0).max(15).default(1),
  balconies: z.number().int().min(0).max(10).default(0),
  propertyAge: z.number().int().min(0).max(80).default(0),
  floor: z.number().int().min(0).max(80).default(1),
  totalFloors: z.number().int().min(1).max(80).default(1),
  parking: z.enum(['Yes', 'No', 'Covered', 'Open']).default('Yes'),
  furnishing: z.enum(['Unfurnished', 'Semi-Furnished', 'Fully-Furnished']).default('Semi-Furnished'),
  constructionStatus: z.enum(['Ready to Move', 'Under Construction']).default('Ready to Move'),
  amenities: z.array(z.string()).default([]),
  contactName: z.string().min(2, 'Name is required').max(100),
  contactEmail: z.string().email('Please enter a valid email address'),
  contactPhone: z.string().min(10, 'Please enter a valid phone number (at least 10 digits)').max(15),
});

export const LeadStatusUpdateSchema = z.object({
  status: z.enum(['NEW', 'CONTACTED', 'QUALIFIED', 'SITE_VISIT', 'NEGOTIATION', 'CONVERTED', 'CLOSED']),
  notes: z.string().optional(),
  assignedToId: z.number().int().optional().nullable(),
});

export const TransactionSchema = z.object({
  propertyType: z.string().min(2),
  localityName: z.string().min(2),
  areaSqFt: z.number().positive(),
  bedrooms: z.number().int().min(0).default(0),
  bathrooms: z.number().int().min(0).default(0),
  propertyAge: z.number().int().min(0).default(0),
  floor: z.number().int().min(0).default(0),
  furnishing: z.string().default('Semi-Furnished'),
  transactionPrice: z.number().positive(),
  pricePerSqFt: z.number().positive().optional(),
  transactionDate: z.string().or(z.date()),
  source: z.string().default('Registry Office'),
});

export const LoginSchema = z.object({
  email: z.string().min(2, 'Email or username is required'),
  password: z.string().min(4, 'Password must be at least 4 characters'),
});

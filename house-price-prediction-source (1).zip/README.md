# HOUSE & LAND PRICE PREDICTION ANALYSIS

> **Production Real Estate Valuation & Predictive Analytics Platform**  
> A complete, fully functional, production-style real-estate predictive analytics platform and property database management system.

---

## 📌 Platform Overview

This enterprise-grade platform implements an end-to-end full-stack property valuation and exploratory data analysis system. It connects user interfaces with a persistent SQL relational database, an explainable hedonic pricing regression engine, live recalculating statistical dashboards, and a secured administrative control portal.

### Core Value Proposition
- **Genuine Full-Stack Architecture**: Zero fake buttons, zero hard-coded statistics, zero static charts.
- **Persistent Relational Database**: SQLite backed by Prisma ORM ensuring all properties, prediction logs, and website settings survive server restarts and reloads.
- **Explainable Valuation Engine**: Deterministic multi-attribute hedonic pricing algorithm decomposing property values into geographic baseline rates, structural depreciation, room layout utility, locality scores, and road accessibility discounts.
- **Live Dynamic Synchronization**: Admin mutations (Create, Edit, Delete) immediately trigger database updates, which recalculate KPI counters and chart distributions in real time.
- **Multi-Layered Security**: Protected administrative portal and API routes guarded with JWT authorization and HTTP-only session cookies.

---

## 🛠️ Technology Stack

| Layer | Technology | Details |
| :--- | :--- | :--- |
| **Frontend Framework** | **Next.js 14 (App Router)** | Server Components + Client Interactivity |
| **Language & Typing** | **TypeScript 5** | Strict end-to-end type safety |
| **Styling & UI** | **Tailwind CSS & Lucide Icons** | Minimalist, responsive design system |
| **Data Visualization** | **Recharts** | Dynamic SVG charts (Bar, Scatter, Pie) |
| **ORM & Database** | **Prisma ORM & SQLite (`dev.db`)**| ACID compliant, zero-config persistence |
| **Authentication** | **JWT & HTTP-Only Cookies** | Protected admin dashboard & API endpoints |
| **File Processing** | **PapaParse** | CSV import validation & CSV dataset export |

---

## 📂 Project Structure

```text
├── app/
│   ├── (public)/                 # Public website route group
│   │   ├── layout.tsx            # Public layout with Navbar & Footer
│   │   ├── page.tsx              # Home: Hero + Live DB KPI counters + Recent listings
│   │   ├── predict/page.tsx      # Price prediction tool + instant factor breakdown
│   │   ├── explore/page.tsx      # Dataset table with search, filter, pagination, modal
│   │   ├── analytics/page.tsx    # Exploratory Data Analysis: 6 KPIs + 8 live charts
│   │   ├── methodology/page.tsx  # Valuation workflow (01-08) + Mathematical formula
│   │   ├── about/page.tsx        # Platform scope, architecture & stack overview
│   │   └── contact/page.tsx      # Support coordinates + inquiry submission form
│   ├── admin/                    # Protected Admin Portal
│   │   ├── layout.tsx            # Server auth guard & layout wrapper
│   │   ├── AdminShell.tsx        # Responsive sidebar, navigation & user session badge
│   │   ├── login/page.tsx        # Admin authentication form (admin / vivektrails)
│   │   ├── page.tsx              # Admin overview dashboard + live audit counters
│   │   ├── properties/page.tsx   # Complete CRUD table (Add, Edit, Delete with modal)
│   │   ├── predictions/page.tsx  # Historical prediction audit trail + inspection
│   │   ├── analytics/page.tsx    # Dedicated admin analytics view
│   │   ├── content/page.tsx      # Website content CMS (updates live DB content)
│   │   └── settings/page.tsx     # Demo data re-seeding, CSV download & CSV import
│   ├── api/                      # RESTful Server API Endpoints
│   │   ├── stats/route.ts        # Database aggregation statistics
│   │   ├── analytics/route.ts    # Aggregated datasets for all 8 charts
│   │   ├── properties/           # Property collection CRUD
│   │   ├── predict/route.ts      # Deterministic prediction computation & DB logging
│   │   ├── predictions/route.ts  # Prediction audit logs query & purge
│   │   ├── content/route.ts      # Fetch & update dynamic site copy
│   │   └── admin/                # Admin auth, demo seed, CSV export & import
├── components/                   # Reusable UI Components (Navbar, Footer, Modals)
├── lib/                          # Core Business Logic & Infrastructure
│   ├── prisma.ts                 # Prisma Client singleton
│   ├── auth.ts                   # JWT token generation & request verification
│   ├── predictionEngine.ts       # Deterministic Hedonic Valuation Engine
│   ├── demoData.ts               # Realistic property seed records
│   ├── seedUtil.ts               # Shared database seeding logic
│   └── utils.ts                  # Currency (₹ INR), Number, and Date formatters
├── prisma/
│   ├── schema.prisma             # Property, Prediction, WebsiteContent models
│   ├── seed.js                   # Standalone database seeder
│   └── dev.db                    # Persistent SQLite database file
├── .env                          # Environment variables
├── package.json
└── README.md
```

---

## ⚡ Quick Start & Installation

### Prerequisites
- **Node.js**: v18.0.0 or higher (v20+ recommended)
- **npm** or **yarn**

### 1. Clone & Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Create or verify `.env` file in the project root:
```env
DATABASE_URL="file:./dev.db"
JWT_SECRET="house_land_price_prediction_super_secret_key_2026"
ADMIN_USERNAME="admin"
ADMIN_PASSWORD_PLAIN="vivektrails"
```

### 3. Initialize & Seed Database
Generate the Prisma client and push the schema to SQLite:
```bash
npx prisma db push
node prisma/seed.js
```

### 4. Start Development Server
```bash
npm run dev
```
Open **[http://localhost:3000](http://localhost:3000)** in your browser.

---

## 🔐 Admin Authentication Credentials

- **Admin Login Route**: `/admin/login`
- **Username**: `admin`
- **Password**: `vivektrails`

> The admin portal is protected by server-side verification using signed JSON Web Tokens stored in secure HTTP-only cookies.

---

## 🧮 Mathematical Hedonic Pricing Formulation

The centralized prediction engine in `lib/predictionEngine.ts` implements a multi-attribute hedonic regression equation:

$$\text{Estimated Price} = \text{Area} \times R_{\text{effective}} + V_{\text{parking}}$$

Where the effective square foot rate ($R_{\text{effective}}$) is computed as:

$$R_{\text{effective}} = R_{\text{base}}(\text{City}) \times C_{\text{type}} \times M_{\text{rating}} \times D_{\text{road}} \times \delta_{\text{age}} \times F_{\text{furnishing}} \times U_{\text{layout}}$$

### Multiplier Details:
1. **City Baseline ($R_{\text{base}}$)**: Dynamically blends 60% empirical database arithmetic mean for the target city with 40% calibrated baseline prior.
2. **Locality Rating ($M_{\text{rating}}$)**: Linear scaling: $0.65 + (\text{Rating} \times 0.07)$. Rating 8.0/10 yields a $+21\%$ premium over the median.
3. **Age Depreciation ($\delta_{\text{age}}$)**: Built structures depreciate $0.75\%$ per year (capped at $30\%$). Plots/Land assets do not depreciate.
4. **Road Distance ($D_{\text{road}}$)**: Proximity discount of $-1.8\%$ per km away from arterial roads (capped at $-20\%$).
5. **Room Layout Utility ($U_{\text{layout}}$)**: Calculates spatial adequacy based on expected density per 500 sq.ft.

---

## 🧪 Comprehensive Verification Checklist

The system satisfies all 8 verification tests:

- [x] **Test 1**: Homepage live statistics (Total properties, average price, average area, price/sqft) compute directly from database.
- [x] **Test 2**: Prediction form evaluated with Mumbai 2BHK House (1000 sqft, Rating 8) computes realistic valuation, factor breakdown, and logs record to SQLite.
- [x] **Test 3**: Admin login with `admin` / `vivektrails` grants access to management console.
- [x] **Test 4**: Adding a property in Admin immediately updates property tables, homepage counters, and EDA charts.
- [x] **Test 5**: Editing that property updates dependent statistics and dataset views.
- [x] **Test 6**: Deleting that property with confirmation dialog purges it and recalculates analytics.
- [x] **Test 7**: Admin prediction history displays logged user calculations with full input summaries.
- [x] **Test 8**: Database persists all data across browser reloads and server restarts in `prisma/dev.db`.

---

## 📄 Dataset Disclaimer
Property listings and initial sample records represent a **DEMO DATASET** calibrated for demonstration and operational evaluation purposes.

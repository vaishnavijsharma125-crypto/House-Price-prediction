# 🚀 Render.com Deployment Guide

This guide walks you through deploying the **House & Land Price Prediction Analysis Platform** to **[Render.com](https://render.com)**.

---

## 📋 Pre-requisites

1. A free account on **[Render.com](https://dashboard.render.com)**.
2. A free account on **[GitHub.com](https://github.com)**.

---

## Step 1: Initialize Git and Push to GitHub

In your project terminal (PowerShell / Command Prompt), run:

```bash
# 1. Initialize local git repository
git init

# 2. Add all project files
git add .

# 3. Create your first commit
git commit -m "Production release ready for Render"
```

Next, open [github.com/new](https://github.com/new) in your browser:
- Repository name: `house-price-prediction-analysis` (or your choice)
- Set visibility to **Public** or **Private**
- Do **not** check "Add a README file"
- Click **Create repository**

Copy the push commands from GitHub and run them in your terminal:

```bash
git remote add origin https://github.com/<YOUR-GITHUB-USERNAME>/<YOUR-REPO-NAME>.git
git branch -M main
git push -u origin main
```

---

## Step 2: Deploy to Render.com

You have two simple options on Render:

### 🌟 Option A: 1-Click Blueprint (Recommended - Full PostgreSQL Setup)

The repository already includes a pre-configured `render.yaml` file that automatically provisions both the **Web Service** and a **Free PostgreSQL Database**.

1. Log in to [dashboard.render.com](https://dashboard.render.com).
2. Click the **"New +"** button in the top navigation bar.
3. Select **"Blueprint"**.
4. Connect your GitHub account and select your repository (`house-price-prediction-analysis`).
5. Render will automatically detect `render.yaml` and configure:
   - Web Service: `propval-analytics`
   - Database: `propval-db` (Free PostgreSQL)
   - Build Command: `npm install && npm run deploy:build`
   - Start Command: `npm start`
6. Click **"Apply"**.
7. Render will build the Next.js application, apply the database schema, seed initial records, and deploy!

---

### ⚡ Option B: Manual Web Service (Fastest - Standalone)

If you prefer to deploy as a standalone Web Service:

1. In [Render Dashboard](https://dashboard.render.com), click **"New +"** -> **"Web Service"**.
2. Connect your GitHub repository.
3. Configure the following settings:
   - **Name**: `propval-analytics`
   - **Region**: Any (e.g., *Oregon (US West)* or *Frankfurt (EU)*)
   - **Branch**: `main`
   - **Root Directory**: *(Leave empty)*
   - **Runtime**: `Node`
   - **Build Command**:
     ```bash
     npm install && npm run deploy:build
     ```
   - **Start Command**:
     ```bash
     npm start
     ```
   - **Plan**: `Free`

4. Click **"Advanced"** and add these **Environment Variables**:

| Key | Value | Description |
| :--- | :--- | :--- |
| `NODE_ENV` | `production` | Production mode |
| `JWT_SECRET` | `propval_super_secure_jwt_key_2026_xyz` | Random secret string for JWT tokens |
| `DATABASE_URL` | `file:./dev.db` | Local SQLite file *(or your PostgreSQL connection string)* |

5. Click **"Create Web Service"**.

---

## Step 3: Access Your Deployed Site

Once the build finishes (usually 2-3 minutes), Render will assign you a live HTTPS URL like:
👉 **`https://propval-analytics.onrender.com`**

### Default Administrator Credentials on Render:
- **Admin Login URL**: `https://<YOUR-RENDER-SUBDOMAIN>.onrender.com/admin/login`
- **Username / Email**: `admin@propval.com` (or `admin`)
- **Password**: `vivektrails`

*(All initial property listings, market benchmarks, and admin accounts will be automatically seeded into the database during the build!)*

import { prisma } from './prisma';
import { SAMPLE_PROPERTIES } from './demoData';

export async function seedDatabase(clearExisting = false) {
  if (clearExisting) {
    await prisma.property.deleteMany({});
  }

  let insertedCount = 0;
  for (const item of SAMPLE_PROPERTIES) {
    const existing = await prisma.property.findUnique({
      where: { propertyCode: item.propertyId },
    });

    if (!existing) {
      // Find or create matching location
      let loc = await prisma.location.findFirst({
        where: { city: item.location },
      });

      if (!loc) {
        loc = await prisma.location.create({
          data: {
            city: item.location,
            area: `${item.location} Central`,
            locality: `${item.location} Central`,
            state: 'Maharashtra',
            avgPricePerSqFt: Math.round(item.price / Math.max(1, item.area)),
            marketTier: 'Tier 1',
            isActive: true,
          },
        });
      }

      await prisma.property.create({
        data: {
          propertyCode: item.propertyId,
          title: `${item.bedrooms > 0 ? `${item.bedrooms} BHK ` : ''}${item.propertyType} in ${item.location}`,
          description: `Prime ${item.propertyType.toLowerCase()} located in ${item.location} offering ${item.area} sq.ft of carpet area with verified infrastructure and prime connectivity.`,
          propertyType: item.propertyType === 'House' ? 'Villa/House' : item.propertyType,
          listingType: 'SALE',
          locationId: loc.id,
          address: `${item.location} Prime Sector`,
          areaSqFt: item.area,
          bedrooms: item.bedrooms,
          bathrooms: item.bathrooms,
          balconies: 1,
          floor: item.floors > 2 ? 3 : 1,
          totalFloors: item.floors,
          propertyAge: item.propertyAge,
          parking: item.parking,
          furnishing: item.furnishing,
          constructionStatus: 'Ready to Move',
          expectedPrice: item.price,
          status: 'ACTIVE',
        },
      });
      insertedCount++;
    }
  }

  // Ensure default website content exists
  const defaultContent = await prisma.websiteContent.findUnique({
    where: { id: 'default' },
  });

  if (!defaultContent) {
    await prisma.websiteContent.create({
      data: {
        id: 'default',
        heroTitle: 'HOUSE & LAND PRICE PREDICTION ANALYSIS',
        heroSubtitle:
          'A data-driven real estate valuation platform that estimates residential and commercial property values using robust multi-factor regression analysis.',
        aboutProject:
          'This property valuation and predictive analytics platform demonstrates an end-to-end full-stack valuation system. It integrates dataset management, exploratory data analysis, interactive visual analytics, and an extensible prediction engine.',
        methodologyText:
          'The system implements a rigorous multi-stage analytical workflow: Data Collection -> Data Cleaning -> Preprocessing -> Exploratory Data Analysis (EDA) -> Feature Engineering -> Statistical Regression & Weighted Valuation Engine -> Prediction Delivery & Analytics.',
        contactEmail: 'support@propvalanalytics.com',
        contactPhone: '+91 98765 43210',
        contactAddress:
          'PropVal Analytics Operations Hub, Tech Park, Sector 5',
        featureDescriptions: JSON.stringify([
          {
            title: 'Statistical Hedonic Engine',
            desc: 'Deterministic multi-factor algorithm calibrating baseline location values with physical characteristics.',
          },
          {
            title: 'Dynamic Dataset Analytics',
            desc: 'Live recalculation of statistical distributions, correlations, and geospatial metrics upon any dataset change.',
          },
          {
            title: 'Complete Admin Management',
            desc: 'Secure management portal for dataset curation, prediction audit logs, and dynamic web content modification.',
          },
          {
            title: 'Valuation Methodology',
            desc: 'Designed according to rigorous empirical valuation standards comparing statistical baselines with ML pipelines.',
          },
        ]),
      },
    });
  }

  // Ensure sample valuation request and prediction exist
  const existingPreds = await prisma.prediction.count();
  if (existingPreds === 0) {
    const valReq = await prisma.valuationRequest.create({
      data: {
        requestRef: 'VAL-INIT-001',
        propertyType: 'Apartment',
        localityText: 'Bandra West, Mumbai',
        areaSqFt: 1100,
        bedrooms: 2,
        bathrooms: 2,
        balconies: 1,
        floor: 7,
        totalFloors: 14,
        propertyAge: 3,
        parking: 'Yes',
        furnishing: 'Semi-Furnished',
        constructionStatus: 'Ready to Move',
        amenities: JSON.stringify(['Gated Security', 'Gymnasium', 'Power Backup']),
        contactName: 'Rohit Sharma',
        contactEmail: 'rohit@example.com',
        contactPhone: '+91 98200 12345',
        status: 'COMPLETED',
      },
    });

    await prisma.prediction.create({
      data: {
        valuationRequestId: valReq.id,
        estimatedPrice: 20450000,
        lowEstimate: 19325000,
        highEstimate: 21575000,
        pricePerSqFt: 18591,
        confidenceLevel: 'High',
        modelVersion: 'valuation-v1.2-baseline',
        factorsJson: JSON.stringify([
          { name: 'Location Base', impact: 'positive', description: 'Bandra West luxury corridor', weightPct: 30 },
          { name: 'Elevation & Floor', impact: 'positive', description: 'Floor 7 vantage', weightPct: 15 },
        ]),
        comparablesJson: JSON.stringify([]),
        dataPointsUsed: 12,
      },
    });
  }

  return { insertedCount };
}

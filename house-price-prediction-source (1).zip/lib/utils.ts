import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatIndianCurrency(amount: number): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '₹ 0';

  // Format into standard Indian number system: ₹ XX,XX,XXX
  const formatted = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 0,
  }).format(Math.round(amount));

  return `₹ ${formatted}`;
}

export function formatCompactCurrency(amount: number): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '₹0';
  if (amount >= 10000000) {
    return `₹${(amount / 10000000).toFixed(2)} Cr`;
  }
  if (amount >= 100000) {
    return `₹${(amount / 100000).toFixed(2)} L`;
  }
  return `₹${amount.toLocaleString('en-IN')}`;
}

export function formatNumber(num: number): string {
  if (num === undefined || num === null || isNaN(num)) return '0';
  return new Intl.NumberFormat('en-IN').format(Math.round(num));
}

export function formatDate(dateStr: string | Date): string {
  try {
    const d = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
    return d.toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return String(dateStr);
  }
}

export const FALLBACK_PROPERTY_IMAGES: Record<string, string[]> = {
  apartment: [
    'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80',
  ],
  villa: [
    'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80',
  ],
  commercial: [
    'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80',
  ],
  plot: [
    'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1524813686514-a57563d77d4e?auto=format&fit=crop&w=1200&q=80',
  ],
  penthouse: [
    'https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80',
  ],
};

export function getPropertyImageUrl(property: any, index: number = 0): string {
  if (property?.images && property.images.length > 0) {
    const primary = property.images.find((img: any) => img.isPrimary);
    if (primary?.imageUrl && index === 0) return primary.imageUrl;
    if (property.images[index]?.imageUrl) return property.images[index].imageUrl;
    if (property.images[0]?.imageUrl) return property.images[0].imageUrl;
  }
  if (property?.imageUrl) return property.imageUrl;

  const type = (property?.propertyType || '').toLowerCase();
  const idNum = typeof property?.id === 'number' ? property.id : (property?.propertyCode ? property.propertyCode.length : 0);

  if (type.includes('villa') || type.includes('house')) {
    const list = FALLBACK_PROPERTY_IMAGES.villa;
    return list[(idNum + index) % list.length];
  }
  if (type.includes('commercial') || type.includes('office')) {
    const list = FALLBACK_PROPERTY_IMAGES.commercial;
    return list[(idNum + index) % list.length];
  }
  if (type.includes('plot') || type.includes('land')) {
    const list = FALLBACK_PROPERTY_IMAGES.plot;
    return list[(idNum + index) % list.length];
  }
  if (type.includes('penthouse')) {
    const list = FALLBACK_PROPERTY_IMAGES.penthouse;
    return list[(idNum + index) % list.length];
  }

  const list = FALLBACK_PROPERTY_IMAGES.apartment;
  return list[(idNum + index) % list.length];
}


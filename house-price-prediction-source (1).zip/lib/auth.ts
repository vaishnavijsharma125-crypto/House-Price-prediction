import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { NextRequest } from 'next/server';
import { prisma } from './prisma';
import { UserRole } from '@/types';

const JWT_SECRET = process.env.JWT_SECRET || 'propval_production_jwt_secret_key_2026';

export interface TokenPayload {
  userId: number;
  email: string;
  name: string;
  role: UserRole;
  iat?: number;
  exp?: number;
}

export function signToken(user: { id: number; email: string; name: string; role: string }): string {
  return jwt.sign(
    {
      userId: user.id,
      email: user.email,
      name: user.name,
      role: user.role as UserRole,
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as TokenPayload;
  } catch {
    return null;
  }
}

export const verifyTokenString = verifyToken;

export async function hashPassword(plainText: string): Promise<string> {
  return bcrypt.hash(plainText, 10);
}

export async function verifyPassword(plainText: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plainText, hash);
}

export function extractAuthUser(request: NextRequest): TokenPayload | null {
  // 1. Check Bearer token header
  const authHeader = request.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    const decoded = verifyToken(token);
    if (decoded) return decoded;
  }

  // 2. Check HTTP-only cookie
  const cookieToken = request.cookies.get('admin_token')?.value;
  if (cookieToken) {
    const decoded = verifyToken(cookieToken);
    if (decoded) return decoded;
  }

  return null;
}

export function checkRoleAccess(userRole: UserRole, requiredRoles?: UserRole[]): boolean {
  if (!requiredRoles || requiredRoles.length === 0) return true;
  if (userRole === 'SUPER_ADMIN') return true;
  return requiredRoles.includes(userRole);
}

export function verifyAdminRequest(
  request: NextRequest,
  requiredRoles?: UserRole[]
): TokenPayload | null {
  const user = extractAuthUser(request);
  if (!user) return null;
  if (!checkRoleAccess(user.role, requiredRoles)) return null;
  return user;
}

# Machine Learning Architecture & Integration Guide

This directory defines the machine learning architecture designed to interface with the **PropVal Analytics** valuation platform.

## Architecture Flow
```
[Client Web Application / Valuation Wizard]
                    │
                    ▼
          [Next.js API Routes]
                    │
                    ▼
          [ValuationService]
          (/services/valuationService.ts)
                    │
          ┌─────────┴─────────┐
          ▼                   ▼
 [MLService (External)]   [Deterministic Hedonic Engine]
 (FastAPI / XGBoost)      (Transparent baseline fallback)
```

## Production ML Service Contract
When an external Python microservice is deployed (e.g. at `ML_SERVICE_URL`), it exposes a `POST /predict` endpoint consuming the standard `ValuationInput` schema.

### Input Payload
```json
{
  "propertyType": "Apartment",
  "city": "Mumbai",
  "locality": "Bandra West",
  "areaSqFt": 1250,
  "bedrooms": 3,
  "bathrooms": 2,
  "balconies": 1,
  "propertyAge": 4,
  "floor": 8,
  "totalFloors": 16,
  "parking": "Covered",
  "furnishing": "Semi-Furnished",
  "constructionStatus": "Ready to Move",
  "amenities": ["Gym", "Security", "Clubhouse"]
}
```

### Output Response
```json
{
  "estimatedPrice": 28500000,
  "lowEstimate": 26800000,
  "highEstimate": 30500000,
  "pricePerSqFt": 22800,
  "confidenceScore": 0.91,
  "modelVersion": "xgboost-regressor-v2.1",
  "shapValues": {
    "locality": 0.42,
    "areaSqFt": 0.35,
    "floor": 0.08,
    "age": -0.05
  }
}
```

The system automatically records the `modelVersion` with every generated prediction for retrospective performance audits.

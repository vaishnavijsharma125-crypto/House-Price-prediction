const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const PROPERTY_IMAGE_SETS = {
  'PROP-MUM-101': [
    { url: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80', caption: 'Sea View Living Room & Balcony', primary: true },
    { url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80', caption: 'Master Bedroom with Coastal Panorama', primary: false },
    { url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80', caption: 'Modern Modular Italian Kitchen', primary: false },
  ],
  'PROP-MUM-102': [
    { url: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80', caption: 'Contemporary 2BHK Hall', primary: true },
    { url: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80', caption: 'Dining & Kitchen View', primary: false },
  ],
  'PROP-BLR-201': [
    { url: 'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80', caption: 'Architectural Villa Facade with Lawn', primary: true },
    { url: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80', caption: 'Double-Height Living Lounge', primary: false },
    { url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80', caption: 'Private Terrace Deck', primary: false },
  ],
  'PROP-BLR-202': [
    { url: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80', caption: 'Gated Society High-Rise Tower', primary: true },
    { url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80', caption: 'Society Clubhouse & Olympic Pool', primary: false },
  ],
  'PROP-DEL-301': [
    { url: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80', caption: 'Luxury Builder Floor Exterior', primary: true },
    { url: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1200&q=80', caption: 'Spacious Formal Living Room', primary: false },
  ],
  'PROP-PUN-401': [
    { url: 'https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=1200&q=80', caption: 'Sky Penthouse Panoramic Deck', primary: true },
    { url: 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80', caption: 'Private Plunge Pool & Terrace Bar', primary: false },
  ],
  'PROP-HYD-501': [
    { url: 'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?auto=format&fit=crop&w=1200&q=80', caption: 'Gachibowli IT Corridor High-Rise Tower', primary: true },
    { url: 'https://images.unsplash.com/photo-1560185007-cde436f6a4d0?auto=format&fit=crop&w=1200&q=80', caption: 'Spacious 3 BHK Interior', primary: false },
  ],
  'PROP-CHE-601': [
    { url: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&w=1200&q=80', caption: 'Independent Residential House with Portico', primary: true },
    { url: 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=1200&q=80', caption: 'Garden Porch & Driveway', primary: false },
  ],
};

const GENERIC_POOLS = {
  Apartment: [
    'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80',
  ],
  'Villa/House': [
    'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80',
  ],
  Commercial: [
    'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80',
  ],
  'Plot/Land': [
    'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1524813686514-a57563d77d4e?auto=format&fit=crop&w=1200&q=80',
  ],
  Penthouse: [
    'https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80',
  ],
};

async function seedPropertyImages() {
  console.log('Seeding curated high-resolution real estate photography...');

  // Remove existing images to avoid duplicates
  await prisma.propertyImage.deleteMany({});

  const properties = await prisma.property.findMany();
  console.log(`Found ${properties.length} properties to attach images to.`);

  let totalImagesCreated = 0;

  for (const prop of properties) {
    const customSet = PROPERTY_IMAGE_SETS[prop.propertyCode];

    if (customSet && customSet.length > 0) {
      for (let i = 0; i < customSet.length; i++) {
        const item = customSet[i];
        await prisma.propertyImage.create({
          data: {
            propertyId: prop.id,
            imageUrl: item.url,
            caption: item.caption,
            isPrimary: item.primary,
            orderIndex: i,
          },
        });
        totalImagesCreated++;
      }
    } else {
      // Pick generic high quality images based on type
      const pool = GENERIC_POOLS[prop.propertyType] || GENERIC_POOLS['Apartment'];
      const img1 = pool[prop.id % pool.length];
      const img2 = pool[(prop.id + 1) % pool.length];

      await prisma.propertyImage.create({
        data: {
          propertyId: prop.id,
          imageUrl: img1,
          caption: `${prop.propertyType} Front View`,
          isPrimary: true,
          orderIndex: 0,
        },
      });
      totalImagesCreated++;

      if (img2 !== img1) {
        await prisma.propertyImage.create({
          data: {
            propertyId: prop.id,
            imageUrl: img2,
            caption: `${prop.propertyType} Interior / Layout`,
            isPrimary: false,
            orderIndex: 1,
          },
        });
        totalImagesCreated++;
      }
    }
  }

  console.log(`✔ Successfully created ${totalImagesCreated} property image records!`);
}

seedPropertyImages()
  .catch((e) => {
    console.error('Error seeding property images:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

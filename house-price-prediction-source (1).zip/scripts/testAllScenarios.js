const http = require('http');

function request(options, data) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(body);
        } catch {}
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body,
          json,
        });
      });
    });
    req.on('error', reject);
    if (data) req.write(typeof data === 'string' ? data : JSON.stringify(data));
    req.end();
  });
}

async function runTests() {
  console.log('========================================================');
  console.log('STARTING FULL SYSTEM VERIFICATION SUITE (TESTS 1 to 8)');
  console.log('========================================================\n');

  // Wait for server to be responsive
  let serverReady = false;
  for (let i = 0; i < 15; i++) {
    try {
      const ping = await request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/stats',
        method: 'GET',
      });
      if (ping.statusCode === 200) {
        serverReady = true;
        break;
      }
    } catch {
      await new Promise((r) => setTimeout(r, 1000));
    }
  }

  if (!serverReady) {
    console.error('FAIL: Next.js server not responding on port 3000');
    process.exit(1);
  }
  console.log('✔ Server is online and responding at http://localhost:3000\n');

  // TEST 1: Open website & verify homepage statistics load from database
  console.log('--- TEST 1: Verify Homepage Statistics from Database ---');
  const statsRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/stats',
    method: 'GET',
  });
  console.log(`HTTP Status: ${statsRes.statusCode}`);
  console.log(`Live DB Statistics:`, statsRes.json);
  if (
    statsRes.statusCode === 200 &&
    statsRes.json.totalProperties > 0 &&
    statsRes.json.averagePrice > 0 &&
    statsRes.json.averageArea > 0
  ) {
    console.log('✔ TEST 1 PASSED: Real statistics loaded from SQLite database.\n');
  } else {
    console.error('✖ TEST 1 FAILED');
    process.exit(1);
  }

  const initialTotalProperties = statsRes.json.totalProperties;
  const initialAveragePrice = statsRes.json.averagePrice;

  // TEST 2: Go to Prediction & enter Mumbai 2BHK House
  console.log('--- TEST 2: Run Property Prediction (Mumbai House 2BHK 1000 sqft) ---');
  const test2Input = {
    propertyType: 'House',
    location: 'Mumbai',
    area: 1000,
    bedrooms: 2,
    bathrooms: 2,
    floors: 1,
    propertyAge: 5,
    parking: 'Yes',
    furnishing: 'Semi-Furnished',
    nearbyFacilities: 'Good',
    distanceFromMainRoad: 1,
    localityRating: 8,
  };

  const predRes = await request(
    {
      hostname: 'localhost',
      port: 3000,
      path: '/api/predict',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    },
    test2Input
  );

  console.log(`HTTP Status: ${predRes.statusCode}`);
  console.log(`Calculated Prediction Output:`, predRes.json);
  if (
    predRes.statusCode === 200 &&
    predRes.json.success === true &&
    predRes.json.predictedPrice > 0 &&
    predRes.json.predictionId
  ) {
    console.log(
      `✔ TEST 2 PASSED: Prediction calculated: ₹${predRes.json.predictedPrice.toLocaleString(
        'en-IN'
      )}, ID: ${predRes.json.predictionId}\n`
    );
  } else {
    console.error('✖ TEST 2 FAILED');
    process.exit(1);
  }
  const test2PredictionId = predRes.json.predictionId;

  // TEST 3: Admin Login with admin / vivektrails
  console.log('--- TEST 3: Admin Login (admin / vivektrails) ---');
  const loginRes = await request(
    {
      hostname: 'localhost',
      port: 3000,
      path: '/api/admin/login',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    },
    { username: 'admin', password: 'vivektrails' }
  );

  console.log(`HTTP Status: ${loginRes.statusCode}`);
  console.log(`Login Response:`, loginRes.json);

  const cookieHeader = loginRes.headers['set-cookie'];
  let adminCookie = '';
  if (cookieHeader) {
    const raw = Array.isArray(cookieHeader) ? cookieHeader[0] : cookieHeader;
    adminCookie = raw.split(';')[0];
  }
  const adminToken = loginRes.json?.token;

  if (loginRes.statusCode === 200 && loginRes.json.success === true && adminToken) {
    console.log('✔ TEST 3 PASSED: Admin authenticated, session token issued.\n');
  } else {
    console.error('✖ TEST 3 FAILED');
    process.exit(1);
  }

  // TEST 4: Add New Property
  console.log('--- TEST 4: Admin Add Property ---');
  const testPropertyId = `TEST-PROP-${Date.now().toString().slice(-4)}`;
  const newProperty = {
    propertyId: testPropertyId,
    propertyType: 'Villa',
    location: 'Bangalore',
    area: 3500,
    bedrooms: 5,
    bathrooms: 5,
    floors: 3,
    propertyAge: 1,
    parking: 'Yes',
    furnishing: 'Fully-Furnished',
    nearbyFacilities: 'Excellent',
    distanceFromMainRoad: 0.5,
    localityRating: 9.5,
    price: 45000000,
  };

  const addRes = await request(
    {
      hostname: 'localhost',
      port: 3000,
      path: '/api/properties',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        Cookie: adminCookie,
      },
    },
    newProperty
  );

  console.log(`HTTP Status: ${addRes.statusCode}`);
  console.log(`Add Property Response:`, addRes.json);
  const createdPropertyDbId = addRes.json?.property?.id;

  // Verify DB stats and charts update
  const statsAfterAdd = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/stats',
    method: 'GET',
  });
  console.log(
    `Updated Property Count: ${statsAfterAdd.json.totalProperties} (was ${initialTotalProperties})`
  );

  if (
    addRes.statusCode === 201 &&
    createdPropertyDbId &&
    statsAfterAdd.json.totalProperties === initialTotalProperties + 1
  ) {
    console.log('✔ TEST 4 PASSED: Property created, database and statistics recalculated.\n');
  } else {
    console.error('✖ TEST 4 FAILED');
    process.exit(1);
  }

  // TEST 5: Edit that Property
  console.log(`--- TEST 5: Admin Edit Property ${testPropertyId} ---`);
  const editRes = await request(
    {
      hostname: 'localhost',
      port: 3000,
      path: `/api/properties/${createdPropertyDbId}`,
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        Cookie: adminCookie,
      },
    },
    {
      price: 52000000,
      area: 3800,
      furnishing: 'Fully-Furnished',
    }
  );

  console.log(`HTTP Status: ${editRes.statusCode}`);
  console.log(`Updated Property Data:`, editRes.json);

  const statsAfterEdit = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/stats',
    method: 'GET',
  });

  if (
    editRes.statusCode === 200 &&
    editRes.json.property?.price === 52000000 &&
    editRes.json.property?.area === 3800
  ) {
    console.log('✔ TEST 5 PASSED: Property updated, dependent data verified.\n');
  } else {
    console.error('✖ TEST 5 FAILED');
    process.exit(1);
  }

  // TEST 6: Delete Property with Admin Auth
  console.log(`--- TEST 6: Admin Delete Property ${testPropertyId} ---`);
  const delRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/properties/${createdPropertyDbId}`,
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${adminToken}`,
      Cookie: adminCookie,
    },
  });

  console.log(`HTTP Status: ${delRes.statusCode}`);
  console.log(`Delete Response:`, delRes.json);

  const statsAfterDelete = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/stats',
    method: 'GET',
  });
  console.log(
    `Property Count After Delete: ${statsAfterDelete.json.totalProperties} (reverted to ${initialTotalProperties})`
  );

  if (
    delRes.statusCode === 200 &&
    statsAfterDelete.json.totalProperties === initialTotalProperties
  ) {
    console.log('✔ TEST 6 PASSED: Property deleted, stats restored correctly.\n');
  } else {
    console.error('✖ TEST 6 FAILED');
    process.exit(1);
  }

  // TEST 7: Open Prediction History & verify Test 2 prediction exists
  console.log('--- TEST 7: Verify Prediction History in Admin ---');
  const predsHistoryRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/predictions?search=${encodeURIComponent(test2PredictionId)}`,
    method: 'GET',
    headers: {
      Authorization: `Bearer ${adminToken}`,
      Cookie: adminCookie,
    },
  });

  console.log(`HTTP Status: ${predsHistoryRes.statusCode}`);
  console.log(`Found Prediction Records:`, predsHistoryRes.json.predictions?.length);
  const foundPred = predsHistoryRes.json.predictions?.find(
    (p) => p.predictionId === test2PredictionId
  );

  if (predsHistoryRes.statusCode === 200 && foundPred) {
    console.log(
      `✔ TEST 7 PASSED: Prediction ${test2PredictionId} retrieved from audit history with inputs: ${foundPred.propertyType} in ${foundPred.location}, ₹${foundPred.predictedPrice.toLocaleString(
        'en-IN'
      )}\n`
    );
  } else {
    console.error('✖ TEST 7 FAILED');
    process.exit(1);
  }

  // TEST 8: Verify database persistence across re-queries
  console.log('--- TEST 8: Database Persistence Verification ---');
  const persistentCheck = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/properties?limit=5',
    method: 'GET',
  });

  if (
    persistentCheck.statusCode === 200 &&
    persistentCheck.json.properties?.length > 0 &&
    persistentCheck.json.pagination?.total === initialTotalProperties
  ) {
    console.log(
      `✔ TEST 8 PASSED: Persistent SQLite database intact with ${persistentCheck.json.pagination.total} records.\n`
    );
  } else {
    console.error('✖ TEST 8 FAILED');
    process.exit(1);
  }

  console.log('========================================================');
  console.log('🎉 ALL 8 USER VERIFICATION TESTS PASSED SUCCESSFULLY! 🎉');
  console.log('========================================================');
}

runTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});

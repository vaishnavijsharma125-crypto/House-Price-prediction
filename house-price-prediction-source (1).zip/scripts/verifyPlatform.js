const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || 'propval_production_jwt_secret_key_2026';

async function runTests() {
  console.log('====================================================');
  console.log('  COMMERCIAL REAL ESTATE PLATFORM VERIFICATION TEST ');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✔ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ✖ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    // TEST 1: Database Connectivity and Baseline Seeding
    console.log('--- TEST GROUP 1: Database & Credentials ---');
    const user = await prisma.user.findUnique({
      where: { email: 'admin@propval.com' },
    });
    assert(user !== null, 'Admin user account exists');
    assert(user?.role === 'SUPER_ADMIN', 'Admin has SUPER_ADMIN role');

    const passwordMatch = await bcrypt.compare('vivektrails', user.passwordHash);
    assert(passwordMatch, 'Admin password matches bcrypt hash for vivektrails');

    // TEST 2: Location Benchmarks
    console.log('\n--- TEST GROUP 2: Locations & Market Tiers ---');
    const locationsCount = await prisma.location.count();
    assert(locationsCount >= 20, `Locations master has sufficient coverage (${locationsCount} localities)`);

    const bandra = await prisma.location.findFirst({
      where: { locality: 'Bandra West' },
    });
    assert(bandra !== null && bandra.avgPricePerSqFt > 30000, `Bandra West benchmark calibrated at ₹${bandra?.avgPricePerSqFt}/sqft`);

    // TEST 3: Properties Dataset & Integrity
    console.log('\n--- TEST GROUP 3: Property Inventory ---');
    const propCount = await prisma.property.count();
    assert(propCount >= 8, `Active property listings exist (${propCount} listings)`);

    const sampleProp = await prisma.property.findFirst({
      include: { location: true },
    });
    assert(sampleProp !== null, 'Sample property found');
    assert(sampleProp.expectedPrice > 1000000, `Expected price is realistic: ₹${sampleProp.expectedPrice.toLocaleString('en-IN')}`);
    assert(sampleProp.areaSqFt > 100, `Area in sq.ft is recorded: ${sampleProp.areaSqFt}`);
    assert(sampleProp.location !== null, `Property linked to location relation: ${sampleProp.location.locality}, ${sampleProp.location.city}`);

    // TEST 4: Valuation Engine Persistence & Relationships
    console.log('\n--- TEST GROUP 4: Valuation Calculations & Persistence ---');
    const ref = `VAL-TEST-${Date.now().toString(36).toUpperCase()}`;
    const testValuation = await prisma.valuationRequest.create({
      data: {
        requestRef: ref,
        propertyType: 'Apartment',
        locationId: bandra.id,
        localityText: 'Bandra West',
        areaSqFt: 1400,
        bedrooms: 3,
        bathrooms: 3,
        balconies: 2,
        floor: 12,
        totalFloors: 20,
        propertyAge: 2,
        parking: 'Covered',
        furnishing: 'Fully-Furnished',
        constructionStatus: 'Ready to Move',
        amenities: JSON.stringify(['Gated Security', 'Swimming Pool', 'Clubhouse']),
        contactName: 'Anand Kumar',
        contactEmail: 'anand.kumar@testenterprise.com',
        contactPhone: '+91 98111 22334',
        status: 'COMPLETED',
      },
    });
    assert(testValuation.id > 0, `ValuationRequest created with ref ${ref}`);

    // Create Prediction record
    const estPrice = 54000000;
    const testPrediction = await prisma.prediction.create({
      data: {
        valuationRequestId: testValuation.id,
        estimatedPrice: estPrice,
        lowEstimate: estPrice * 0.94,
        highEstimate: estPrice * 1.06,
        pricePerSqFt: Math.round(estPrice / 1400),
        confidenceLevel: 'High',
        modelVersion: 'valuation-v1.2-baseline',
        factorsJson: JSON.stringify([
          { name: 'Locality Benchmark', impact: 'positive', description: 'Bandra West prime rates', weightPct: 35 },
          { name: 'Elevation Bonus', impact: 'positive', description: 'Floor 12 vantage', weightPct: 15 },
        ]),
        comparablesJson: JSON.stringify([]),
        dataPointsUsed: 15,
      },
    });
    assert(testPrediction.id > 0, `Prediction saved and linked to ValuationRequest #${testValuation.id}`);

    // Create Lead record automatically for this customer
    const leadCode = `LEAD-${Date.now().toString(36).toUpperCase()}`;
    const lead = await prisma.lead.create({
      data: {
        leadCode,
        name: testValuation.contactName,
        phone: testValuation.contactPhone,
        email: testValuation.contactEmail,
        source: 'Valuation Wizard',
        status: 'NEW',
        valuationRequestId: testValuation.id,
      },
    });
    assert(lead.id > 0, `Customer lead registered automatically with code ${leadCode}`);

    // TEST 5: Lead Pipeline Workflow
    console.log('\n--- TEST GROUP 5: Lead Status Progression ---');
    const updatedLead = await prisma.lead.update({
      where: { id: lead.id },
      data: {
        status: 'QUALIFIED',
        notes: 'High net-worth buyer looking for immediate registry. Qualified by sales team.',
      },
    });
    assert(updatedLead.status === 'QUALIFIED', 'Lead successfully transitioned to QUALIFIED');
    assert(updatedLead.notes?.includes('High net-worth'), 'Internal sales notes persisted properly');

    // TEST 6: Historical Property Transactions Dataset
    console.log('\n--- TEST GROUP 6: Historical Transaction Registry ---');
    const txnCount = await prisma.propertyTransaction.count();
    assert(txnCount >= 6, `Historical transaction registry populated (${txnCount} registered transactions)`);

    const sampleTxn = await prisma.propertyTransaction.findFirst();
    assert(sampleTxn !== null, 'Sample historical transaction retrieved');
    assert(sampleTxn.verified === true, 'Historical transaction is marked verified');
    assert(sampleTxn.pricePerSqFt > 0, `Transaction rate verified: ₹${sampleTxn.pricePerSqFt}/sqft`);

    // TEST 7: Audit Log Compliance
    console.log('\n--- TEST GROUP 7: Security & Audit Logging ---');
    const audit = await prisma.auditLog.create({
      data: {
        userId: user.id,
        userEmail: user.email,
        action: 'PLATFORM_VERIFICATION_TEST',
        entity: 'SystemTest',
        entityId: String(testValuation.id),
        metadata: JSON.stringify({ testTimestamp: new Date().toISOString() }),
        ipAddress: '127.0.0.1',
      },
    });
    assert(audit.id > 0, `Audit log entry created with ID #${audit.id}`);

    // TEST 8: Token Generation & Verification
    console.log('\n--- TEST GROUP 8: JWT Authentication ---');
    const token = jwt.sign(
      {
        userId: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    const decoded = jwt.verify(token, JWT_SECRET);
    assert(decoded.email === 'admin@propval.com', 'JWT token decoded and verified successfully');
    assert(decoded.role === 'SUPER_ADMIN', 'Decoded role matches SUPER_ADMIN');

    console.log('\n====================================================');
    console.log(`  TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
    console.log('====================================================');

    if (failed > 0) {
      process.exit(1);
    }
  } catch (err) {
    console.error('Fatal test error:', err);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

runTests();

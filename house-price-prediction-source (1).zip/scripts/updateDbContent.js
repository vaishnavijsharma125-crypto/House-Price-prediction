const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function updateDb() {
  await prisma.websiteContent.upsert({
    where: { id: 'default' },
    update: {
      heroTitle: 'HOUSE & LAND PRICE PREDICTION ANALYSIS',
      heroSubtitle:
        'A data-driven real estate analytics platform that estimates residential and commercial property values using robust multi-factor regression analysis.',
      aboutProject:
        'This property valuation and predictive analytics platform demonstrates an end-to-end full-stack valuation system. It integrates dataset management, exploratory data analysis, interactive visual analytics, and an extensible prediction engine.',
      methodologyText:
        'The system implements a rigorous multi-stage analytical workflow: Data Collection -> Data Cleaning -> Preprocessing -> Exploratory Data Analysis (EDA) -> Feature Engineering -> Statistical Regression & Weighted Valuation Engine -> Prediction Delivery & Analytics.',
      contactEmail: 'support@propvalanalytics.com',
      contactPhone: '+91 98765 43210',
      contactAddress: 'PropVal Analytics Operations Hub, Tech Park, Sector 5',
      featureDescriptions: JSON.stringify([
        {
          title: 'Statistical Hedonic Engine',
          desc: 'Deterministic multi-factor algorithm calibrating baseline location values with physical characteristics.',
        },
        {
          title: 'Dynamic Dataset Analytics',
          desc: 'Live recalculation of statistical distributions, correlations, and geospatial metrics upon any dataset change.',
        },
        {
          title: 'Complete Admin Management',
          desc: 'Secure management portal for dataset curation, prediction audit logs, and dynamic web content modification.',
        },
        {
          title: 'Valuation Methodology',
          desc: 'Designed according to rigorous empirical valuation standards comparing statistical baselines with ML pipelines.',
        },
      ]),
    },
    create: {
      id: 'default',
      heroTitle: 'HOUSE & LAND PRICE PREDICTION ANALYSIS',
      heroSubtitle:
        'A data-driven real estate analytics platform that estimates residential and commercial property values using robust multi-factor regression analysis.',
      aboutProject:
        'This property valuation and predictive analytics platform demonstrates an end-to-end full-stack valuation system. It integrates dataset management, exploratory data analysis, interactive visual analytics, and an extensible prediction engine.',
      methodologyText:
        'The system implements a rigorous multi-stage analytical workflow: Data Collection -> Data Cleaning -> Preprocessing -> Exploratory Data Analysis (EDA) -> Feature Engineering -> Statistical Regression & Weighted Valuation Engine -> Prediction Delivery & Analytics.',
      contactEmail: 'support@propvalanalytics.com',
      contactPhone: '+91 98765 43210',
      contactAddress: 'PropVal Analytics Operations Hub, Tech Park, Sector 5',
      featureDescriptions: '[]',
    },
  });

  console.log('Successfully updated dev.db WebsiteContent record.');
}

updateDb()
  .catch(console.error)
  .finally(() => prisma.$disconnect());

const fs = require('fs');
const path = require('path');

const dbUrl = process.env.DATABASE_URL || 'file:./dev.db';
const schemaPath = path.join(__dirname, '..', 'prisma', 'schema.prisma');
const pgSchemaPath = path.join(__dirname, '..', 'prisma', 'schema.postgresql.prisma');

if (dbUrl.startsWith('postgres://') || dbUrl.startsWith('postgresql://')) {
  console.log('[Render/Cloud Deploy] Detected PostgreSQL DATABASE_URL. Activating PostgreSQL schema...');
  if (fs.existsSync(pgSchemaPath)) {
    fs.copyFileSync(pgSchemaPath, schemaPath);
    console.log('✔ PostgreSQL schema applied.');
  }
} else {
  console.log('[Render/Local Deploy] Using SQLite database schema.');
}

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding production-grade real estate platform database...');

  // 1. Seed Users (Hashed passwords)
  const passwordHash = await bcrypt.hash('vivektrails', 10);

  const superAdmin = await prisma.user.upsert({
    where: { email: 'admin@propval.com' },
    update: { passwordHash },
    create: {
      email: 'admin@propval.com',
      name: 'System Administrator',
      passwordHash,
      role: 'SUPER_ADMIN',
      phone: '+91 98765 00001',
      isActive: true,
    },
  });

  await prisma.user.upsert({
    where: { email: 'analyst@propval.com' },
    update: { passwordHash },
    create: {
      email: 'analyst@propval.com',
      name: 'Market Research Analyst',
      passwordHash,
      role: 'ANALYST',
      phone: '+91 98765 00002',
      isActive: true,
    },
  });

  console.log('✔ Administrator accounts initialized.');

  // 2. Seed Structured Locations
  const locations = [
    // Mumbai
    { city: 'Mumbai', area: 'Western Suburbs', locality: 'Bandra West', pincode: '400050', state: 'Maharashtra', avgPricePerSqFt: 38000, marketTier: 'Luxury' },
    { city: 'Mumbai', area: 'Western Suburbs', locality: 'Andheri East', pincode: '400069', state: 'Maharashtra', avgPricePerSqFt: 18500, marketTier: 'Prime' },
    { city: 'Mumbai', area: 'South Mumbai', locality: 'Worli', pincode: '400018', state: 'Maharashtra', avgPricePerSqFt: 42000, marketTier: 'Luxury' },
    { city: 'Mumbai', area: 'Central Suburbs', locality: 'Powai', pincode: '400076', state: 'Maharashtra', avgPricePerSqFt: 21000, marketTier: 'Prime' },
    // Bangalore
    { city: 'Bangalore', area: 'East Bangalore', locality: 'Indiranagar', pincode: '560038', state: 'Karnataka', avgPricePerSqFt: 14500, marketTier: 'Prime' },
    { city: 'Bangalore', area: 'East Bangalore', locality: 'Whitefield', pincode: '560066', state: 'Karnataka', avgPricePerSqFt: 8800, marketTier: 'Tier 1' },
    { city: 'Bangalore', area: 'South Bangalore', locality: 'Koramangala', pincode: '560034', state: 'Karnataka', avgPricePerSqFt: 13800, marketTier: 'Prime' },
    { city: 'Bangalore', area: 'South Bangalore', locality: 'HSR Layout', pincode: '560102', state: 'Karnataka', avgPricePerSqFt: 9600, marketTier: 'Tier 1' },
    // Delhi / NCR
    { city: 'Delhi', area: 'South Delhi', locality: 'Vasant Kunj', pincode: '110070', state: 'Delhi', avgPricePerSqFt: 16500, marketTier: 'Prime' },
    { city: 'Delhi', area: 'Central Delhi', locality: 'Connaught Place', pincode: '110001', state: 'Delhi', avgPricePerSqFt: 26000, marketTier: 'Luxury' },
    { city: 'Delhi', area: 'Cyber Hub Corridor', locality: 'Gurgaon DLF Phase 5', pincode: '122002', state: 'Haryana', avgPricePerSqFt: 18200, marketTier: 'Prime' },
    { city: 'Delhi', area: 'Noida Expressway', locality: 'Noida Sector 62', pincode: '201301', state: 'Uttar Pradesh', avgPricePerSqFt: 7800, marketTier: 'Tier 1' },
    // Pune
    { city: 'Pune', area: 'East Pune', locality: 'Koregaon Park', pincode: '411001', state: 'Maharashtra', avgPricePerSqFt: 12500, marketTier: 'Prime' },
    { city: 'Pune', area: 'IT Corridor', locality: 'Hinjewadi', pincode: '411057', state: 'Maharashtra', avgPricePerSqFt: 6900, marketTier: 'Tier 2' },
    { city: 'Pune', area: 'West Pune', locality: 'Baner', pincode: '411045', state: 'Maharashtra', avgPricePerSqFt: 8900, marketTier: 'Tier 1' },
    // Hyderabad
    { city: 'Hyderabad', area: 'HITEC Corridor', locality: 'Hitec City', pincode: '500081', state: 'Telangana', avgPricePerSqFt: 9800, marketTier: 'Prime' },
    { city: 'Hyderabad', area: 'Financial District', locality: 'Gachibowli', pincode: '500032', state: 'Telangana', avgPricePerSqFt: 9100, marketTier: 'Tier 1' },
    { city: 'Hyderabad', area: 'Central Hyderabad', locality: 'Banjara Hills', pincode: '500034', state: 'Telangana', avgPricePerSqFt: 15400, marketTier: 'Luxury' },
    // Chennai
    { city: 'Chennai', area: 'Central Chennai', locality: 'Anna Nagar', pincode: '600040', state: 'Tamil Nadu', avgPricePerSqFt: 10500, marketTier: 'Prime' },
    { city: 'Chennai', area: 'South Chennai', locality: 'Adyar', pincode: '600020', state: 'Tamil Nadu', avgPricePerSqFt: 12200, marketTier: 'Prime' },
    // Kolkata
    { city: 'Kolkata', area: 'Salt Lake Sector 5', locality: 'Salt Lake', pincode: '700091', state: 'West Bengal', avgPricePerSqFt: 7200, marketTier: 'Tier 1' },
    // Ahmedabad
    { city: 'Ahmedabad', area: 'West Ahmedabad', locality: 'Bodakdev', pincode: '380054', state: 'Gujarat', avgPricePerSqFt: 7900, marketTier: 'Tier 1' },
  ];

  const createdLocations = {};
  for (const loc of locations) {
    const record = await prisma.location.upsert({
      where: {
        city_locality: { city: loc.city, locality: loc.locality },
      },
      update: loc,
      create: loc,
    });
    createdLocations[`${loc.city}-${loc.locality}`] = record.id;
  }
  console.log(`✔ Initialized ${Object.keys(createdLocations).length} structured locations.`);

  // 3. Seed Properties
  const properties = [
    {
      propertyCode: 'PROP-MUM-101',
      propertyType: 'Apartment',
      listingType: 'SALE',
      title: 'Luxury 3 BHK Sea-Facing Residence in Bandra West',
      description: 'Expansive living spaces with panoramic coastline views, Italian marble flooring, VRV climate control, and two dedicated covered parking bays.',
      locationId: createdLocations['Mumbai-Bandra West'],
      address: 'Sea View Heights, Carter Road, Bandra West',
      areaSqFt: 1650,
      bedrooms: 3,
      bathrooms: 3,
      balconies: 2,
      floor: 14,
      totalFloors: 24,
      propertyAge: 3,
      parking: 'Covered',
      furnishing: 'Fully-Furnished',
      constructionStatus: 'Ready to Move',
      amenities: JSON.stringify(['Swimming Pool', 'Gymnasium', '24/7 Concierge', 'Clubhouse', 'Power Backup']),
      expectedPrice: 62500000,
      status: 'ACTIVE',
      isFeatured: true,
    },
    {
      propertyCode: 'PROP-MUM-102',
      propertyType: 'Apartment',
      listingType: 'SALE',
      title: 'Modern 2 BHK Urban Flat near Metro',
      description: 'Well-appointed residential unit located in a gated community within walking distance of the metro station and commercial centers.',
      locationId: createdLocations['Mumbai-Andheri East'],
      address: 'Silver Oak Enclave, Chakala, Andheri East',
      areaSqFt: 980,
      bedrooms: 2,
      bathrooms: 2,
      balconies: 1,
      floor: 7,
      totalFloors: 16,
      propertyAge: 4,
      parking: 'Covered',
      furnishing: 'Semi-Furnished',
      constructionStatus: 'Ready to Move',
      amenities: JSON.stringify(['Gymnasium', 'Security', 'Intercom', 'Power Backup']),
      expectedPrice: 18100000,
      status: 'ACTIVE',
      isFeatured: false,
    },
    {
      propertyCode: 'PROP-BLR-201',
      propertyType: 'Villa/House',
      listingType: 'SALE',
      title: 'Contemporary 4 BHK Independent Villa in Indiranagar',
      description: 'Architect-designed private villa featuring landscaped courtyard, terrace garden, double-height living room, and private garage.',
      locationId: createdLocations['Bangalore-Indiranagar'],
      address: '100 Feet Road Enclave, Indiranagar',
      areaSqFt: 3200,
      bedrooms: 4,
      bathrooms: 5,
      balconies: 3,
      floor: 0,
      totalFloors: 3,
      propertyAge: 2,
      parking: 'Covered',
      furnishing: 'Semi-Furnished',
      constructionStatus: 'Ready to Move',
      amenities: JSON.stringify(['Private Garden', 'Security', 'Servant Quarters', 'Solar Power']),
      expectedPrice: 46400000,
      status: 'ACTIVE',
      isFeatured: true,
    },
    {
      propertyCode: 'PROP-BLR-202',
      propertyType: 'Apartment',
      listingType: 'SALE',
      title: 'Premium 3 BHK Gated Society Flat in Whitefield',
      description: 'Spacious high-rise apartment in Whitefield IT corridor with clubhouse access, sports facilities, and proximity to international schools.',
      locationId: createdLocations['Bangalore-Whitefield'],
      address: 'Prestige Boulevard, ITPL Main Road, Whitefield',
      areaSqFt: 1550,
      bedrooms: 3,
      bathrooms: 3,
      balconies: 2,
      floor: 9,
      totalFloors: 18,
      propertyAge: 1,
      parking: 'Covered',
      furnishing: 'Semi-Furnished',
      constructionStatus: 'Ready to Move',
      amenities: JSON.stringify(['Clubhouse', 'Swimming Pool', 'Tennis Court', 'Children Play Area', 'Power Backup']),
      expectedPrice: 13640000,
      status: 'ACTIVE',
      isFeatured: false,
    },
    {
      propertyCode: 'PROP-DEL-301',
      propertyType: 'Apartment',
      listingType: 'SALE',
      title: 'Spacious 3 BHK Builder Floor in Vasant Kunj',
      description: 'Independent builder floor with elevator access, reserved stilt parking, modular kitchen, and park view.',
      locationId: createdLocations['Delhi-Vasant Kunj'],
      address: 'Sector B, Pocket 1, Vasant Kunj',
      areaSqFt: 1800,
      bedrooms: 3,
      bathrooms: 3,
      balconies: 2,
      floor: 2,
      totalFloors: 4,
      propertyAge: 5,
      parking: 'Covered',
      furnishing: 'Semi-Furnished',
      constructionStatus: 'Ready to Move',
      amenities: JSON.stringify(['Lift', 'Security', 'Park View', 'Reserved Parking']),
      expectedPrice: 29700000,
      status: 'ACTIVE',
      isFeatured: false,
    },
    {
      propertyCode: 'PROP-PUN-401',
      propertyType: 'Penthouse',
      listingType: 'SALE',
      title: 'Exclusive 4 BHK Sky Penthouse in Koregaon Park',
      description: 'Top-floor penthouse with private plunge pool, 360-degree cityscape vistas, dedicated elevator access, and designer finishes.',
      locationId: createdLocations['Pune-Koregaon Park'],
      address: 'Lane 7, Koregaon Park',
      areaSqFt: 3400,
      bedrooms: 4,
      bathrooms: 5,
      balconies: 3,
      floor: 18,
      totalFloors: 18,
      propertyAge: 1,
      parking: 'Covered',
      furnishing: 'Fully-Furnished',
      constructionStatus: 'Ready to Move',
      amenities: JSON.stringify(['Private Pool', 'Gymnasium', 'Concierge', 'Power Backup', 'Terrace Lounge']),
      expectedPrice: 42500000,
      status: 'ACTIVE',
      isFeatured: true,
    },
    {
      propertyCode: 'PROP-HYD-501',
      propertyType: 'Apartment',
      listingType: 'SALE',
      title: 'High-Rise 3 BHK Flat in Gachibowli Financial District',
      description: 'Modern condominium minutes from Amazon and Microsoft campuses with club amenities and round-the-clock maintenance.',
      locationId: createdLocations['Hyderabad-Gachibowli'],
      address: 'Financial District Boulevard, Gachibowli',
      areaSqFt: 1720,
      bedrooms: 3,
      bathrooms: 3,
      balconies: 2,
      floor: 11,
      totalFloors: 25,
      propertyAge: 2,
      parking: 'Covered',
      furnishing: 'Semi-Furnished',
      constructionStatus: 'Ready to Move',
      amenities: JSON.stringify(['Clubhouse', 'Gym', 'Swimming Pool', 'Security', 'EV Charging']),
      expectedPrice: 15650000,
      status: 'ACTIVE',
      isFeatured: false,
    },
    {
      propertyCode: 'PROP-CHE-601',
      propertyType: 'Villa/House',
      listingType: 'SALE',
      title: 'Independent 3 BHK Residential House in Adyar',
      description: 'Peaceful residential property with private portico, borewell connection, and close access to Elliot Beach.',
      locationId: createdLocations['Chennai-Adyar'],
      address: '1st Cross Road, Gandhi Nagar, Adyar',
      areaSqFt: 2100,
      bedrooms: 3,
      bathrooms: 3,
      balconies: 1,
      floor: 0,
      totalFloors: 2,
      propertyAge: 8,
      parking: 'Covered',
      furnishing: 'Semi-Furnished',
      constructionStatus: 'Ready to Move',
      amenities: JSON.stringify(['Rainwater Harvesting', 'Private Borewell', 'Covered Car Porch']),
      expectedPrice: 25620000,
      status: 'ACTIVE',
      isFeatured: false,
    },
  ];

  for (const p of properties) {
    await prisma.property.upsert({
      where: { propertyCode: p.propertyCode },
      update: p,
      create: p,
    });
  }
  console.log(`✔ Seeded ${properties.length} commercial property listings.`);

  // 4. Seed Verified Historical Property Transactions
  const transactions = [
    {
      transactionRef: 'TXN-MUM-2026-001',
      propertyType: 'Apartment',
      locationId: createdLocations['Mumbai-Bandra West'],
      localityName: 'Bandra West',
      areaSqFt: 1450,
      bedrooms: 3,
      bathrooms: 3,
      propertyAge: 4,
      floor: 8,
      furnishing: 'Semi-Furnished',
      transactionPrice: 55100000,
      pricePerSqFt: 38000,
      transactionDate: new Date('2026-06-15'),
      source: 'State Land Registry Office',
      verified: true,
    },
    {
      transactionRef: 'TXN-MUM-2026-002',
      propertyType: 'Apartment',
      locationId: createdLocations['Mumbai-Andheri East'],
      localityName: 'Andheri East',
      areaSqFt: 1050,
      bedrooms: 2,
      bathrooms: 2,
      propertyAge: 6,
      floor: 5,
      furnishing: 'Semi-Furnished',
      transactionPrice: 19425000,
      pricePerSqFt: 18500,
      transactionDate: new Date('2026-07-20'),
      source: 'Sub-Registrar Deeds Record',
      verified: true,
    },
    {
      transactionRef: 'TXN-BLR-2026-003',
      propertyType: 'Apartment',
      locationId: createdLocations['Bangalore-Whitefield'],
      localityName: 'Whitefield',
      areaSqFt: 1600,
      bedrooms: 3,
      bathrooms: 3,
      propertyAge: 2,
      floor: 12,
      furnishing: 'Semi-Furnished',
      transactionPrice: 14080000,
      pricePerSqFt: 8800,
      transactionDate: new Date('2026-08-10'),
      source: 'Department of Stamps and Registration',
      verified: true,
    },
    {
      transactionRef: 'TXN-BLR-2026-004',
      propertyType: 'Villa/House',
      locationId: createdLocations['Bangalore-Indiranagar'],
      localityName: 'Indiranagar',
      areaSqFt: 2800,
      bedrooms: 4,
      bathrooms: 4,
      propertyAge: 3,
      floor: 0,
      furnishing: 'Fully-Furnished',
      transactionPrice: 40600000,
      pricePerSqFt: 14500,
      transactionDate: new Date('2026-05-18'),
      source: 'Kaveri Online Services Registry',
      verified: true,
    },
    {
      transactionRef: 'TXN-PUN-2026-005',
      propertyType: 'Apartment',
      locationId: createdLocations['Pune-Baner'],
      localityName: 'Baner',
      areaSqFt: 1200,
      bedrooms: 2,
      bathrooms: 2,
      propertyAge: 4,
      floor: 6,
      furnishing: 'Semi-Furnished',
      transactionPrice: 10680000,
      pricePerSqFt: 8900,
      transactionDate: new Date('2026-07-02'),
      source: 'IGR Maharashtra Records',
      verified: true,
    },
    {
      transactionRef: 'TXN-HYD-2026-006',
      propertyType: 'Apartment',
      locationId: createdLocations['Hyderabad-Gachibowli'],
      localityName: 'Gachibowli',
      areaSqFt: 1550,
      bedrooms: 3,
      bathrooms: 3,
      propertyAge: 2,
      floor: 9,
      furnishing: 'Semi-Furnished',
      transactionPrice: 14105000,
      pricePerSqFt: 9100,
      transactionDate: new Date('2026-08-28'),
      source: 'CARD Telangana Registry',
      verified: true,
    },
  ];

  for (const t of transactions) {
    await prisma.propertyTransaction.upsert({
      where: { transactionRef: t.transactionRef },
      update: t,
      create: t,
    });
  }
  console.log(`✔ Seeded ${transactions.length} verified historical property transactions.`);

  // 5. Seed Website Settings
  await prisma.websiteSetting.upsert({
    where: { id: 'default' },
    update: {},
    create: {
      id: 'default',
      brandName: 'PropVal Analytics',
      heroTitle: 'Enterprise Real Estate Valuation & Market Analytics',
      heroSubtitle: 'Institutional-grade property pricing intelligence combining empirical transactions, hedonic calibration, and locality benchmarks.',
      aboutText: 'PropVal Analytics delivers commercial-grade property valuation and real estate data intelligence for buyers, sellers, brokers, and institutional investors.',
      contactEmail: 'contact@propvalanalytics.com',
      contactPhone: '+91 98765 43210',
      contactAddress: 'Tech Hub Tower, Level 8, Sector 5, Bangalore 560100',
      disclaimerText: 'This valuation estimate is generated from available transaction records and statistical regression heuristics. It does not constitute a formal chartered surveyor legal appraisal.',
    },
  });

  // 6. Seed Sample Initial Leads
  const initialLeads = [
    {
      leadCode: 'LEAD-INIT-001',
      name: 'Aditya Birla Capital Partners',
      phone: '+91 98200 12345',
      email: 'aditya.invest@abcapital.com',
      source: 'Direct Inquire',
      status: 'QUALIFIED',
      notes: 'Institutional inquiry regarding commercial inventory in Worli and Bandra.',
    },
    {
      leadCode: 'LEAD-INIT-002',
      name: 'Vikramaditya Roy',
      phone: '+91 98110 54321',
      email: 'vikram.roy@outlook.com',
      source: 'Valuation Wizard',
      status: 'SITE_VISIT',
      notes: 'Requested on-site assessment for 3BHK flat in Indiranagar Bangalore.',
    },
  ];

  for (const l of initialLeads) {
    await prisma.lead.upsert({
      where: { leadCode: l.leadCode },
      update: l,
      create: l,
    });
  }

  // 7. Seed Property Images
  const allProps = await prisma.property.findMany();
  const imageCount = await prisma.propertyImage.count();
  if (imageCount === 0 && allProps.length > 0) {
    const GENERIC_POOLS = {
      Apartment: [
        'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80',
      ],
      'Villa/House': [
        'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
      ],
      Commercial: [
        'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
      ],
      'Plot/Land': [
        'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
      ],
      Penthouse: [
        'https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80',
      ],
    };

    for (const prop of allProps) {
      const pool = GENERIC_POOLS[prop.propertyType] || GENERIC_POOLS['Apartment'];
      const img1 = pool[prop.id % pool.length];
      const img2 = pool[(prop.id + 1) % pool.length];
      await prisma.propertyImage.create({
        data: {
          propertyId: prop.id,
          imageUrl: img1,
          caption: `${prop.propertyType} Front View`,
          isPrimary: true,
          orderIndex: 0,
        },
      });
      if (img2 && img2 !== img1) {
        await prisma.propertyImage.create({
          data: {
            propertyId: prop.id,
            imageUrl: img2,
            caption: `${prop.propertyType} Interior`,
            isPrimary: false,
            orderIndex: 1,
          },
        });
      }
    }
    console.log('✔ Property images seeded.');
  }

  console.log('✔ Platform database initialization complete!');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

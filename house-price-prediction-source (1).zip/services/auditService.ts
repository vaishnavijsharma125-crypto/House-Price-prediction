import { prisma } from '@/lib/prisma';

export interface AuditLogParams {
  userId?: number | null;
  userEmail?: string | null;
  action: string;
  entity: string;
  entityId?: string | number | null;
  metadata?: any;
  ipAddress?: string | null;
}

export class AuditService {
  public static async log(params: AuditLogParams): Promise<void> {
    try {
      await prisma.auditLog.create({
        data: {
          userId: params.userId || null,
          userEmail: params.userEmail || null,
          action: params.action,
          entity: params.entity,
          entityId: params.entityId ? String(params.entityId) : null,
          metadata: params.metadata ? JSON.stringify(params.metadata) : null,
          ipAddress: params.ipAddress || null,
        },
      });
    } catch (err) {
      console.error('Failed to write audit log:', err);
    }
  }
}

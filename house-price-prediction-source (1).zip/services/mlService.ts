import { ValuationInput } from '@/types';

export interface MLInferenceResult {
  estimatedPrice: number;
  lowEstimate: number;
  highEstimate: number;
  pricePerSqFt: number;
  confidenceScore: number;
  modelVersion: string;
  shapValues?: Record<string, number>;
}

export class MLService {
  private static mlEndpoint = process.env.ML_SERVICE_URL || null;

  /**
   * Evaluates if external Python ML microservice is available
   */
  public static isMLServiceConfigured(): boolean {
    return !!this.mlEndpoint;
  }

  /**
   * Invokes external ML inference API when configured.
   * Returns null if service not configured or unreachable, triggering baseline fallback.
   */
  public static async predictWithML(input: ValuationInput): Promise<MLInferenceResult | null> {
    if (!this.mlEndpoint) return null;

    try {
      const response = await fetch(`${this.mlEndpoint}/predict`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
        signal: AbortSignal.timeout(3500),
      });

      if (!response.ok) return null;
      const data = await response.json();
      return data as MLInferenceResult;
    } catch {
      // Graceful fallback to transparent statistical baseline
      return null;
    }
  }
}

import { prisma } from '@/lib/prisma';
import {
  ValuationInput,
  ValuationResult,
  ValuationFactor,
  ComparableProperty,
} from '@/types';

export class ValuationService {
  /**
   * Process a customer valuation request:
   * 1. Calculates market value using transparent empirical & attribute heuristics
   * 2. Retrieves actual comparable listings & transactions from database
   * 3. Stores ValuationRequest, Prediction, and Lead in relational database
   * 4. Returns transparent valuation report
   */
  public static async calculateValuation(
    input: ValuationInput
  ): Promise<ValuationResult> {
    const {
      propertyType,
      city,
      locality,
      areaSqFt,
      bedrooms,
      bathrooms,
      balconies,
      propertyAge,
      floor,
      totalFloors,
      parking,
      furnishing,
      constructionStatus,
      amenities,
      contactName,
      contactEmail,
      contactPhone,
    } = input;

    // 1. Locate or match location record
    let locationRecord = await prisma.location.findFirst({
      where: {
        city: { equals: city.trim() },
        locality: { equals: locality.trim() },
        isActive: true,
      },
    });

    if (!locationRecord) {
      // Fallback search by city or locality partial
      locationRecord = await prisma.location.findFirst({
        where: {
          OR: [
            { city: { contains: city.trim() } },
            { locality: { contains: locality.trim() } },
          ],
          isActive: true,
        },
      });
    }

    // Default city rate if no location record in database yet
    let baseRatePerSqFt = locationRecord?.avgPricePerSqFt || 8500;
    const marketTier = locationRecord?.marketTier || 'Tier 1';

    // 2. Query actual historical transactions in database for this locality
    const recentTransactions = await prisma.propertyTransaction.findMany({
      where: {
        OR: [
          { localityName: { contains: locality.trim() } },
          { locationId: locationRecord?.id },
        ],
      },
      orderBy: { transactionDate: 'desc' },
      take: 10,
    });

    let dataPointsUsed = recentTransactions.length;
    let empiricalTransactionRate = 0;

    if (recentTransactions.length > 0) {
      const totalTransPrice = recentTransactions.reduce((acc, t) => acc + t.transactionPrice, 0);
      const totalTransArea = recentTransactions.reduce((acc, t) => acc + t.areaSqFt, 0);
      if (totalTransArea > 0) {
        empiricalTransactionRate = Math.round(totalTransPrice / totalTransArea);
        // Blend 65% verified historical transactions + 35% location baseline
        baseRatePerSqFt = Math.round(empiricalTransactionRate * 0.65 + baseRatePerSqFt * 0.35);
      }
    }

    // 3. Multipliers & Attribute Adjustments
    const factors: ValuationFactor[] = [];

    // Property Type
    let typeMultiplier = 1.0;
    if (propertyType === 'Villa/House') typeMultiplier = 1.25;
    else if (propertyType === 'Commercial') typeMultiplier = 1.45;
    else if (propertyType === 'Penthouse') typeMultiplier = 1.50;
    else if (propertyType === 'Plot/Land') typeMultiplier = 0.90;

    factors.push({
      factor: 'Property Typology',
      impact: typeMultiplier >= 1.1 ? 'positive' : typeMultiplier < 1.0 ? 'negative' : 'neutral',
      impactPercent: Math.round((typeMultiplier - 1) * 100),
      description: `${propertyType} specification adjustment applied.`,
    });

    // Market Tier
    let tierMultiplier = 1.0;
    if (marketTier === 'Luxury') tierMultiplier = 1.35;
    else if (marketTier === 'Prime') tierMultiplier = 1.20;
    else if (marketTier === 'Tier 2') tierMultiplier = 0.90;

    factors.push({
      factor: 'Locality & Market Tier',
      impact: tierMultiplier > 1.0 ? 'positive' : tierMultiplier < 1.0 ? 'negative' : 'neutral',
      impactPercent: Math.round((tierMultiplier - 1) * 100),
      description: `${locality} categorized under ${marketTier} real-estate density.`,
    });

    // Age Depreciation
    let ageMultiplier = 1.0;
    if (propertyType !== 'Plot/Land') {
      const depreciation = Math.min(0.30, propertyAge * 0.0075);
      ageMultiplier = Math.max(0.70, 1 - depreciation);
      factors.push({
        factor: 'Structural Age & Wear',
        impact: propertyAge > 10 ? 'negative' : propertyAge <= 3 ? 'positive' : 'neutral',
        impactPercent: -Math.round(depreciation * 100),
        description: `${propertyAge} years building age (${Math.round(depreciation * 100)}% depreciation).`,
      });
    }

    // Floor Elevation Bonus
    let floorBonus = 0;
    if (floor > 4 && propertyType !== 'Plot/Land' && propertyType !== 'Villa/House') {
      floorBonus = Math.min(0.12, (floor - 4) * 0.015);
      factors.push({
        factor: 'Floor Elevation',
        impact: 'positive',
        impactPercent: Math.round(floorBonus * 100),
        description: `Floor level ${floor} of ${totalFloors} offers scenic elevation value.`,
      });
    }

    // Furnishing
    let furnishingMultiplier = 1.0;
    if (furnishing === 'Fully-Furnished') furnishingMultiplier = 1.10;
    else if (furnishing === 'Semi-Furnished') furnishingMultiplier = 1.04;

    factors.push({
      factor: 'Furnishing Condition',
      impact: furnishingMultiplier > 1.0 ? 'positive' : 'neutral',
      impactPercent: Math.round((furnishingMultiplier - 1) * 100),
      description: `${furnishing} asset standard.`,
    });

    // Parking flat value
    const hasParking = parking !== 'No';
    const parkingBonusValue = hasParking ? Math.round(baseRatePerSqFt * 25) : 0;
    if (hasParking) {
      factors.push({
        factor: 'Dedicated Parking',
        impact: 'positive',
        impactPercent: 4,
        description: `${parking} parking space allocation included in valuation.`,
      });
    }

    // Amenities (Gym, Swimming pool, Clubhouse, 24/7 Security, Power Backup)
    let amenitiesBonus = 0;
    if (amenities && amenities.length > 0) {
      amenitiesBonus = Math.min(0.10, amenities.length * 0.02);
      factors.push({
        factor: 'Lifestyle Amenities',
        impact: 'positive',
        impactPercent: Math.round(amenitiesBonus * 100),
        description: `${amenities.length} premium lifestyle amenities verified.`,
      });
    }

    // Layout Utility
    const expectedBHK = Math.max(1, Math.round(areaSqFt / 550));
    const bhkDiff = bedrooms - expectedBHK;
    const layoutMultiplier = 1 + Math.max(-0.10, Math.min(0.12, bhkDiff * 0.03));

    // Combine effective square-foot rate
    const combinedRate =
      baseRatePerSqFt *
      typeMultiplier *
      tierMultiplier *
      ageMultiplier *
      furnishingMultiplier *
      layoutMultiplier *
      (1 + floorBonus + amenitiesBonus);

    const calculatedPrice = Math.round(areaSqFt * combinedRate + parkingBonusValue);
    const estimatedPrice = Math.round(calculatedPrice / 1000) * 1000;
    const pricePerSqFt = Math.round(estimatedPrice / Math.max(1, areaSqFt));

    const lowEstimate = Math.round((estimatedPrice * 0.94) / 1000) * 1000;
    const highEstimate = Math.round((estimatedPrice * 1.07) / 1000) * 1000;

    const confidenceLevel: 'High' | 'Medium' | 'Moderate' =
      recentTransactions.length >= 3 ? 'High' : recentTransactions.length >= 1 ? 'Medium' : 'Moderate';

    // 4. Fetch Real Comparable Properties from Database (actual records only!)
    const areaMin = areaSqFt * 0.75;
    const areaMax = areaSqFt * 1.35;

    const dbComparables = await prisma.property.findMany({
      where: {
        isDeleted: false,
        status: 'ACTIVE',
        areaSqFt: { gte: areaMin, lte: areaMax },
      },
      include: { location: true },
      take: 4,
      orderBy: { createdAt: 'desc' },
    });

    dataPointsUsed += dbComparables.length;

    const comparables: ComparableProperty[] = [];

    // Add active listings as comparables
    dbComparables.forEach((c) => {
      comparables.push({
        id: c.id,
        propertyCode: c.propertyCode,
        propertyType: c.propertyType,
        locality: c.location?.locality || locality,
        areaSqFt: c.areaSqFt,
        bedrooms: c.bedrooms,
        price: c.expectedPrice,
        pricePerSqFt: Math.round(c.expectedPrice / Math.max(1, c.areaSqFt)),
        date: c.createdAt.toISOString().split('T')[0],
        type: 'listing',
      });
    });

    // Add recent verified transactions as comparables
    recentTransactions.slice(0, 2).forEach((t) => {
      comparables.push({
        id: t.id,
        propertyType: t.propertyType,
        locality: t.localityName,
        areaSqFt: t.areaSqFt,
        bedrooms: t.bedrooms,
        price: t.transactionPrice,
        pricePerSqFt: t.pricePerSqFt,
        date: t.transactionDate.toISOString().split('T')[0],
        type: 'transaction',
      });
    });

    // 5. Save ValuationRequest to Database
    const requestRef = `VAL-${Date.now().toString(36).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

    const savedValuation = await prisma.valuationRequest.create({
      data: {
        requestRef,
        propertyType,
        locationId: locationRecord?.id || null,
        localityText: locality.trim(),
        areaSqFt,
        bedrooms,
        bathrooms,
        balconies,
        propertyAge,
        floor,
        totalFloors,
        parking,
        furnishing,
        constructionStatus,
        amenities: JSON.stringify(amenities || []),
        contactName: contactName.trim(),
        contactEmail: contactEmail.trim().toLowerCase(),
        contactPhone: contactPhone.trim(),
        status: 'COMPLETED',
      },
    });

    // 6. Save Prediction to Database
    const modelVersion = 'valuation-v1.2-baseline';
    await prisma.prediction.create({
      data: {
        valuationRequestId: savedValuation.id,
        estimatedPrice,
        lowEstimate,
        highEstimate,
        pricePerSqFt,
        confidenceLevel,
        modelVersion,
        factorsJson: JSON.stringify(factors),
        comparablesJson: JSON.stringify(comparables),
        dataPointsUsed,
      },
    });

    // 7. Create Commercial Lead in Database
    const leadCode = `LEAD-${Date.now().toString(36).toUpperCase()}-${Math.floor(10 + Math.random() * 90)}`;
    await prisma.lead.create({
      data: {
        leadCode,
        name: contactName.trim(),
        email: contactEmail.trim().toLowerCase(),
        phone: contactPhone.trim(),
        valuationRequestId: savedValuation.id,
        source: 'Valuation Wizard',
        status: 'NEW',
        notes: `Customer requested valuation for ${propertyType} in ${locality}, ${city} (${areaSqFt} Sq.Ft, est. ₹${estimatedPrice.toLocaleString('en-IN')})`,
      },
    });

    return {
      estimatedPrice,
      lowEstimate,
      highEstimate,
      pricePerSqFt,
      confidenceLevel,
      factors,
      comparables,
      dataPointsUsed,
      modelVersion,
      valuationDate: new Date().toISOString(),
      requestRef,
      leadCode,
    };
  }
}

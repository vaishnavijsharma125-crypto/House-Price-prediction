'use client';

import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Phone,
  Mail,
  Building,
  Calendar,
  ExternalLink,
  Edit3,
  Trash2,
  X,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  AlertCircle,
  FileText,
  UserCheck,
  MapPin,
  Tag,
} from 'lucide-react';
import { formatIndianCurrency, formatDate } from '@/lib/utils';

const STATUS_OPTIONS = [
  { value: 'ALL', label: 'All Statuses' },
  { value: 'NEW', label: 'New Lead', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  { value: 'CONTACTED', label: 'Contacted', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  { value: 'QUALIFIED', label: 'Qualified', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
  { value: 'SITE_VISIT_SCHEDULED', label: 'Site Visit', color: 'bg-purple-50 text-purple-700 border-purple-200' },
  { value: 'NEGOTIATION', label: 'Negotiation', color: 'bg-cyan-50 text-cyan-700 border-cyan-200' },
  { value: 'CONVERTED', label: 'Converted', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  { value: 'LOST', label: 'Lost', color: 'bg-rose-50 text-rose-700 border-rose-200' },
];

export default function AdminLeadsPage() {
  const [leads, setLeads] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Selected lead for detail modal
  const [selectedLead, setSelectedLead] = useState<any | null>(null);
  const [editingNotes, setEditingNotes] = useState('');
  const [editingStatus, setEditingStatus] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchLeads = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '15',
        search,
        status: statusFilter,
      });

      const res = await fetch(`/api/leads?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch leads from server');
      const data = await res.json();

      setLeads(data.leads || []);
      setTotalPages(data.pagination.totalPages || 1);
      setTotalCount(data.pagination.total || 0);
    } catch (err: any) {
      setError(err.message || 'Error loading leads');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeads();
  }, [page, statusFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchLeads();
  };

  const openLeadDetails = (lead: any) => {
    setSelectedLead(lead);
    setEditingNotes(lead.notes || '');
    setEditingStatus(lead.status);
  };

  const handleUpdateLead = async (leadId: number, newStatus: string, notes?: string) => {
    setIsUpdating(true);
    try {
      const res = await fetch(`/api/leads/${leadId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: newStatus,
          notes: notes !== undefined ? notes : editingNotes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update lead');

      showToast(`Lead updated to ${newStatus}`);
      if (selectedLead && selectedLead.id === leadId) {
        setSelectedLead({ ...selectedLead, status: newStatus, notes: notes !== undefined ? notes : editingNotes });
      }
      fetchLeads();
    } catch (err: any) {
      alert(`Update error: ${err.message}`);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDeleteLead = async (leadId: number) => {
    if (!confirm('Are you sure you want to permanently delete this lead?')) return;
    try {
      const res = await fetch(`/api/leads/${leadId}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete lead');

      showToast('Lead deleted successfully');
      setSelectedLead(null);
      fetchLeads();
    } catch (err: any) {
      alert(`Delete error: ${err.message}`);
    }
  };

  const getStatusBadge = (status: string) => {
    const config = STATUS_OPTIONS.find((s) => s.value === status) || {
      label: status,
      color: 'bg-slate-100 text-slate-700 border-slate-200',
    };
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${config.color}`}>
        {config.label}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-xl shadow-lg flex items-center space-x-2 text-sm font-medium animate-bounce">
          <CheckCircle2 className="w-5 h-5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-8 h-8 text-sky-600" />
            <span>Customer Leads & Inquiries</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Commercial pipeline generated from valuation requests, property inquiries, and platform consultations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold text-slate-700">
            Total Leads: {totalCount}
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 items-center justify-between">
        <form onSubmit={handleSearchSubmit} className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by customer name, phone, email, or lead code..."
            className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all text-slate-800"
          />
        </form>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Filter className="w-4 h-4 text-slate-500" />
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="text-xs py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
            >
              {STATUS_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => {
              setSearch('');
              setStatusFilter('ALL');
              setPage(1);
            }}
            className="px-3 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Leads Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-20 text-center">
            <div className="w-8 h-8 border-3 border-sky-500/30 border-t-sky-500 rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs text-slate-500">Querying commercial lead database...</p>
          </div>
        ) : error ? (
          <div className="py-12 text-center text-rose-600 space-y-2">
            <AlertCircle className="w-8 h-8 mx-auto" />
            <p className="text-sm font-semibold">{error}</p>
          </div>
        ) : leads.length === 0 ? (
          <div className="py-16 text-center text-slate-500 space-y-2">
            <Users className="w-10 h-10 mx-auto text-slate-300" />
            <p className="text-sm font-semibold">No customer leads found</p>
            <p className="text-xs text-slate-400">Leads captured via valuation requests will appear here automatically.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4">Lead ID & Customer</th>
                  <th className="py-3 px-4">Contact Info</th>
                  <th className="py-3 px-4">Property Context</th>
                  <th className="py-3 px-4">Valuation Est.</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {leads.map((lead) => {
                  const req = lead.valuationRequest;
                  const pred = req?.prediction;
                  return (
                    <tr key={lead.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{lead.name}</div>
                        <div className="font-mono text-[10px] text-slate-400">{lead.leadCode}</div>
                        <span className="inline-block mt-1 text-[10px] font-medium px-2 py-0.5 bg-slate-100 text-slate-600 rounded">
                          {lead.source}
                        </span>
                      </td>
                      <td className="py-3 px-4 space-y-1">
                        <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                          <Phone className="w-3.5 h-3.5 text-slate-400" />
                          <span>{lead.phone}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                          <Mail className="w-3.5 h-3.5 text-slate-400" />
                          <span>{lead.email}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {req ? (
                          <div>
                            <div className="font-semibold text-slate-900">
                              {req.propertyType} • {req.location}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {req.area} Sq.Ft • {req.bedrooms} BHK
                            </div>
                          </div>
                        ) : lead.property ? (
                          <div>
                            <div className="font-semibold text-slate-900">{lead.property.title}</div>
                            <div className="text-[11px] text-slate-500">{lead.property.location}</div>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">General Consultation</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {pred ? (
                          <div>
                            <div className="font-bold text-slate-900">
                              {formatIndianCurrency(pred.predictedPrice)}
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              Conf: {Math.round((pred.confidenceScore || 0.85) * 100)}%
                            </div>
                          </div>
                        ) : lead.property ? (
                          <div className="font-bold text-slate-900">
                            {formatIndianCurrency(lead.property.price)}
                          </div>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {getStatusBadge(lead.status)}
                      </td>
                      <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                        {formatDate(lead.createdAt)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => openLeadDetails(lead)}
                            className="p-1.5 text-sky-600 hover:bg-sky-50 rounded-lg transition-colors"
                            title="View Full Profile & Update"
                          >
                            <FileText className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteLead(lead.id)}
                            className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Delete Lead"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {!loading && totalPages > 1 && (
          <div className="p-4 border-t border-slate-200 flex items-center justify-between">
            <span className="text-xs text-slate-500">
              Page {page} of {totalPages} ({totalCount} total leads)
            </span>
            <div className="flex items-center gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage(page - 1)}
                className="p-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage(page + 1)}
                className="p-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Lead Details & Status Modal */}
      {selectedLead && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                  {selectedLead.leadCode}
                </span>
                <h3 className="text-lg font-bold text-slate-900 leading-tight">
                  Lead Profile: {selectedLead.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedLead(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700">
              {/* Customer Contact Box */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Direct Phone</div>
                  <div className="font-semibold text-slate-900 text-sm mt-0.5 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-sky-600" />
                    <span>{selectedLead.phone}</span>
                  </div>
                </div>

                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Email Address</div>
                  <div className="font-semibold text-slate-900 text-sm mt-0.5 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-sky-600" />
                    <span>{selectedLead.email}</span>
                  </div>
                </div>

                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Lead Source</div>
                  <div className="font-medium text-slate-800 mt-0.5">{selectedLead.source}</div>
                </div>

                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Creation Date</div>
                  <div className="font-medium text-slate-800 mt-0.5">{formatDate(selectedLead.createdAt)}</div>
                </div>
              </div>

              {/* Valuation Details (if applicable) */}
              {selectedLead.valuationRequest && (
                <div className="p-4 rounded-xl border border-sky-100 bg-sky-50/50 space-y-3">
                  <div className="font-bold text-sky-950 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Building className="w-4 h-4 text-sky-600" />
                      <span>Associated Valuation Request</span>
                    </span>
                    {selectedLead.valuationRequest.prediction && (
                      <span className="text-sm font-extrabold text-sky-900">
                        {formatIndianCurrency(selectedLead.valuationRequest.prediction.predictedPrice)}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-[11px]">
                    <div>
                      <span className="text-slate-400 block">Typology:</span>
                      <span className="font-semibold text-slate-800">{selectedLead.valuationRequest.propertyType}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Locality:</span>
                      <span className="font-semibold text-slate-800">{selectedLead.valuationRequest.location}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Area:</span>
                      <span className="font-semibold text-slate-800">{selectedLead.valuationRequest.area} Sq.Ft</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Bedrooms / Baths:</span>
                      <span className="font-semibold text-slate-800">
                        {selectedLead.valuationRequest.bedrooms} BHK / {selectedLead.valuationRequest.bathrooms} Bath
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Property Age:</span>
                      <span className="font-semibold text-slate-800">{selectedLead.valuationRequest.propertyAge} Years</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Furnishing:</span>
                      <span className="font-semibold text-slate-800">{selectedLead.valuationRequest.furnishing}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Pipeline Status Editor */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-900 block">Pipeline Status</label>
                <select
                  value={editingStatus}
                  onChange={(e) => setEditingStatus(e.target.value)}
                  className="w-full py-2.5 px-3 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  {STATUS_OPTIONS.filter((o) => o.value !== 'ALL').map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Internal Admin Notes */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-900 block">Consultation / Sales Notes</label>
                <textarea
                  rows={4}
                  value={editingNotes}
                  onChange={(e) => setEditingNotes(e.target.value)}
                  placeholder="Record customer preferences, site visit schedule, agreed price negotiation notes, or next action items..."
                  className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <button
                type="button"
                onClick={() => handleDeleteLead(selectedLead.id)}
                className="px-4 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
              >
                Delete Lead
              </button>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedLead(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isUpdating}
                  onClick={() => handleUpdateLead(selectedLead.id, editingStatus, editingNotes)}
                  className="px-5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors shadow-xs disabled:opacity-50"
                >
                  {isUpdating ? 'Saving...' : 'Save Updates'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

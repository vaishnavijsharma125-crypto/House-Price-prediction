'use client';

import React, { useState, useEffect } from 'react';
import {
  History,
  Search,
  Trash2,
  Eye,
  RefreshCw,
  X,
  ChevronLeft,
  ChevronRight,
  Calculator,
  Calendar,
  Layers,
  MapPin,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { formatIndianCurrency, formatNumber, formatDate } from '@/lib/utils';

export default function AdminPredictionsPage() {
  const [predictions, setPredictions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Selected item for modal
  const [selectedPrediction, setSelectedPrediction] = useState<any | null>(null);
  const [predictionToDelete, setPredictionToDelete] = useState<any | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchPredictions = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '12',
        search,
      });

      const res = await fetch(`/api/predictions?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to retrieve prediction logs');
      const data = await res.json();

      setPredictions(data.predictions || []);
      setTotalPages(data.pagination?.totalPages || 1);
      setTotalCount(data.pagination?.total || 0);
    } catch (err: any) {
      setError(err.message || 'Error communicating with database');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPredictions();
  }, [page]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchPredictions();
  };

  const handleDeletePrediction = async () => {
    if (!predictionToDelete) return;
    setIsDeleting(true);
    try {
      const res = await fetch(
        `/api/predictions?predictionId=${encodeURIComponent(predictionToDelete.predictionId)}`,
        { method: 'DELETE' }
      );
      if (!res.ok) throw new Error('Failed to delete prediction record');
      setPredictionToDelete(null);
      fetchPredictions();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleClearAll = async () => {
    if (!confirm('Are you sure you want to clear all logged prediction history?')) return;
    setIsDeleting(true);
    try {
      const res = await fetch('/api/predictions?action=clearAll', {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('Failed to clear predictions');
      fetchPredictions();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Prediction Audit Trail
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Historical log of all price estimations generated via the prediction engine.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {predictions.length > 0 && (
            <button
              onClick={handleClearAll}
              disabled={isDeleting}
              className="px-3.5 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl transition-colors"
            >
              Clear All Logs
            </button>
          )}
          <button
            onClick={() => fetchPredictions()}
            className="p-2 border border-slate-200 hover:bg-slate-50 rounded-xl"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by Prediction ID, location, or type..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-semibold"
          >
            Search
          </button>
        </form>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-16 text-center space-y-3">
            <div className="w-8 h-8 border-3 border-sky-600/30 border-t-sky-600 rounded-full animate-spin mx-auto" />
            <p className="text-xs text-slate-500 font-medium">Loading prediction history...</p>
          </div>
        ) : error ? (
          <div className="p-8 text-center text-rose-600 text-xs">{error}</div>
        ) : predictions.length === 0 ? (
          <div className="p-16 text-center space-y-2">
            <History className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700">No prediction history recorded</p>
            <p className="text-xs text-slate-500">
              Predictions generated on the public predictor page will automatically log here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                <tr>
                  <th className="py-3 px-4">Prediction ID</th>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4">Area (Sq.Ft)</th>
                  <th className="py-3 px-4">BHK</th>
                  <th className="py-3 px-4">Predicted Price</th>
                  <th className="py-3 px-4">Price / Sq.Ft</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {predictions.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {p.predictionId}
                    </td>
                    <td className="py-3 px-4 text-slate-500">{formatDate(p.createdAt)}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[11px] bg-slate-100 font-medium text-slate-800 border border-slate-200">
                        {p.propertyType}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-900">{p.location}</td>
                    <td className="py-3 px-4 font-mono">{formatNumber(p.area)}</td>
                    <td className="py-3 px-4">{p.bedrooms > 0 ? `${p.bedrooms} BHK` : 'N/A'}</td>
                    <td className="py-3 px-4 font-bold text-emerald-700">
                      {formatIndianCurrency(p.predictedPrice)}
                    </td>
                    <td className="py-3 px-4 text-sky-700 font-semibold">
                      ₹{Math.round(p.pricePerSqFt).toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 px-4 text-right space-x-1">
                      <button
                        onClick={() => setSelectedPrediction(p)}
                        className="p-1.5 text-slate-500 hover:text-sky-600 hover:bg-sky-50 rounded-lg transition-colors"
                        title="View Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setPredictionToDelete(p)}
                        className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <div>
            Showing {predictions.length} of {totalCount} records (Page {page} of {totalPages})
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 disabled:opacity-50"
            >
              Previous
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 disabled:opacity-50"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* PREDICTION DETAILS MODAL */}
      {selectedPrediction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <span className="text-xs font-mono font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                  {selectedPrediction.predictionId}
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-1">
                  Prediction Details & Attribution
                </h3>
              </div>
              <button
                onClick={() => setSelectedPrediction(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-sky-50 p-5 rounded-2xl border border-sky-100 flex items-center justify-between">
              <div>
                <span className="text-xs uppercase font-bold text-sky-800">
                  Calculated Price
                </span>
                <div className="text-2xl font-extrabold text-slate-900">
                  {formatIndianCurrency(selectedPrediction.predictedPrice)}
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-500 font-medium">Confidence Range</span>
                <div className="text-xs font-bold text-slate-800">
                  {formatIndianCurrency(selectedPrediction.priceRangeMin)} –{' '}
                  {formatIndianCurrency(selectedPrediction.priceRangeMax)}
                </div>
              </div>
            </div>

            {/* Input Specs */}
            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-400">Type: </span>
                <strong className="text-slate-800">{selectedPrediction.propertyType}</strong>
              </div>
              <div>
                <span className="text-slate-400">Location: </span>
                <strong className="text-slate-800">{selectedPrediction.location}</strong>
              </div>
              <div>
                <span className="text-slate-400">Area: </span>
                <strong className="text-slate-800">{selectedPrediction.area} Sq.Ft</strong>
              </div>
              <div>
                <span className="text-slate-400">Layout: </span>
                <strong className="text-slate-800">
                  {selectedPrediction.bedrooms} BHK / {selectedPrediction.bathrooms} Bath
                </strong>
              </div>
              <div>
                <span className="text-slate-400">Locality: </span>
                <strong className="text-slate-800">{selectedPrediction.localityRating} / 10</strong>
              </div>
              <div>
                <span className="text-slate-400">Age: </span>
                <strong className="text-slate-800">{selectedPrediction.propertyAge} Yrs</strong>
              </div>
              <div>
                <span className="text-slate-400">Furnishing: </span>
                <strong className="text-slate-800">{selectedPrediction.furnishing}</strong>
              </div>
              <div>
                <span className="text-slate-400">Parking: </span>
                <strong className="text-slate-800">{selectedPrediction.parking}</strong>
              </div>
            </div>

            {/* Influencing factors if present */}
            {selectedPrediction.factors && selectedPrediction.factors.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase text-slate-500">
                  Attribution Multipliers
                </h4>
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {selectedPrediction.factors.map((f: any, idx: number) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg border border-slate-100 bg-white text-xs flex justify-between items-center"
                    >
                      <div>
                        <div className="font-semibold text-slate-800">{f.name}</div>
                        <div className="text-[11px] text-slate-500">{f.description}</div>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          f.impact === 'positive'
                            ? 'bg-emerald-100 text-emerald-800'
                            : f.impact === 'negative'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {f.impact}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
              <span>Timestamp: {formatDate(selectedPrediction.createdAt)}</span>
              <button
                onClick={() => setSelectedPrediction(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl font-semibold hover:bg-slate-800"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {predictionToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              Delete Prediction Record?
            </h3>
            <p className="text-xs text-slate-500">
              Are you sure you want to remove audit log{' '}
              <strong className="font-mono text-slate-800">
                {predictionToDelete.predictionId}
              </strong>
              ?
            </p>
            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setPredictionToDelete(null)}
                className="px-4 py-2 border rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleDeletePrediction}
                disabled={isDeleting}
                className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-semibold hover:bg-rose-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

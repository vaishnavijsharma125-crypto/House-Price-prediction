'use client';

import React, { useState, useEffect } from 'react';
import {
  Database,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  HardDrive,
  ShieldCheck,
  AlertCircle,
  Palette,
  Sparkles,
  Check,
} from 'lucide-react';
import { useTheme, THEMES } from '@/components/ThemeProvider';

export default function AdminSettingsPage() {
  const { theme, setTheme } = useTheme();
  const [savingTheme, setSavingTheme] = useState(false);
  const [importingDemo, setImportingDemo] = useState(false);
  const [uploadingCsv, setUploadingCsv] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [importStats, setImportStats] = useState<any | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4500);
  };

  const handleApplyAndSaveTheme = async (themeId: string) => {
    setSavingTheme(true);
    setErrorMessage(null);
    try {
      // 1. Instantly switch client visual theme
      setTheme(themeId);

      // 2. Persist to database via /api/settings
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ activeTheme: themeId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to persist theme setting');

      const found = THEMES.find((t) => t.id === themeId);
      showToast(`Visual Theme updated to "${found?.name}" and saved to database.`);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error saving theme');
    } finally {
      setSavingTheme(false);
    }
  };

  // 1. IMPORT DEMO DATA
  const handleImportDemoData = async (reset: boolean = false) => {
    if (reset && !confirm('This will purge all existing property records and re-seed the standard demo dataset. Continue?')) {
      return;
    }
    setImportingDemo(true);
    setErrorMessage(null);
    try {
      const res = await fetch(`/api/admin/demo-data?reset=${reset}`, {
        method: 'POST',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to populate demo data');

      showToast(data.message || 'Demo dataset populated successfully.');
    } catch (err: any) {
      setErrorMessage(err.message || 'Error executing demo import');
    } finally {
      setImportingDemo(false);
    }
  };

  // 2. EXPORT DATA (CSV)
  const handleExportCsv = async () => {
    try {
      const res = await fetch('/api/admin/export');
      if (!res.ok) throw new Error('Failed to generate export file');

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `property_dataset_${Date.now()}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      showToast('Dataset exported as CSV successfully.');
    } catch (err: any) {
      alert(`Export error: ${err.message}`);
    }
  };

  // 3. UPLOAD & IMPORT CSV
  const handleCsvUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      alert('Please select a valid CSV file first.');
      return;
    }

    setUploadingCsv(true);
    setErrorMessage(null);
    setImportStats(null);

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);

      const res = await fetch('/api/admin/import', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to process CSV file');
      }

      setImportStats(data);
      showToast(data.message || 'CSV records imported successfully.');
      setSelectedFile(null);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error importing CSV data');
    } finally {
      setUploadingCsv(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center space-x-3 text-xs font-semibold animate-in slide-in-from-bottom duration-300">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-slate-200 pb-6">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Data Import / Export & System Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Utilities to manage demo property data, download CSV backups, and upload batch property files.
        </p>
      </div>

      {errorMessage && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold block">Operation Failed</span>
            <span>{errorMessage}</span>
          </div>
        </div>
      )}

      {/* Platform Theme & Appearance Engine (5 Commercial Color Profiles) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Palette className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  Platform Theme & Appearance Engine
                </h2>
                <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  5 Color Profiles
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Switch platform brand atmosphere across entire website. Applied live and stored in the database.
              </p>
            </div>
          </div>

          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span>Current Active Theme:</span>
            <span className="font-bold text-amber-400 px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700">
              {THEMES.find((t) => t.id === theme)?.name || theme}
            </span>
          </div>
        </div>

        {/* 5 Theme Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {THEMES.map((t) => {
            const isActive = theme === t.id;
            return (
              <div
                key={t.id}
                onClick={() => !savingTheme && handleApplyAndSaveTheme(t.id)}
                className={`relative p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between group ${
                  isActive
                    ? 'bg-slate-800/90 border-amber-400 shadow-xl shadow-amber-500/10 ring-2 ring-amber-400/40'
                    : 'bg-slate-950/60 hover:bg-slate-800/50 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className="w-5 h-5 rounded-full shadow-md border border-white/20"
                      style={{ backgroundColor: t.primaryColor }}
                    />
                    <span className="text-[10px] font-semibold text-slate-400 px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800">
                      {t.badge.split('•')[0].trim()}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                    {t.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {t.subtitle}
                  </p>

                  {/* Micro Visual Preview */}
                  <div className="mt-4 p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: t.primaryColor }}
                      />
                      <span className="text-slate-400">Accent: <code className="text-slate-300 font-mono">{t.primaryColor}</code></span>
                    </div>
                    <div
                      className="px-2 py-0.5 rounded text-[10px] font-bold text-white"
                      style={{ backgroundColor: t.primaryColor }}
                    >
                      Sample
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  {isActive ? (
                    <span className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
                      <Check className="w-4 h-4" /> Active System Theme
                    </span>
                  ) : (
                    <span className="text-xs font-medium text-slate-500 group-hover:text-slate-300 transition-colors">
                      Click to Apply & Save
                    </span>
                  )}
                  {isActive && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card 1: Import Demo Data */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center font-bold">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Import / Seed Demo Dataset
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed mt-1">
                Populates the SQLite database with 40+ realistic property records across Mumbai, Delhi, Bangalore, Pune, Hyderabad, Chennai, Kolkata, and Ahmedabad.
              </p>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900">
              <span className="font-bold">Dataset Notice:</span> All seeded records are labeled as <code className="bg-white px-1 py-0.5 rounded font-mono">isDemo: true</code>.
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-3">
            <button
              onClick={() => handleImportDemoData(false)}
              disabled={importingDemo}
              className="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-semibold shadow-xs disabled:opacity-50 flex items-center gap-2"
            >
              {importingDemo ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Importing...</span>
                </>
              ) : (
                <>
                  <Database className="w-3.5 h-3.5" />
                  <span>Import Missing Demo Records</span>
                </>
              )}
            </button>

            <button
              onClick={() => handleImportDemoData(true)}
              disabled={importingDemo}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold disabled:opacity-50"
            >
              Reset & Re-Seed All
            </button>
          </div>
        </div>

        {/* Card 2: Export Data (CSV) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Export Property Dataset (CSV)
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed mt-1">
                Download the complete live database records as a standardized CSV file for offline review, spreadsheets, or statistical analysis.
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
              Includes: <code className="text-slate-800 font-mono">propertyId, type, location, area, bedrooms, bathrooms, floors, age, price, rating</code>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={handleExportCsv}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>Download Dataset as CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* Card 3: Batch CSV Import */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-5">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Upload className="w-5 h-5 text-indigo-600" />
          <h2 className="text-base font-bold text-slate-900">
            Batch Property CSV Import
          </h2>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Upload an external CSV file containing property rows. The system verifies required columns (<code className="bg-slate-100 px-1 py-0.5 rounded font-mono">propertyType, location, area, price</code>) and validates numeric bounds before insertion.
        </p>

        <form onSubmit={handleCsvUpload} className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <input
              type="file"
              accept=".csv"
              onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
              className="text-xs text-slate-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100 cursor-pointer"
            />

            <button
              type="submit"
              disabled={uploadingCsv || !selectedFile}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs disabled:opacity-50 flex items-center gap-2"
            >
              {uploadingCsv ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Validating & Importing...</span>
                </>
              ) : (
                <>
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload & Import CSV</span>
                </>
              )}
            </button>
          </div>
        </form>

        {importStats && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 space-y-1">
            <div className="font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{importStats.message}</span>
            </div>
            {importStats.stats && (
              <div>
                Inserted: {importStats.stats.inserted} | Updated: {importStats.stats.updated} | Skipped: {importStats.stats.skipped}
              </div>
            )}
            {importStats.errors && importStats.errors.length > 0 && (
              <div className="pt-2 text-rose-700">
                <span className="font-semibold">Validation warnings:</span>
                <ul className="list-disc pl-4 text-[11px] mt-1 space-y-0.5">
                  {importStats.errors.map((err: string, i: number) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>

      {/* System Technical Specifications */}
      <div className="bg-slate-900 text-slate-300 p-6 rounded-2xl border border-slate-800 space-y-3 text-xs">
        <div className="flex items-center gap-2 text-white font-bold">
          <HardDrive className="w-4 h-4 text-sky-400" />
          <span>Persistent Storage & Environment Diagnostics</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1 font-mono text-[11px]">
          <div>
            <span className="text-slate-500 block">Database URL:</span>
            <span className="text-emerald-400">file:./dev.db (SQLite)</span>
          </div>
          <div>
            <span className="text-slate-500 block">ORM Layer:</span>
            <span className="text-sky-400">Prisma Client v5.22</span>
          </div>
          <div>
            <span className="text-slate-500 block">Session Security:</span>
            <span className="text-amber-400">JWT + HTTP-Only Cookie</span>
          </div>
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState, useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
} from 'recharts';
import {
  BarChart3,
  RefreshCw,
  Building,
  History,
  TrendingUp,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { formatIndianCurrency, formatNumber } from '@/lib/utils';

const COLORS = ['#0284c7', '#3b82f6', '#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'];

export default function AdminAnalyticsPage() {
  const [data, setData] = useState<any | null>(null);
  const [stats, setStats] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [analyticsRes, statsRes] = await Promise.all([
        fetch('/api/analytics'),
        fetch('/api/stats'),
      ]);

      if (!analyticsRes.ok || !statsRes.ok) {
        throw new Error('Failed to load database analytics');
      }

      const analyticsJson = await analyticsRes.json();
      const statsJson = await statsRes.json();

      setData(analyticsJson);
      setStats(statsJson);
    } catch (err: any) {
      setError(err.message || 'Error communicating with database');
    } finally {
      setLoading(false);
    }
  };

  if (!isMounted) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Administrator Analytics & Diagnostics
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time descriptive statistical distributions aggregated straight from the database.
          </p>
        </div>

        <button
          onClick={fetchData}
          className="inline-flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 transition-colors shadow-xs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Recalculate</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Total Properties
          </span>
          <div className="text-2xl font-extrabold text-slate-900">
            {stats ? formatNumber(stats.totalProperties) : '...'}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">Recorded in DB</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Total Predictions
          </span>
          <div className="text-2xl font-extrabold text-indigo-700">
            {stats ? formatNumber(stats.totalPredictions) : '...'}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">Logged in Audit Trail</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Average Price
          </span>
          <div className="text-xl font-extrabold text-slate-900 truncate">
            {stats ? formatIndianCurrency(stats.averagePrice) : '...'}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">Arithmetic mean</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Avg Price / Sq.Ft
          </span>
          <div className="text-xl font-extrabold text-sky-700 truncate">
            {stats ? formatIndianCurrency(stats.averagePricePerSqFt) : '...'}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">Normalized density</span>
        </div>
      </div>

      {/* Charts Grid */}
      {loading ? (
        <div className="p-16 text-center space-y-3 bg-white rounded-2xl border border-slate-200">
          <div className="w-8 h-8 border-3 border-sky-600/30 border-t-sky-600 rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500 font-medium">Computing live analytics...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Average Price by Location */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Average Valuation by Location
            </h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data?.priceByLocation || []} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="location" angle={-25} textAnchor="end" tick={{ fontSize: 10, fill: '#64748b' }} />
                  <YAxis tickFormatter={(v) => `₹${(v / 10000000).toFixed(1)}Cr`} tick={{ fontSize: 10, fill: '#64748b' }} />
                  <Tooltip formatter={(value: any) => [formatIndianCurrency(value), 'Avg Price']} />
                  <Bar dataKey="avgPrice" fill="#0284c7" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Property Type Distribution */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Property Typology Distribution
            </h3>
            <div className="h-64 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data?.propertyTypeDistribution || []}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={3}
                    dataKey="count"
                    label={({ name, percentage }) => `${name} (${percentage}%)`}
                  >
                    {(data?.propertyTypeDistribution || []).map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Bedroom vs Price */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Bedroom Configuration vs Price
            </h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data?.bedroomVsPrice || []} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#64748b' }} />
                  <YAxis tickFormatter={(v) => `₹${(v / 10000000).toFixed(1)}Cr`} tick={{ fontSize: 10, fill: '#64748b' }} />
                  <Tooltip formatter={(value: any) => [formatIndianCurrency(value), 'Avg Price']} />
                  <Bar dataKey="avgPrice" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Price per Sq.Ft by Location */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Unit Rate (Price / Sq.Ft) by Location
            </h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data?.pricePerSqFtByLocation || []} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="location" angle={-25} textAnchor="end" tick={{ fontSize: 10, fill: '#64748b' }} />
                  <YAxis tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 10, fill: '#64748b' }} />
                  <Tooltip formatter={(value: any) => [formatIndianCurrency(value), 'Rate / Sq.Ft']} />
                  <Bar dataKey="avgPricePerSqFt" fill="#6366f1" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

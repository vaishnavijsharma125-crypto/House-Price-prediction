'use client';

import React, { useState, useEffect } from 'react';
import {
  MapPin,
  PlusCircle,
  Edit2,
  Search,
  Filter,
  CheckCircle2,
  TrendingUp,
  AlertCircle,
  Building,
  Layers,
  X,
  Sparkles,
  DollarSign,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { formatIndianCurrency } from '@/lib/utils';

interface LocationItem {
  id: number;
  city: string;
  area: string;
  locality: string;
  pincode: string | null;
  state: string;
  avgPricePerSqFt: number;
  marketTier: string;
  isActive: boolean;
}

export default function AdminLocationsPage() {
  const [locations, setLocations] = useState<LocationItem[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedCity, setSelectedCity] = useState('All');
  const [search, setSearch] = useState('');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingLocality, setEditingLocality] = useState<LocationItem | null>(null);
  const [newRate, setNewRate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New location form
  const [newCity, setNewCity] = useState('Mumbai');
  const [newArea, setNewArea] = useState('');
  const [newLocalityName, setNewLocalityName] = useState('');
  const [newPincode, setNewPincode] = useState('');
  const [newState, setNewState] = useState('Maharashtra');
  const [newPriceSqFt, setNewPriceSqFt] = useState('12000');
  const [newTier, setNewTier] = useState('Tier 1');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const fetchLocations = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        city: selectedCity,
      });

      const res = await fetch(`/api/locations?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch location database');
      const data = await res.json();

      setLocations(data.locations || []);
      setCities(data.cities || []);
    } catch (err: any) {
      setError(err.message || 'Error loading locations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLocations();
  }, [selectedCity]);

  const filteredLocations = locations.filter((loc) => {
    if (!search.trim()) return true;
    const s = search.toLowerCase();
    return (
      loc.locality.toLowerCase().includes(s) ||
      loc.area.toLowerCase().includes(s) ||
      loc.city.toLowerCase().includes(s) ||
      (loc.pincode && loc.pincode.includes(s))
    );
  });

  const handleAddLocation = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/locations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          city: newCity,
          area: newArea || newLocalityName,
          locality: newLocalityName,
          pincode: newPincode,
          state: newState,
          avgPricePerSqFt: parseFloat(newPriceSqFt),
          marketTier: newTier,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save location');

      showToast(`Locality ${newLocalityName} registered with base rate ₹${newPriceSqFt}/sqft`);
      setIsAddModalOpen(false);
      setNewLocalityName('');
      setNewArea('');
      setNewPincode('');
      fetchLocations();
    } catch (err: any) {
      alert(`Error: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateRate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLocality) return;
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/locations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          city: editingLocality.city,
          area: editingLocality.area,
          locality: editingLocality.locality,
          pincode: editingLocality.pincode,
          state: editingLocality.state,
          avgPricePerSqFt: parseFloat(newRate),
          marketTier: editingLocality.marketTier,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update benchmark rate');

      showToast(`Updated baseline rate for ${editingLocality.locality} to ₹${newRate}/sqft`);
      setEditingLocality(null);
      fetchLocations();
    } catch (err: any) {
      alert(`Error updating rate: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-xl shadow-lg flex items-center space-x-2 text-sm font-medium animate-bounce">
          <CheckCircle2 className="w-5 h-5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <MapPin className="w-8 h-8 text-sky-600" />
            <span>Locations & Benchmark Rates</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Locality master registry, market tiering, and baseline price-per-square-foot calibrations powering the prediction engine.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 transition-colors shadow-xs"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Add Locality</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by locality name, sub-area, or pincode..."
            className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all text-slate-800"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-500" />
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="text-xs py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
            >
              <option value="All">All Cities</option>
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">
            {filteredLocations.length} Localities
          </span>
        </div>
      </div>

      {/* Locations Grid / Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-20 text-center">
            <div className="w-8 h-8 border-3 border-sky-500/30 border-t-sky-500 rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs text-slate-500">Loading locality rate benchmarks...</p>
          </div>
        ) : error ? (
          <div className="py-12 text-center text-rose-600 space-y-2">
            <AlertCircle className="w-8 h-8 mx-auto" />
            <p className="text-sm font-semibold">{error}</p>
          </div>
        ) : filteredLocations.length === 0 ? (
          <div className="py-16 text-center text-slate-500 space-y-2">
            <MapPin className="w-10 h-10 mx-auto text-slate-300" />
            <p className="text-sm font-semibold">No localities found matching query</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4">Locality & Area</th>
                  <th className="py-3 px-4">City & State</th>
                  <th className="py-3 px-4">Pincode</th>
                  <th className="py-3 px-4">Market Tier</th>
                  <th className="py-3 px-4">Base Rate (₹/sqft)</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredLocations.map((loc) => (
                  <tr key={loc.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{loc.locality}</div>
                      <div className="text-[11px] text-slate-500">{loc.area}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{loc.city}</div>
                      <div className="text-[10px] text-slate-400">{loc.state}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {loc.pincode || '—'}
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                        {loc.marketTier}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div className="flex items-center gap-1.5 text-sky-700">
                        <span>₹{loc.avgPricePerSqFt.toLocaleString('en-IN')}/sqft</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Active</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => {
                          setEditingLocality(loc);
                          setNewRate(String(loc.avgPricePerSqFt));
                        }}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-lg text-xs font-semibold transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit Rate</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Rate Modal */}
      {editingLocality && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">
                Calibrate Benchmark: {editingLocality.locality}
              </h3>
              <button
                onClick={() => setEditingLocality(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateRate} className="p-6 space-y-4 text-xs">
              <p className="text-slate-600">
                Updating this baseline directly influences future customer price predictions and valuation confidence for properties situated in{' '}
                <strong className="text-slate-900">{editingLocality.locality}, {editingLocality.city}</strong>.
              </p>

              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  Base Rate (₹ per Sq.Ft)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">₹</span>
                  <input
                    type="number"
                    required
                    min="1000"
                    step="100"
                    value={newRate}
                    onChange={(e) => setNewRate(e.target.value)}
                    className="w-full pl-8 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingLocality(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? 'Updating...' : 'Save Benchmark'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Locality Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-lg font-bold text-slate-900">Add Locality Benchmark</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddLocation} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">City</label>
                  <input
                    type="text"
                    required
                    value={newCity}
                    onChange={(e) => setNewCity(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                    placeholder="e.g. Mumbai, Bangalore"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Locality Name</label>
                  <input
                    type="text"
                    required
                    value={newLocalityName}
                    onChange={(e) => setNewLocalityName(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                    placeholder="e.g. Whitefield, HSR Layout"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Sub-Area / Zone</label>
                  <input
                    type="text"
                    value={newArea}
                    onChange={(e) => setNewArea(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                    placeholder="e.g. South Bangalore"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Pincode</label>
                  <input
                    type="text"
                    value={newPincode}
                    onChange={(e) => setNewPincode(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                    placeholder="e.g. 560066"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Baseline Rate (₹/sqft)</label>
                  <input
                    type="number"
                    required
                    min="1000"
                    step="100"
                    value={newPriceSqFt}
                    onChange={(e) => setNewPriceSqFt(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">Market Tier</label>
                  <select
                    value={newTier}
                    onChange={(e) => setNewTier(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="Tier 1">Tier 1 (Prime Urban)</option>
                    <option value="Tier 2">Tier 2 (Emerging Metro)</option>
                    <option value="Tier 3">Tier 3 (Suburban / Peripheral)</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : 'Add Locality'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

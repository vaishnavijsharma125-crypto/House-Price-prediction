import React from 'react';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifyTokenString } from '@/lib/auth';
import AdminShell from './AdminShell';

export const dynamic = 'force-dynamic';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const cookieStore = cookies();
  const token = cookieStore.get('admin_token')?.value;

  // Verify token
  const isValid = token ? verifyTokenString(token) : null;

  return (
    <AdminShell isAuthenticated={!!isValid}>
      {children}
    </AdminShell>
  );
}

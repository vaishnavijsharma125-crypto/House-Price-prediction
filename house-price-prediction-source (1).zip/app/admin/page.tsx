import React from 'react';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import {
  Building,
  History,
  TrendingUp,
  PlusCircle,
  Database,
  BarChart3,
  FileEdit,
  ArrowRight,
  Clock,
  CheckCircle2,
  Users,
  Receipt,
  MapPin,
  ShieldCheck,
  Phone,
  Mail,
} from 'lucide-react';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifyToken } from '@/lib/auth';
import { formatIndianCurrency, formatNumber, formatDate } from '@/lib/utils';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminDashboardPage() {
  const cookieStore = cookies();
  const token = cookieStore.get('admin_token')?.value;
  if (!token || !verifyToken(token)) {
    redirect('/admin/login');
  }

  const [
    totalProperties,
    totalPredictions,
    totalLeads,
    totalTransactions,
    totalLocations,
    aggregations,
    recentProperties,
    recentPredictions,
    recentLeads,
  ] = await Promise.all([
    prisma.property.count(),
    prisma.prediction.count(),
    prisma.lead.count(),
    prisma.propertyTransaction.count(),
    prisma.location.count({ where: { isActive: true } }),
    prisma.property.aggregate({
      _avg: { expectedPrice: true, areaSqFt: true },
      _max: { expectedPrice: true },
    }),
    prisma.property.findMany({
      orderBy: { createdAt: 'desc' },
      take: 4,
      include: { location: true },
    }),
    prisma.prediction.findMany({
      orderBy: { createdAt: 'desc' },
      take: 4,
    }),
    prisma.lead.findMany({
      orderBy: { createdAt: 'desc' },
      take: 4,
      include: {
        valuationRequest: true,
      },
    }),
  ]);

  const averagePrice = Math.round(aggregations._avg.expectedPrice || 0);

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Administrator Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Commercial real estate intelligence, database controls, lead pipeline, and statistical valuation monitoring.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/admin/properties"
            className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 shadow-xs transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Manage Properties</span>
          </Link>
          <Link
            href="/admin/leads"
            className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 shadow-xs transition-colors"
          >
            <Users className="w-4 h-4 text-sky-600" />
            <span>Lead Pipeline</span>
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Properties Inventory</span>
            <Building className="w-5 h-5 text-sky-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {formatNumber(totalProperties)}
          </div>
          <p className="text-xs text-slate-500 mt-1">Active database listings</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Customer Leads</span>
            <Users className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {formatNumber(totalLeads)}
          </div>
          <p className="text-xs text-slate-500 mt-1">Inquiries & valuation conversions</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Historical Transactions</span>
            <Receipt className="w-5 h-5 text-amber-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {formatNumber(totalTransactions)}
          </div>
          <p className="text-xs text-slate-500 mt-1">Verified registry sales</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Market Localities</span>
            <MapPin className="w-5 h-5 text-purple-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {formatNumber(totalLocations)}
          </div>
          <p className="text-xs text-slate-500 mt-1">Calibrated benchmark registries</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Total Predictions</span>
            <History className="w-5 h-5 text-indigo-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {formatNumber(totalPredictions)}
          </div>
          <p className="text-xs text-slate-500 mt-1">Logged valuation invocations</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Average Property Price</span>
            <TrendingUp className="w-5 h-5 text-teal-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {formatIndianCurrency(averagePrice)}
          </div>
          <p className="text-xs text-slate-500 mt-1">Live arithmetic dataset mean</p>
        </div>
      </div>

      {/* Quick Actions Shortcuts */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Link
          href="/admin/properties"
          className="p-4 bg-white rounded-xl border border-slate-200 hover:border-sky-300 hover:shadow-xs transition-all flex items-center gap-3"
        >
          <div className="p-2.5 rounded-lg bg-sky-50 text-sky-600">
            <Building className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Properties</div>
            <div className="text-[11px] text-slate-500">Inventory & Listings</div>
          </div>
        </Link>

        <Link
          href="/admin/leads"
          className="p-4 bg-white rounded-xl border border-slate-200 hover:border-emerald-300 hover:shadow-xs transition-all flex items-center gap-3"
        >
          <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Customer Leads</div>
            <div className="text-[11px] text-slate-500">Pipeline & Status</div>
          </div>
        </Link>

        <Link
          href="/admin/transactions"
          className="p-4 bg-white rounded-xl border border-slate-200 hover:border-amber-300 hover:shadow-xs transition-all flex items-center gap-3"
        >
          <div className="p-2.5 rounded-lg bg-amber-50 text-amber-600">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Transactions</div>
            <div className="text-[11px] text-slate-500">Registry Ledger</div>
          </div>
        </Link>

        <Link
          href="/admin/locations"
          className="p-4 bg-white rounded-xl border border-slate-200 hover:border-purple-300 hover:shadow-xs transition-all flex items-center gap-3"
        >
          <div className="p-2.5 rounded-lg bg-purple-50 text-purple-600">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Locations</div>
            <div className="text-[11px] text-slate-500">Benchmark Rates</div>
          </div>
        </Link>

        <Link
          href="/admin/predictions"
          className="p-4 bg-white rounded-xl border border-slate-200 hover:border-indigo-300 hover:shadow-xs transition-all flex items-center gap-3"
        >
          <div className="p-2.5 rounded-lg bg-indigo-50 text-indigo-600">
            <History className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Valuation Audit</div>
            <div className="text-[11px] text-slate-500">Calculation Logs</div>
          </div>
        </Link>

        <Link
          href="/admin/analytics"
          className="p-4 bg-white rounded-xl border border-slate-200 hover:border-teal-300 hover:shadow-xs transition-all flex items-center gap-3"
        >
          <div className="p-2.5 rounded-lg bg-teal-50 text-teal-600">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Analytics</div>
            <div className="text-[11px] text-slate-500">Market Intelligence</div>
          </div>
        </Link>

        <Link
          href="/admin/audit-logs"
          className="p-4 bg-white rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-xs transition-all flex items-center gap-3"
        >
          <div className="p-2.5 rounded-lg bg-blue-50 text-blue-600">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Audit Trail</div>
            <div className="text-[11px] text-slate-500">Security & Changes</div>
          </div>
        </Link>

        <Link
          href="/admin/settings"
          className="p-4 bg-white rounded-xl border border-slate-200 hover:border-slate-400 hover:shadow-xs transition-all flex items-center gap-3"
        >
          <div className="p-2.5 rounded-lg bg-slate-100 text-slate-600">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Data & Settings</div>
            <div className="text-[11px] text-slate-500">Import & Export</div>
          </div>
        </Link>
      </div>

      {/* Tri-Column Summary: Recent Leads, Recent Predictions, Recent Properties */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Leads */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Recent Customer Leads
              </h3>
              <p className="text-[11px] text-slate-500">
                Inquiries from valuation submissions.
              </p>
            </div>
            <Link
              href="/admin/leads"
              className="text-xs font-semibold text-sky-600 hover:text-sky-700 flex items-center gap-1"
            >
              <span>View all</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentLeads.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No leads registered yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 text-xs">
              {recentLeads.map((lead) => (
                <div key={lead.id} className="py-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{lead.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-sky-50 text-sky-700 border border-sky-200">
                      {lead.status}
                    </span>
                  </div>
                  <div className="text-slate-500 text-[11px] mt-0.5">
                    {lead.phone} • {lead.email}
                  </div>
                  <div className="text-slate-400 text-[10px] mt-0.5">
                    {formatDate(lead.createdAt)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Predictions */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Recent Valuations
              </h3>
              <p className="text-[11px] text-slate-500">
                Calculations processed by engine.
              </p>
            </div>
            <Link
              href="/admin/predictions"
              className="text-xs font-semibold text-sky-600 hover:text-sky-700 flex items-center gap-1"
            >
              <span>View all</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentPredictions.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No valuations logged yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 text-xs">
              {recentPredictions.map((pred: any) => {
                const estPrice = pred.estimatedPrice ?? pred.predictedPrice ?? 0;
                const vReq = pred.valuationRequest;
                const pType = vReq?.propertyType ?? pred.propertyType ?? 'Residential';
                const pLoc = vReq?.localityText ?? pred.location ?? 'Metro';
                const pArea = vReq?.areaSqFt ?? pred.area ?? '—';

                return (
                  <div key={pred.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">
                        {formatIndianCurrency(estPrice)}
                      </div>
                      <div className="text-slate-500 text-[11px]">
                        {pType} • {pLoc}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[11px] text-slate-600 font-mono">
                        {pArea} Sq.Ft
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {formatDate(pred.createdAt)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Recent Property Records */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Recent Properties
              </h3>
              <p className="text-[11px] text-slate-500">
                Latest active inventory items.
              </p>
            </div>
            <Link
              href="/admin/properties"
              className="text-xs font-semibold text-sky-600 hover:text-sky-700 flex items-center gap-1"
            >
              <span>View all</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentProperties.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No properties found.</p>
          ) : (
            <div className="divide-y divide-slate-100 text-xs">
              {recentProperties.map((p: any) => {
                const price = p.expectedPrice ?? p.price ?? 0;
                const area = p.areaSqFt ?? p.area ?? 1;
                const locName = p.location ? `${p.location.locality}, ${p.location.city}` : (typeof p.location === 'string' ? p.location : 'Metro');

                return (
                  <div key={p.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">
                        {p.propertyType}
                      </div>
                      <div className="text-slate-500 text-[11px]">
                        {locName} • {area} Sq.Ft
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-slate-900">
                        {formatIndianCurrency(price)}
                      </div>
                      <div className="text-[10px] text-sky-700 font-medium">
                        ₹{Math.round(price / Math.max(1, area)).toLocaleString('en-IN')}/sqft
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState, useEffect } from 'react';
import {
  Building2,
  MapPin,
  Maximize2,
  BedDouble,
  Bath,
  Layers,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  ShieldAlert,
  Calendar,
  Check,
  Building,
  TrendingUp,
  Tag,
  Phone,
  Mail,
  User,
  Sliders,
  ShieldCheck,
} from 'lucide-react';
import { formatIndianCurrency, formatNumber, formatDate } from '@/lib/utils';
import { ValuationResult, PropertyType } from '@/types';

const STEPS = [
  { id: 1, name: 'Typology', icon: Building2 },
  { id: 2, name: 'Location', icon: MapPin },
  { id: 3, name: 'Area', icon: Maximize2 },
  { id: 4, name: 'Rooms', icon: BedDouble },
  { id: 5, name: 'Condition', icon: Calendar },
  { id: 6, name: 'Elevation', icon: Layers },
  { id: 7, name: 'Amenities', icon: Sliders },
  { id: 8, name: 'Verification', icon: User },
];

const PROPERTY_TYPES: PropertyType[] = [
  'Apartment',
  'Villa/House',
  'Plot/Land',
  'Commercial',
  'Penthouse',
];

const AMENITY_OPTIONS = [
  'Swimming Pool',
  'Gymnasium',
  'Clubhouse',
  '24/7 Security',
  'Power Backup',
  'Covered Parking',
  'Intercom Facility',
  'Children Play Area',
  'EV Charging Station',
  'Private Garden',
  'Solar Heating',
  'Visitor Parking',
];

export default function PredictPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [locations, setLocations] = useState<any[]>([]);
  const [cities, setCities] = useState<string[]>([]);

  // Form State
  const [formData, setFormData] = useState({
    propertyType: 'Apartment' as PropertyType,
    city: 'Mumbai',
    locality: 'Bandra West',
    pincode: '400050',
    areaSqFt: 1200,
    bedrooms: 2,
    bathrooms: 2,
    balconies: 1,
    propertyAge: 3,
    floor: 6,
    totalFloors: 18,
    parking: 'Covered',
    furnishing: 'Semi-Furnished',
    constructionStatus: 'Ready to Move',
    amenities: ['Gymnasium', '24/7 Security', 'Power Backup'],
    contactName: '',
    contactEmail: '',
    contactPhone: '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ValuationResult | null>(null);

  useEffect(() => {
    // Fetch active locations from DB
    fetch('/api/locations')
      .then((res) => res.json())
      .then((data) => {
        if (data.locations && data.locations.length > 0) {
          setLocations(data.locations);
          const distinctCities = Array.from(new Set(data.locations.map((l: any) => l.city))) as string[];
          setCities(distinctCities);
        }
      })
      .catch((err) => console.error('Failed to fetch locations:', err));
  }, []);

  const handleAmenityToggle = (amenity: string) => {
    setFormData((prev) => {
      const exists = prev.amenities.includes(amenity);
      return {
        ...prev,
        amenities: exists
          ? prev.amenities.filter((a) => a !== amenity)
          : [...prev.amenities, amenity],
      };
    });
  };

  const nextStep = () => {
    setError(null);

    // Step 2 validation
    if (currentStep === 2) {
      if (!formData.city.trim()) {
        setError('Please select a target city');
        return;
      }
      if (!formData.locality.trim()) {
        setError('Please enter the locality or neighborhood');
        return;
      }
    }

    // Step 3 validation
    if (currentStep === 3) {
      if (!formData.areaSqFt || formData.areaSqFt < 100 || formData.areaSqFt > 100000) {
        setError('Please enter a valid area between 100 and 100,000 sq.ft');
        return;
      }
    }

    // Step 8 validation and submit
    if (currentStep === 8) {
      if (!formData.contactName.trim()) {
        setError('Please enter your contact name');
        return;
      }
      if (!formData.contactEmail.trim() || !formData.contactEmail.includes('@')) {
        setError('Please enter a valid email address');
        return;
      }
      if (formData.contactPhone.length < 10) {
        setError('Please enter a valid 10-digit phone number');
        return;
      }
      handleSubmit();
      return;
    }

    setCurrentStep((prev) => Math.min(8, prev + 1));
  };

  const prevStep = () => {
    setError(null);
    setCurrentStep((prev) => Math.max(1, prev - 1));
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/valuations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to calculate property valuation');
      }

      setResult(data);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      setError(err.message || 'An error occurred during valuation calculation.');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setResult(null);
    setCurrentStep(1);
    setError(null);
  };

  return (
    <div className="bg-industrial-grid min-h-screen text-slate-100 py-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Page Header */}
        <div className="border-b border-slate-800/90 pb-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-500/15 border border-sky-400/30 text-sky-300 text-xs font-bold uppercase tracking-wider mb-2 shadow-sm shadow-sky-500/10">
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>Automated Valuation Engine</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Property Market Valuation Analysis
          </h1>
          <p className="text-slate-400 text-sm mt-1 max-w-3xl leading-relaxed">
            Receive an empirical market estimation powered by location density benchmarks, physical layout parameters, and verified historical transactions.
          </p>
        </div>

        {result ? (
          /* VALUATION REPORT RESULT */
          <div className="space-y-8 animate-in fade-in duration-300">
            <div className="bg-slate-900/95 rounded-3xl border border-slate-800 p-6 sm:p-10 shadow-2xl shadow-black/90 backdrop-blur-2xl space-y-8">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-6 gap-4">
                <div>
                  <span className="text-xs font-mono font-bold text-sky-400 bg-sky-950/80 px-3 py-1 rounded-full border border-sky-500/30">
                    {result.requestRef}
                  </span>
                  <h2 className="text-2xl font-extrabold text-white mt-2">
                    Valuation Report: {formData.propertyType} in {formData.locality}, {formData.city}
                  </h2>
                  <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 font-medium">
                    <span>Valuation Date: {formatDate(result.valuationDate)}</span>
                    <span>•</span>
                    <span>Model: {result.modelVersion}</span>
                    <span>•</span>
                    <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 radar-dot"></span>
                      <span>Confidence: {result.confidenceLevel}</span>
                    </span>
                  </div>
                </div>

                <button
                  onClick={resetForm}
                  className="btn-shady-dark px-4 py-2 text-xs gap-2"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-sky-400" />
                  <span>Evaluate Another Property</span>
                </button>
              </div>

              {/* Price Output Hero with Glowing Industrial Accents */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 relative overflow-hidden bg-gradient-to-br from-sky-950 via-slate-900 to-[#0c1a2e] border border-sky-500/40 p-8 rounded-3xl text-white shadow-2xl shadow-sky-500/15 flex flex-col justify-between">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-sky-500 via-blue-500 to-indigo-500" />
                  <div>
                    <span className="text-xs uppercase font-bold tracking-widest text-sky-400">
                      Estimated Market Value
                    </span>
                    <div className="text-4xl sm:text-5xl font-black tracking-tight mt-2 text-white">
                      {formatIndianCurrency(result.estimatedPrice)}
                    </div>
                    <div className="text-sm font-semibold text-slate-300 mt-3 flex items-center gap-2">
                      <span>Valuation Rate:</span>
                      <span className="text-sky-300 font-bold">
                        {formatIndianCurrency(result.pricePerSqFt)} / Sq.Ft
                      </span>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
                    <span>Based on {result.dataPointsUsed} historical transactions & live comparable listings</span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-sky-950/80 border border-sky-500/30 text-sky-300 font-mono text-[11px] font-bold">
                      ±5.5% Confidence Band
                    </span>
                  </div>
                </div>

                <div className="bg-slate-950/80 p-6 rounded-3xl border border-slate-800 flex flex-col justify-between space-y-4">
                  <div>
                    <span className="text-xs uppercase font-bold text-sky-400 tracking-wider">
                      Estimated Price Range
                    </span>
                    <div className="mt-3 space-y-3">
                      <div>
                        <span className="text-[11px] text-slate-400">Conservative Floor:</span>
                        <div className="text-lg font-black text-slate-200">
                          {formatIndianCurrency(result.lowEstimate)}
                        </div>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400">Optimistic Ceiling:</span>
                        <div className="text-lg font-black text-slate-200">
                          {formatIndianCurrency(result.highEstimate)}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900/90 rounded-2xl border border-slate-800 text-xs text-slate-400">
                    <span className="font-semibold block text-slate-200 mb-0.5">Market Position:</span>
                    <span>{formData.locality} real estate density benchmark: {formData.areaSqFt} Sq.Ft.</span>
                  </div>
                </div>
              </div>

              {/* Valuation Attribution Factors */}
              <div className="space-y-4">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-sky-400" />
                  <span>Key Valuation Factors & Attribution</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {result.factors.map((f, i) => (
                    <div
                      key={i}
                      className="p-4 rounded-2xl border border-slate-800 bg-slate-950/70 space-y-2 shadow-md"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-200">{f.factor}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            f.impact === 'positive'
                              ? 'bg-emerald-950/80 border border-emerald-500/30 text-emerald-400'
                              : f.impact === 'negative'
                              ? 'bg-rose-950/80 border border-rose-500/30 text-rose-400'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {f.impact}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400">{f.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Legal Disclaimer */}
              <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <strong>Commercial Valuation Notice:</strong> This estimate is calibrated from verified sub-registrar transactions and multi-attribute econometric coefficients. It serves for analytical and comparative purposes.
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* 8-STEP VALUATION WIZARD */
          <div className="bg-slate-900/90 rounded-3xl border border-slate-800/90 p-6 sm:p-10 shadow-2xl backdrop-blur-2xl space-y-8">
            {/* Step Progress Indicator */}
            <div className="border-b border-slate-800 pb-6">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-4">
                <span>Step {currentStep} of 8</span>
                <span className="text-sky-400 font-bold uppercase tracking-wider">
                  {STEPS[currentStep - 1].name}
                </span>
              </div>

              <div className="grid grid-cols-8 gap-1.5 sm:gap-2">
                {STEPS.map((s) => (
                  <div
                    key={s.id}
                    className={`h-2 rounded-full transition-all ${
                      s.id === currentStep
                        ? 'bg-sky-500 shadow-md shadow-sky-500/50'
                        : s.id < currentStep
                        ? 'bg-emerald-500'
                        : 'bg-slate-800'
                    }`}
                  />
                ))}
              </div>
            </div>

            {error && (
              <div className="p-4 rounded-2xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            {/* STEP 1: Property Type */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Select Property Typology
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Choose the structural category that best describes the asset.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {PROPERTY_TYPES.map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setFormData({ ...formData, propertyType: type })}
                      className={`p-6 rounded-3xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        formData.propertyType === type
                          ? 'border-sky-500 bg-sky-500/15 shadow-xl shadow-sky-500/20 text-white'
                          : 'border-slate-800 hover:border-slate-700 bg-slate-950/70 text-slate-300'
                      }`}
                    >
                      <Building2 className={`w-6 h-6 mb-4 ${formData.propertyType === type ? 'text-sky-400' : 'text-slate-500'}`} />
                      <div>
                        <div className="font-bold text-white text-sm">{type}</div>
                        <div className="text-[11px] text-slate-400 mt-1">
                          {type === 'Apartment' && 'Gated or standalone residential apartment'}
                          {type === 'Villa/House' && 'Independent bungalow, row house, or villa'}
                          {type === 'Plot/Land' && 'Residential or commercial vacant land parcel'}
                          {type === 'Commercial' && 'Office space, retail storefront, or warehouse'}
                          {type === 'Penthouse' && 'Top-tier luxury penthouse residence'}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* STEP 2: Location */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Location & Locality Details
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Enter the geographic coordinates and neighborhood to calibrate baseline market density.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      City <span className="text-rose-400">*</span>
                    </label>
                    <select
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20"
                    >
                      {cities.length > 0 ? (
                        cities.map((c) => (
                          <option key={c} value={c} className="bg-slate-900 text-white">
                            {c}
                          </option>
                        ))
                      ) : (
                        <>
                          <option value="Mumbai" className="bg-slate-900 text-white">Mumbai</option>
                          <option value="Bangalore" className="bg-slate-900 text-white">Bangalore</option>
                          <option value="Delhi" className="bg-slate-900 text-white">Delhi</option>
                          <option value="Pune" className="bg-slate-900 text-white">Pune</option>
                          <option value="Hyderabad" className="bg-slate-900 text-white">Hyderabad</option>
                          <option value="Chennai" className="bg-slate-900 text-white">Chennai</option>
                          <option value="Kolkata" className="bg-slate-900 text-white">Kolkata</option>
                          <option value="Ahmedabad" className="bg-slate-900 text-white">Ahmedabad</option>
                        </>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Locality / Submarket <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.locality}
                      onChange={(e) => setFormData({ ...formData, locality: e.target.value })}
                      placeholder="e.g. Bandra West, Indiranagar, Whitefield"
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Postal Pincode
                    </label>
                    <input
                      type="text"
                      value={formData.pincode}
                      onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                      placeholder="e.g. 400050"
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* STEP 3: Property Size */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Property Dimensions & Usable Footprint
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Specify the total built-up or carpet area in square feet.
                  </p>
                </div>

                <div className="max-w-md space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Area (Sq.Ft) <span className="text-rose-400">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min="100"
                        max="100000"
                        value={formData.areaSqFt}
                        onChange={(e) =>
                          setFormData({ ...formData, areaSqFt: parseFloat(e.target.value) || 0 })
                        }
                        className="w-full pl-4 pr-16 py-3.5 rounded-xl border border-slate-700 bg-slate-950 text-base font-black text-white focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20"
                      />
                      <span className="absolute right-4 top-3.5 text-xs text-slate-400 font-semibold">
                        Sq.Ft
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 4: Rooms */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Room Configuration
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Select number of bedrooms, bathrooms, and balconies.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Bedrooms
                    </label>
                    <select
                      value={formData.bedrooms}
                      onChange={(e) =>
                        setFormData({ ...formData, bedrooms: parseInt(e.target.value, 10) })
                      }
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    >
                      {[0, 1, 2, 3, 4, 5, 6].map((num) => (
                        <option key={num} value={num} className="bg-slate-900 text-white">
                          {num === 0 ? '0 (Studio/Plot)' : `${num} BHK`}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Bathrooms
                    </label>
                    <select
                      value={formData.bathrooms}
                      onChange={(e) =>
                        setFormData({ ...formData, bathrooms: parseInt(e.target.value, 10) })
                      }
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    >
                      {[0, 1, 2, 3, 4, 5, 6].map((num) => (
                        <option key={num} value={num} className="bg-slate-900 text-white">
                          {num} Bathrooms
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Balconies
                    </label>
                    <select
                      value={formData.balconies}
                      onChange={(e) =>
                        setFormData({ ...formData, balconies: parseInt(e.target.value, 10) })
                      }
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    >
                      {[0, 1, 2, 3, 4].map((num) => (
                        <option key={num} value={num} className="bg-slate-900 text-white">
                          {num} Balconies
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 5: Property Condition */}
            {currentStep === 5 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Property Age & Furnishing Status
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Structural depreciation and interior furnishing standard.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Property Age (Years)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="60"
                      value={formData.propertyAge}
                      onChange={(e) =>
                        setFormData({ ...formData, propertyAge: parseInt(e.target.value, 10) || 0 })
                      }
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    />
                    <span className="text-[11px] text-slate-500 mt-1 block">0 for brand new</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Furnishing Level
                    </label>
                    <select
                      value={formData.furnishing}
                      onChange={(e) => setFormData({ ...formData, furnishing: e.target.value })}
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    >
                      <option value="Unfurnished" className="bg-slate-900 text-white">Unfurnished</option>
                      <option value="Semi-Furnished" className="bg-slate-900 text-white">Semi-Furnished</option>
                      <option value="Fully-Furnished" className="bg-slate-900 text-white">Fully-Furnished</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Construction Status
                    </label>
                    <select
                      value={formData.constructionStatus}
                      onChange={(e) => setFormData({ ...formData, constructionStatus: e.target.value })}
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    >
                      <option value="Ready to Move" className="bg-slate-900 text-white">Ready to Move</option>
                      <option value="Under Construction" className="bg-slate-900 text-white">Under Construction</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 6: Floor Elevation */}
            {currentStep === 6 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Floor Elevation & Parking
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Floor height vantage and dedicated parking bay allocation.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Property Floor
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="80"
                      value={formData.floor}
                      onChange={(e) =>
                        setFormData({ ...formData, floor: parseInt(e.target.value, 10) || 0 })
                      }
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    />
                    <span className="text-[11px] text-slate-500 mt-1 block">0 for ground level</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Total Building Floors
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="80"
                      value={formData.totalFloors}
                      onChange={(e) =>
                        setFormData({ ...formData, totalFloors: parseInt(e.target.value, 10) || 1 })
                      }
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Parking Bay
                    </label>
                    <select
                      value={formData.parking}
                      onChange={(e) => setFormData({ ...formData, parking: e.target.value })}
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    >
                      <option value="Covered" className="bg-slate-900 text-white">Covered Garage</option>
                      <option value="Open" className="bg-slate-900 text-white">Open Parking</option>
                      <option value="None" className="bg-slate-900 text-white">No Parking</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 7: Amenities */}
            {currentStep === 7 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Amenities & Facilities
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Select society and private amenities that enhance valuation.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {AMENITY_OPTIONS.map((amenity) => {
                    const selected = formData.amenities.includes(amenity);
                    return (
                      <button
                        key={amenity}
                        type="button"
                        onClick={() => handleAmenityToggle(amenity)}
                        className={`p-3.5 rounded-2xl border text-left text-xs font-semibold flex items-center justify-between transition-all ${
                          selected
                            ? 'bg-sky-500/20 border-sky-400/50 text-sky-300 shadow-md shadow-sky-500/10'
                            : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        <span>{amenity}</span>
                        {selected && <Check className="w-3.5 h-3.5 text-sky-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 8: Verification & Delivery */}
            {currentStep === 8 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Appraisal Verification
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Enter contact info to generate the valuation certificate.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Full Name <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.contactName}
                      onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
                      placeholder="e.g. Vikramaditya Roy"
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Work Email <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.contactEmail}
                      onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                      placeholder="e.g. vikram@investments.com"
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-sky-400 uppercase mb-1.5">
                      Mobile Phone <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.contactPhone}
                      onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                      placeholder="e.g. 9820123456"
                      className="w-full px-3.5 py-3 rounded-xl border border-slate-700 bg-slate-950 text-sm text-white"
                    />
                  </div>
                </div>

                <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 text-xs text-slate-400 space-y-1">
                  <span className="font-bold text-slate-200 block">Review of Parameters:</span>
                  <p>
                    {formData.propertyType} • {formData.locality}, {formData.city} • {formData.areaSqFt} Sq.Ft • {formData.bedrooms} BHK • Floor {formData.floor}/{formData.totalFloors} • {formData.furnishing}
                  </p>
                </div>
              </div>
            )}

            {/* Navigation Controls */}
            <div className="pt-6 border-t border-slate-800 flex items-center justify-between">
              {currentStep > 1 ? (
                <button
                  type="button"
                  onClick={prevStep}
                  className="btn-shady-dark px-5 py-2.5 text-xs gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Previous Step</span>
                </button>
              ) : (
                <div />
              )}

              <button
                type="button"
                disabled={loading}
                onClick={nextStep}
                className={
                  currentStep === 8
                    ? 'btn-shady-amber px-8 py-3 text-xs gap-2'
                    : 'btn-shady-primary px-8 py-3 text-xs gap-2'
                }
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" />
                    <span>Processing Valuation Engine...</span>
                  </>
                ) : currentStep === 8 ? (
                  <>
                    <span>Generate Market Valuation</span>
                    <Sparkles className="w-4 h-4" />
                  </>
                ) : (
                  <>
                    <span>Next Step</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

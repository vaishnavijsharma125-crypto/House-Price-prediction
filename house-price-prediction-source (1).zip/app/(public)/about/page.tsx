import React from 'react';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import {
  Layers,
  Code2,
  Server,
  Database,
  Cpu,
  CheckCircle2,
  ShieldCheck,
  Building2,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AboutPage() {
  const content = await prisma.websiteContent.findUnique({
    where: { id: 'default' },
  });

  const aboutText =
    content?.aboutProject ||
    'This property valuation and predictive analytics platform demonstrates an end-to-end full-stack valuation system. It integrates dataset management, exploratory data analysis, interactive visual analytics, and an extensible prediction engine.';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header */}
      <div className="border-b border-slate-200 pb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold uppercase tracking-wider mb-2">
          <TrendingUp className="w-3.5 h-3.5" />
          <span>System Architecture & Overview</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          About The Platform
        </h1>
        <p className="text-slate-600 text-sm mt-1 max-w-3xl leading-relaxed">
          Comprehensive documentation on platform objectives, full-stack architectural design, data modeling pipelines, and technical specifications.
        </p>
      </div>

      {/* Main Overview Card */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
            VAL
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              House & Land Price Prediction Analysis System
            </h2>
            <p className="text-xs text-slate-500">
              Real Estate Valuation & Exploratory Data Platform
            </p>
          </div>
        </div>

        <div className="prose prose-slate max-w-none text-sm text-slate-600 leading-relaxed space-y-4">
          <p>{aboutText}</p>
          <p>
            Unlike static frontend mockups or superficial templates, this platform was developed as a genuinely functional production-style system. Every CRUD mutation against properties or website settings persists directly to a relational SQLite database through Prisma ORM. Analytical KPI metrics and charts dynamically recalculate from the database layer rather than static constants.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-100">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-xs text-slate-400 font-bold uppercase">System Edition</span>
            <div className="font-bold text-slate-800 text-sm">Enterprise Valuation Engine</div>
            <div className="text-[11px] text-slate-500">Release v1.0 Production</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-xs text-slate-400 font-bold uppercase">Analytics Domain</span>
            <div className="font-bold text-slate-800 text-sm">Full-Stack Predictive Modeling</div>
            <div className="text-[11px] text-slate-500">Hedonic Regression & Spatial Analytics</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-xs text-slate-400 font-bold uppercase">Database Engine</span>
            <div className="font-bold text-slate-800 text-sm">SQLite + Prisma ORM</div>
            <div className="text-[11px] text-slate-500">ACID Compliant Relational Storage</div>
          </div>
        </div>
      </div>

      {/* Technology Stack Grid */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-slate-900">
          Complete Technology Stack
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-700 flex items-center justify-center">
              <Code2 className="w-4 h-4" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Next.js & React 18</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Modern App Router architecture providing server-rendered pages, API routes, and client interactivity.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Prisma ORM & SQLite</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Real schema migrations, type-safe queries, indexing, and persistent database file on disk.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Tailwind CSS</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Custom design tokens, responsive typography, and streamlined utility classes.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <div className="w-8 h-8 rounded-lg bg-violet-50 text-violet-700 flex items-center justify-center">
              <Cpu className="w-4 h-4" />
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Modular Hedonic Engine</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Deterministic valuation calculation with factor breakdown, structured for future external ML microservices.
            </p>
          </div>
        </div>
      </div>

      {/* Core Objectives Fulfilled */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-lg font-bold text-slate-900">
          Core Technical Capabilities
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>Eliminated dummy/hard-coded values; all KPI counters calculate straight from real relational SQL tables.</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>Provided full Administrator CRUD capabilities allowing properties to be inserted, updated, and purged.</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>Enforced deterministic hedonic regression algorithm that reacts proportionally to inputs without random numbers.</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>Logged every user price calculation to a persistent prediction database table with search and audit capabilities.</span>
          </div>
        </div>
      </div>
    </div>
  );
}

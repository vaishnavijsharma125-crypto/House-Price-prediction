'use client';

import React, { useState, useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  CartesianGrid,
  Legend,
  LineChart,
  Line,
} from 'recharts';
import {
  BarChart3,
  TrendingUp,
  Layers,
  Building,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
} from 'lucide-react';
import { formatIndianCurrency, formatNumber, formatCompactCurrency } from '@/lib/utils';

const COLORS = ['#38bdf8', '#3b82f6', '#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'];

export default function AnalyticsPage() {
  const [data, setData] = useState<any | null>(null);
  const [stats, setStats] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    fetchAnalyticsData();
  }, []);

  const fetchAnalyticsData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [analyticsRes, statsRes] = await Promise.all([
        fetch('/api/analytics'),
        fetch('/api/stats'),
      ]);

      if (!analyticsRes.ok || !statsRes.ok) {
        throw new Error('Failed to load database analytics');
      }

      const analyticsJson = await analyticsRes.json();
      const statsJson = await statsRes.json();

      setData(analyticsJson);
      setStats(statsJson);
    } catch (err: any) {
      setError(err.message || 'Error communicating with database API');
    } finally {
      setLoading(false);
    }
  };

  const CustomTooltipCurrency = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-950/95 border border-slate-700/80 text-white p-3 rounded-xl shadow-2xl backdrop-blur-xl text-xs space-y-1">
          <p className="font-bold text-sky-400">{label || payload[0]?.payload?.name || payload[0]?.payload?.propertyId}</p>
          <p className="text-white font-black text-sm">
            {formatIndianCurrency(payload[0].value)}
          </p>
          {payload[0]?.payload?.count && (
            <p className="text-slate-400 text-[11px]">
              Sample Size: {payload[0].payload.count} units
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  const CustomScatterTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const pt = payload[0].payload;
      return (
        <div className="bg-slate-950/95 border border-slate-700/80 text-white p-3 rounded-xl shadow-2xl backdrop-blur-xl text-xs space-y-1">
          <p className="font-bold text-sky-400">{pt.propertyId}</p>
          <p className="text-slate-200">{pt.location} • {pt.propertyType}</p>
          <p className="text-slate-300">Area: {pt.area} Sq.Ft</p>
          <p className="text-emerald-400 font-bold">{formatIndianCurrency(pt.rawPrice)}</p>
        </div>
      );
    }
    return null;
  };

  if (!isMounted) return null;

  return (
    <div className="bg-industrial-grid min-h-screen text-slate-100 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-slate-800/90 pb-6 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-500/15 border border-sky-400/30 text-sky-300 text-xs font-bold uppercase tracking-wider mb-2 shadow-sm shadow-sky-500/10">
              <BarChart3 className="w-3.5 h-3.5 text-sky-400" />
              <span>Exploratory Data Analysis</span>
            </div>
            <h1 className="text-3xl font-extrabold text-white tracking-tight">
              Real Estate Valuation Analytics
            </h1>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Live descriptive statistical visualizations calculated dynamically from records stored in the SQLite database.
            </p>
          </div>

          <button
            onClick={fetchAnalyticsData}
            className="btn-shady-dark px-4 py-2.5 text-xs gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-sky-400 ${loading ? 'animate-spin' : ''}`} />
            <span>Recalculate Analytics</span>
          </button>
        </div>

        {/* KPI Cards (6 cards required) with Shady Industrial Glass */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {/* Total Properties */}
          <div className="bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60">
            <span className="text-[11px] font-bold text-sky-400/90 uppercase tracking-widest block mb-1">
              Properties
            </span>
            <div className="text-2xl font-black text-white">
              {stats ? formatNumber(stats.totalProperties) : '...'}
            </div>
            <span className="text-[11px] text-slate-500 font-medium">Database entries</span>
          </div>

          {/* Average Price */}
          <div className="bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60">
            <span className="text-[11px] font-bold text-sky-400/90 uppercase tracking-widest block mb-1">
              Avg Price
            </span>
            <div className="text-lg font-black text-white truncate">
              {stats ? formatCompactCurrency(stats.averagePrice) : '...'}
            </div>
            <span className="text-[11px] text-slate-500 font-medium">Arithmetic mean</span>
          </div>

          {/* Average Area */}
          <div className="bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60">
            <span className="text-[11px] font-bold text-sky-400/90 uppercase tracking-widest block mb-1">
              Avg Area
            </span>
            <div className="text-2xl font-black text-white">
              {stats ? formatNumber(stats.averageArea) : '...'}{' '}
              <span className="text-xs font-normal text-slate-400">Sq.Ft</span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium">Usable area</span>
          </div>

          {/* Average Price / Sq.Ft */}
          <div className="bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60">
            <span className="text-[11px] font-bold text-sky-400/90 uppercase tracking-widest block mb-1">
              Rate / Sq.Ft
            </span>
            <div className="text-lg font-black text-sky-400 truncate">
              {stats ? formatIndianCurrency(stats.averagePricePerSqFt) : '...'}
            </div>
            <span className="text-[11px] text-slate-500 font-medium">Baseline density</span>
          </div>

          {/* Highest Price */}
          <div className="bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60">
            <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-widest block mb-1 flex items-center gap-1">
              <span>Peak Price</span>
              <ArrowUpRight className="w-3 h-3 text-emerald-400" />
            </span>
            <div className="text-lg font-black text-emerald-400 truncate">
              {stats ? formatCompactCurrency(stats.highestPrice) : '...'}
            </div>
            <span className="text-[11px] text-slate-500 font-medium">Peak valuation</span>
          </div>

          {/* Lowest Price */}
          <div className="bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60">
            <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-widest block mb-1 flex items-center gap-1">
              <span>Floor Price</span>
              <ArrowDownRight className="w-3 h-3 text-indigo-400" />
            </span>
            <div className="text-lg font-black text-slate-200 truncate">
              {stats ? formatCompactCurrency(stats.lowestPrice) : '...'}
            </div>
            <span className="text-[11px] text-slate-500 font-medium">Floor valuation</span>
          </div>
        </div>

        {loading ? (
          <div className="p-20 text-center space-y-3 bg-slate-900/80 rounded-3xl border border-slate-800 shadow-xl">
            <div className="w-10 h-10 border-3 border-sky-500/30 border-t-sky-400 rounded-full animate-spin mx-auto" />
            <p className="text-sm text-slate-400 font-medium">Generating statistical aggregations from database...</p>
          </div>
        ) : error ? (
          <div className="p-12 text-center text-rose-400 bg-slate-900/80 rounded-3xl border border-rose-900/50 shadow-xl">
            <p className="font-semibold">{error}</p>
          </div>
        ) : (
          /* The 8 Interactive Charts Styled with Dark Industrial Shady Cards */
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Chart 1: Average Price by Location */}
            <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">
                  1. Average Price by Location
                </h3>
                <p className="text-xs text-slate-400">
                  Mean property values across metropolitan geographical markets.
                </p>
              </div>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data?.priceByLocation || []} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                    <XAxis dataKey="location" angle={-25} textAnchor="end" interval={0} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <YAxis tickFormatter={(v) => `₹${(v / 10000000).toFixed(1)}Cr`} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <Tooltip content={<CustomTooltipCurrency />} />
                    <Bar dataKey="avgPrice" fill="#0284c7" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Price vs Area */}
            <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">
                  2. Price vs Area (Sq.Ft)
                </h3>
                <p className="text-xs text-slate-400">
                  Scatter dispersion showing price elasticity against square footage.
                </p>
              </div>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 10, right: 20, left: 10, bottom: 25 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis type="number" dataKey="area" name="Area" unit=" sqft" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <YAxis type="number" dataKey="price" name="Price" unit=" L" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <Tooltip content={<CustomScatterTooltip />} />
                    <Scatter data={data?.priceVsArea || []} fill="#38bdf8" fillOpacity={0.8} />
                  </ScatterChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 3: Price/Sq.Ft by Location */}
            <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">
                  3. Price / Sq.Ft by Location
                </h3>
                <p className="text-xs text-slate-400">
                  Unit density metric normalized by total square footage per city.
                </p>
              </div>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data?.pricePerSqFtByLocation || []} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                    <XAxis dataKey="location" angle={-25} textAnchor="end" interval={0} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <YAxis tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <Tooltip content={<CustomTooltipCurrency />} />
                    <Bar dataKey="avgPricePerSqFt" fill="#6366f1" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 4: Property Type Distribution */}
            <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">
                  4. Property Type Distribution
                </h3>
                <p className="text-xs text-slate-400">
                  Composition of housing typologies in the empirical database.
                </p>
              </div>
              <div className="h-72 w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={data?.propertyTypeDistribution || []}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={95}
                      paddingAngle={3}
                      dataKey="count"
                      label={({ name, percentage }) => `${name} (${percentage}%)`}
                    >
                      {(data?.propertyTypeDistribution || []).map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
                      formatter={(value: any, name: any, props: any) => [
                        `${value} properties (${props.payload.percentage}%)`,
                        props.payload.name,
                      ]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 5: Bedroom vs Price */}
            <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">
                  5. Bedroom Configuration vs Price
                </h3>
                <p className="text-xs text-slate-400">
                  Average valuation increment across room count specifications.
                </p>
              </div>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data?.bedroomVsPrice || []} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                    <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <YAxis tickFormatter={(v) => `₹${(v / 10000000).toFixed(1)}Cr`} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <Tooltip content={<CustomTooltipCurrency />} />
                    <Bar dataKey="avgPrice" fill="#10b981" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 6: Property Age vs Price */}
            <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">
                  6. Property Age vs Price (Depreciation Trend)
                </h3>
                <p className="text-xs text-slate-400">
                  Average valuation comparison across age cohorts.
                </p>
              </div>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data?.propertyAgeVsPrice || []} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                    <XAxis dataKey="ageGroup" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <YAxis tickFormatter={(v) => `₹${(v / 10000000).toFixed(1)}Cr`} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <Tooltip content={<CustomTooltipCurrency />} />
                    <Bar dataKey="avgPrice" fill="#f59e0b" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 7: Furnishing vs Price */}
            <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">
                  7. Furnishing Status vs Average Price
                </h3>
                <p className="text-xs text-slate-400">
                  Valuation premium associated with semi and fully furnished interiors.
                </p>
              </div>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data?.furnishingVsPrice || []} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                    <XAxis dataKey="furnishing" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <YAxis tickFormatter={(v) => `₹${(v / 10000000).toFixed(1)}Cr`} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <Tooltip content={<CustomTooltipCurrency />} />
                    <Bar dataKey="avgPrice" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 8: Locality Rating vs Price */}
            <div className="bg-slate-900/90 p-6 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">
                  8. Locality Rating vs Price
                </h3>
                <p className="text-xs text-slate-400">
                  Correlation between municipal neighborhood rating score and property valuation.
                </p>
              </div>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data?.localityRatingVsPrice || []} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                    <XAxis dataKey="ratingTier" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <YAxis tickFormatter={(v) => `₹${(v / 10000000).toFixed(1)}Cr`} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                    <Tooltip content={<CustomTooltipCurrency />} />
                    <Bar dataKey="avgPrice" fill="#0284c7" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

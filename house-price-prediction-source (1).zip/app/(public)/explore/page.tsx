'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
  Database,
  Search,
  Filter,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  X,
  Building,
  MapPin,
  Maximize2,
  Calendar,
  Layers,
  Car,
  Sofa,
  Navigation,
  Star,
  CheckCircle2,
  RefreshCw,
  LayoutGrid,
  List,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { formatIndianCurrency, formatCompactCurrency, formatNumber, formatDate, getPropertyImageUrl } from '@/lib/utils';
import PropertyCard from '@/components/PropertyCard';

function ExploreContent() {
  const searchParams = useSearchParams();

  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // View mode: 'cards' or 'table'
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  // Filter & Search states
  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [location, setLocation] = useState(searchParams.get('location') || 'All');
  const [propertyType, setPropertyType] = useState(searchParams.get('propertyType') || 'All');
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Available options
  const [availableLocations, setAvailableLocations] = useState<string[]>([]);
  const [availableTypes, setAvailableTypes] = useState<string[]>([]);

  // Selected property for modal
  const [selectedProperty, setSelectedProperty] = useState<any | null>(null);

  const fetchProperties = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: viewMode === 'cards' ? '9' : '12',
        search,
        city: location === 'All' ? '' : location,
        propertyType: propertyType === 'All' ? '' : propertyType,
        sortBy,
        sortOrder,
      });

      const res = await fetch(`/api/properties?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch property records');
      const data = await res.json();

      setProperties(data.properties || []);
      setTotalPages(data.pagination.totalPages || 1);
      setTotalCount(data.pagination.total || 0);

      if (data.filters) {
        setAvailableLocations(data.filters.cities || []);
        setAvailableTypes(data.filters.propertyTypes || []);
      }
    } catch (err: any) {
      setError(err.message || 'Error loading inventory.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties();
  }, [page, location, propertyType, sortBy, sortOrder, viewMode]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchProperties();
  };

  const handleSortToggle = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
    setPage(1);
  };

  return (
    <div className="bg-industrial-grid min-h-screen text-slate-100 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header with Title & View Mode Toggle */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-slate-800/90 pb-6 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/15 border border-sky-400/30 text-sky-300 text-xs font-bold uppercase tracking-wider mb-2 shadow-sm shadow-sky-500/10">
              <Building className="w-3.5 h-3.5 text-sky-400" />
              <span>Verified Market Inventory</span>
            </div>
            <h1 className="text-3xl font-extrabold text-white tracking-tight">
              Explore Properties & Land
            </h1>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Live commercial real estate listings across premier metropolitan corridors with RERA verification and deterministic valuation benchmarks.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs px-3.5 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-bold flex items-center gap-1.5 shadow-md">
              <span className="w-2 h-2 rounded-full bg-emerald-400 radar-dot"></span>
              <span>RERA VERIFIED INVENTORY</span>
            </span>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-slate-800 shadow-md">
              <button
                onClick={() => setViewMode('cards')}
                className={`p-1.5 rounded-lg transition-all ${
                  viewMode === 'cards'
                    ? 'bg-sky-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Card Grid View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-lg transition-all ${
                  viewMode === 'table'
                    ? 'bg-sky-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Detailed Table View"
              >
                <List className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={() => fetchProperties()}
              className="p-2 text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors border border-slate-800 shadow-md"
              title="Refresh Inventory"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-sky-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* 99acres-Style Filter & Search Bar with Shady Dark Glass */}
        <div className="bg-slate-900/90 backdrop-blur-2xl p-5 rounded-3xl border border-slate-800 shadow-2xl shadow-black/80 space-y-4">
          <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3">
            <div className="md:col-span-5 relative group">
              <Search className="w-4 h-4 text-sky-400 absolute left-3.5 top-3.5 group-hover:scale-110 transition-transform" />
              <input
                type="text"
                placeholder="Search by code, title, locality, or landmark..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-700/80 bg-slate-950/70 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20 transition-all"
              />
            </div>

            <div className="md:col-span-3">
              <select
                value={location}
                onChange={(e) => {
                  setLocation(e.target.value);
                  setPage(1);
                }}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-700/80 bg-slate-950/70 text-sm font-semibold text-slate-200 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20 cursor-pointer transition-all"
              >
                <option value="All" className="bg-slate-900 text-white">All Metropolitan Hubs</option>
                {availableLocations.map((loc) => (
                  <option key={loc} value={loc} className="bg-slate-900 text-white">
                    {loc}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2">
              <select
                value={propertyType}
                onChange={(e) => {
                  setPropertyType(e.target.value);
                  setPage(1);
                }}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-700/80 bg-slate-950/70 text-sm font-semibold text-slate-200 focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20 cursor-pointer transition-all"
              >
                <option value="All" className="bg-slate-900 text-white">All Types</option>
                {availableTypes.map((type) => (
                  <option key={type} value={type} className="bg-slate-900 text-white">
                    {type}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2 flex gap-2">
              <button
                type="submit"
                className="btn-shady-primary w-full py-2.5 px-4 text-xs tracking-wider"
              >
                Search
              </button>
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setLocation('All');
                  setPropertyType('All');
                  setSortBy('createdAt');
                  setSortOrder('desc');
                  setPage(1);
                }}
                className="btn-shady-dark px-3 py-2.5 text-xs text-slate-300"
                title="Reset Filters"
              >
                Reset
              </button>
            </div>
          </form>

          <div className="flex flex-wrap items-center justify-between text-xs text-slate-400 pt-3 border-t border-slate-800">
            <span>
              Showing <strong className="text-white">{properties.length}</strong> of{' '}
              <strong className="text-white">{totalCount}</strong> verified properties
            </span>
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-semibold">Sort by:</span>
              <button
                onClick={() => handleSortToggle('expectedPrice')}
                className={`px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-all ${
                  sortBy === 'expectedPrice'
                    ? 'bg-sky-500/20 border-sky-400/50 text-sky-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span>Price</span>
                {sortBy === 'expectedPrice' && <ArrowUpDown className="w-3 h-3 text-sky-400" />}
              </button>
              <button
                onClick={() => handleSortToggle('areaSqFt')}
                className={`px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-all ${
                  sortBy === 'areaSqFt'
                    ? 'bg-sky-500/20 border-sky-400/50 text-sky-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span>Area</span>
                {sortBy === 'areaSqFt' && <ArrowUpDown className="w-3 h-3 text-sky-400" />}
              </button>
              <button
                onClick={() => handleSortToggle('createdAt')}
                className={`px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-all ${
                  sortBy === 'createdAt'
                    ? 'bg-sky-500/20 border-sky-400/50 text-sky-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span>Latest</span>
                {sortBy === 'createdAt' && <ArrowUpDown className="w-3 h-3 text-sky-400" />}
              </button>
            </div>
          </div>
        </div>

        {/* Main Content: Shady Card Grid or Table */}
        {loading ? (
          <div className="p-16 text-center space-y-3 bg-slate-900/80 rounded-3xl border border-slate-800 shadow-xl">
            <div className="w-8 h-8 border-3 border-sky-500/30 border-t-sky-400 rounded-full animate-spin mx-auto" />
            <p className="text-xs text-slate-400 font-medium">Fetching verified properties...</p>
          </div>
        ) : error ? (
          <div className="p-12 text-center text-rose-400 text-sm bg-slate-900/80 rounded-3xl border border-rose-900/50 shadow-xl">
            <p>{error}</p>
            <button
              onClick={() => fetchProperties()}
              className="mt-3 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              Retry Connection
            </button>
          </div>
        ) : properties.length === 0 ? (
          <div className="p-16 text-center space-y-3 bg-slate-900/80 rounded-3xl border border-slate-800 shadow-xl">
            <Building className="w-10 h-10 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-white">No properties match your filter</h3>
            <p className="text-xs text-slate-400">
              Try adjusting your search criteria, city selection, or resetting filters.
            </p>
          </div>
        ) : viewMode === 'cards' ? (
          /* Visual 99acres-Style Property Cards */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((p) => (
              <PropertyCard
                key={p.id}
                property={p}
                onView={(prop) => setSelectedProperty(prop)}
              />
            ))}
          </div>
        ) : (
          /* Dense Analytical Dark Table View */
          <div className="bg-slate-900/90 rounded-3xl border border-slate-800 shadow-2xl shadow-black/80 overflow-hidden backdrop-blur-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-bold tracking-wider">
                  <tr>
                    <th className="py-4 px-4">Property</th>
                    <th className="py-4 px-4">Type</th>
                    <th className="py-4 px-4">Location</th>
                    <th className="py-4 px-4">Area (Sq.Ft)</th>
                    <th className="py-4 px-4">Layout</th>
                    <th className="py-4 px-4">Price</th>
                    <th className="py-4 px-4">Price / Sq.Ft</th>
                    <th className="py-4 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 text-slate-300">
                  {properties.map((p) => {
                    const price = p.expectedPrice ?? p.price ?? 0;
                    const area = p.areaSqFt ?? p.area ?? 1;
                    const locText = p.location ? (typeof p.location === 'object' ? `${p.location.locality}, ${p.location.city}` : p.location) : 'Metro';
                    return (
                      <tr key={p.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-sky-400">
                          {p.propertyCode || p.propertyId || `PROP-${p.id}`}
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2.5 py-0.5 rounded-lg font-medium text-[11px] bg-slate-950 text-slate-300 border border-slate-800">
                            {p.propertyType}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-medium text-white">{locText}</td>
                        <td className="py-3 px-4 font-mono">{formatNumber(area)}</td>
                        <td className="py-3 px-4">{p.bedrooms > 0 ? `${p.bedrooms} BHK` : 'Plot'}</td>
                        <td className="py-3 px-4 font-bold text-white">
                          {formatCompactCurrency(price)}
                        </td>
                        <td className="py-3 px-4 text-sky-400 font-semibold">
                          ₹{Math.round(price / Math.max(1, area)).toLocaleString('en-IN')}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => setSelectedProperty(p)}
                            className="btn-shady-dark px-3 py-1 text-xs gap-1"
                          >
                            <Eye className="w-3 h-3 text-sky-400" />
                            <span>View</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Pagination Bar */}
        <div className="p-4 border border-slate-800 rounded-3xl bg-slate-900/90 flex items-center justify-between text-xs text-slate-400 shadow-xl backdrop-blur-xl">
          <div>
            Page <strong className="text-white">{page}</strong> of{' '}
            <strong className="text-white">{totalPages}</strong>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((prev) => Math.max(1, prev - 1))}
              disabled={page <= 1 || loading}
              className="btn-shady-dark px-3 py-1.5 text-xs font-semibold disabled:opacity-40 disabled:cursor-not-allowed gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>
            <button
              onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
              disabled={page >= totalPages || loading}
              className="btn-shady-dark px-3 py-1.5 text-xs font-semibold disabled:opacity-40 disabled:cursor-not-allowed gap-1"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 99acres-Style Property Details Shady Modal */}
        {selectedProperty && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
            <div className="bg-slate-900 rounded-3xl max-w-2xl w-full shadow-2xl shadow-black border border-slate-700/80 overflow-hidden max-h-[90vh] flex flex-col">
              {/* Modal Image Header */}
              <div className="relative aspect-[16/9] bg-slate-950 shrink-0">
                <img
                  src={getPropertyImageUrl(selectedProperty)}
                  alt={selectedProperty.title || 'Property View'}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-black/40" />

                <button
                  onClick={() => setSelectedProperty(null)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-slate-950/80 backdrop-blur-md text-white hover:bg-slate-800 transition-colors z-20 border border-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="absolute bottom-4 left-5 right-5 text-white z-10 flex items-end justify-between">
                  <div>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-emerald-950/85 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold uppercase tracking-wider mb-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 radar-dot"></span>
                      <span>RERA Verified</span>
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-black text-white">
                      {formatIndianCurrency(selectedProperty.expectedPrice ?? selectedProperty.price ?? 0)}
                    </h3>
                    <p className="text-xs text-sky-300">
                      ₹{Math.round((selectedProperty.expectedPrice ?? selectedProperty.price ?? 0) / Math.max(1, selectedProperty.areaSqFt ?? selectedProperty.area ?? 1)).toLocaleString('en-IN')} / sq.ft
                    </p>
                  </div>
                  <span className="px-3 py-1 rounded-xl bg-sky-500/20 backdrop-blur-md border border-sky-400/30 text-sky-300 text-xs font-bold">
                    {selectedProperty.propertyType}
                  </span>
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-6 overflow-y-auto">
                <div>
                  <span className="text-xs font-mono font-bold text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded-lg border border-sky-500/30">
                    {selectedProperty.propertyCode || selectedProperty.propertyId}
                  </span>
                  <h4 className="text-lg font-bold text-white mt-1.5">
                    {selectedProperty.title || `${selectedProperty.bedrooms || 2} BHK ${selectedProperty.propertyType}`}
                  </h4>
                  <p className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                    <MapPin className="w-3.5 h-3.5 text-sky-400" />
                    <span>
                      {selectedProperty.address || ''}{' '}
                      {selectedProperty.location?.locality ? `• ${selectedProperty.location.locality}, ${selectedProperty.location.city}` : ''}
                    </span>
                  </p>
                  {selectedProperty.description && (
                    <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                      {selectedProperty.description}
                    </p>
                  )}
                </div>

                {/* Specs Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800">
                    <span className="text-slate-500 block mb-0.5">Carpet Area</span>
                    <span className="font-bold text-white text-sm">
                      {formatNumber(selectedProperty.areaSqFt ?? selectedProperty.area)} Sq.Ft
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800">
                    <span className="text-slate-500 block mb-0.5">Configuration</span>
                    <span className="font-bold text-white text-sm">
                      {selectedProperty.bedrooms > 0 ? `${selectedProperty.bedrooms} BHK` : 'Plot'} / {selectedProperty.bathrooms || 1} Bath
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800">
                    <span className="text-slate-500 block mb-0.5">Floor Level</span>
                    <span className="font-bold text-white text-sm">
                      {selectedProperty.floor > 0 ? `${selectedProperty.floor} of ${selectedProperty.totalFloors || 10}` : 'Ground'}
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800">
                    <span className="text-slate-500 block mb-0.5">Property Age</span>
                    <span className="font-bold text-white text-sm">
                      {selectedProperty.propertyAge ?? 0} Years
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800">
                    <span className="text-slate-500 block mb-0.5">Parking</span>
                    <span className="font-bold text-white text-sm">
                      {selectedProperty.parking || 'Yes'}
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800">
                    <span className="text-slate-500 block mb-0.5">Furnishing</span>
                    <span className="font-bold text-white text-sm">
                      {selectedProperty.furnishing || 'Semi-Furnished'}
                    </span>
                  </div>
                </div>

                {/* Call to Action Bar */}
                <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <Link
                    href={`/predict?propertyType=${encodeURIComponent(selectedProperty.propertyType)}&area=${selectedProperty.areaSqFt ?? selectedProperty.area}&bedrooms=${selectedProperty.bedrooms || 2}&bathrooms=${selectedProperty.bathrooms || 2}&location=${encodeURIComponent(selectedProperty.location?.city || 'Mumbai')}&locality=${encodeURIComponent(selectedProperty.location?.locality || 'Bandra West')}`}
                    className="btn-shady-primary w-full sm:w-auto px-6 py-2.5 text-xs gap-2"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-sky-200" />
                    <span>Check Hedonic Valuation Benchmark</span>
                  </Link>

                  <button
                    onClick={() => setSelectedProperty(null)}
                    className="btn-shady-dark w-full sm:w-auto px-5 py-2.5 text-xs"
                  >
                    Close Window
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ExploreDatasetPage() {
  return (
    <Suspense
      fallback={
        <div className="bg-industrial-grid min-h-screen text-slate-100 flex items-center justify-center p-16">
          <div className="text-center space-y-3">
            <div className="w-8 h-8 border-3 border-sky-500/30 border-t-sky-400 rounded-full animate-spin mx-auto" />
            <p className="text-xs text-slate-400 font-medium">Loading Property Inventory...</p>
          </div>
        </div>
      }
    >
      <ExploreContent />
    </Suspense>
  );
}

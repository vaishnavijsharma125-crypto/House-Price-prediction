import React from 'react';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import {
  TrendingUp,
  Building,
  Layers,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Search,
  SlidersHorizontal,
  BarChart4,
  ExternalLink,
  MapPin,
  Building2,
  Briefcase,
  Home,
  Check,
  Zap,
} from 'lucide-react';
import { formatIndianCurrency, formatNumber, formatCompactCurrency } from '@/lib/utils';
import HeroSearchBar from '@/components/HeroSearchBar';
import PropertyCard from '@/components/PropertyCard';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function HomePage() {
  // Query live database records directly
  const totalProperties = await prisma.property.count({ where: { isDeleted: false } });
  const aggregations = await prisma.property.aggregate({
    where: { isDeleted: false },
    _avg: {
      expectedPrice: true,
      areaSqFt: true,
    },
  });

  const averagePrice = Math.round(aggregations._avg.expectedPrice || 0);
  const averageArea = Math.round(aggregations._avg.areaSqFt || 0);
  const averagePricePerSqFt =
    averageArea > 0 ? Math.round(averagePrice / averageArea) : 0;

  // Fetch featured / recent properties with locations and images
  const recentProperties = await prisma.property.findMany({
    where: { isDeleted: false },
    orderBy: { createdAt: 'desc' },
    take: 6,
    include: {
      location: true,
      images: true,
    },
  });

  // Fetch locations for autocomplete/search options
  const locations = await prisma.location.findMany({
    where: { isActive: true },
    select: { city: true, locality: true },
    orderBy: { city: 'asc' },
  });

  // Top localities price trends
  const localityTrends = [
    {
      locality: 'Bandra West',
      city: 'Mumbai',
      avgPricePerSqFt: 38000,
      annualGrowth: '+12.4%',
      tier: 'Luxury',
      image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=600&q=80',
    },
    {
      locality: 'Indiranagar',
      city: 'Bangalore',
      avgPricePerSqFt: 14500,
      annualGrowth: '+9.8%',
      tier: 'Prime',
      image: 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=600&q=80',
    },
    {
      locality: 'DLF Phase 5',
      city: 'Gurgaon / Delhi',
      avgPricePerSqFt: 18200,
      annualGrowth: '+11.2%',
      tier: 'Prime',
      image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=600&q=80',
    },
    {
      locality: 'Koregaon Park',
      city: 'Pune',
      avgPricePerSqFt: 12500,
      annualGrowth: '+8.5%',
      tier: 'Prime',
      image: 'https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=600&q=80',
    },
    {
      locality: 'Gachibowli',
      city: 'Hyderabad',
      avgPricePerSqFt: 9100,
      annualGrowth: '+14.1%',
      tier: 'High Growth',
      image: 'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?auto=format&fit=crop&w=600&q=80',
    },
    {
      locality: 'Worli',
      city: 'Mumbai',
      avgPricePerSqFt: 42000,
      annualGrowth: '+10.5%',
      tier: 'Ultra Luxury',
      image: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=600&q=80',
    },
  ];

  // Property typologies for visual category browsing
  const typologies = [
    {
      title: 'Residential Apartments',
      subtitle: 'Modern high-rises & gated communities',
      startingPrice: '₹ 45 Lakh',
      typeParam: 'Apartment',
      imageUrl: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=800&q=80',
      badge: 'High Demand',
    },
    {
      title: 'Luxury Villas & Houses',
      subtitle: 'Architectural independent residences',
      startingPrice: '₹ 1.25 Crore',
      typeParam: 'Villa/House',
      imageUrl: 'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=800&q=80',
      badge: 'Ultra Luxury',
    },
    {
      title: 'Commercial Offices & IT Parks',
      subtitle: 'Grade-A tech hubs & retail spaces',
      startingPrice: '₹ 1.80 Crore',
      typeParam: 'Commercial',
      imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80',
      badge: 'Institutional',
    },
    {
      title: 'RERA Approved Plots & Land',
      subtitle: 'Clear-title residential land parcels',
      startingPrice: '₹ 35 Lakh',
      typeParam: 'Plot/Land',
      imageUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80',
      badge: 'High Appreciation',
    },
  ];

  return (
    <div className="bg-industrial-grid min-h-screen text-slate-100 space-y-20 pb-24 overflow-hidden">
      {/* 99acres-Style High-Impact Hero Section with Atmospheric Industrial Glow */}
      <section className="relative pt-12 pb-24 border-b border-slate-800/80 overflow-hidden">
        {/* Ambient Industrial Glow Spheres */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-sky-500/15 blur-[120px] rounded-full pointer-events-none -z-10 animate-pulse-slow" />
        <div className="absolute top-10 left-10 w-96 h-96 bg-indigo-500/10 blur-[100px] rounded-full pointer-events-none -z-10" />

        {/* Industrial Architectural Background Image with Deep Shady Gradient */}
        <div className="absolute inset-0 -z-20">
          <img
            src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=2200&q=80"
            alt="Commercial Real Estate Facade"
            className="w-full h-full object-cover opacity-20 filter grayscale contrast-150"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/95 via-slate-950/90 to-[#050811]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          {/* Header Typography with Animated Floating Badge */}
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/80 text-xs font-bold uppercase tracking-wider backdrop-blur-xl shadow-lg animate-float">
              <span className="w-2 h-2 rounded-full radar-dot mr-1"></span>
              <span className="theme-gradient-text">RERA Benchmarked • Institutional Valuation Intelligence</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight">
              HOUSE & LAND <br className="hidden sm:inline" />
              <span className="theme-gradient-text">
                PRICE PREDICTION ANALYSIS
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal max-w-2xl mx-auto">
              Empowering home buyers, institutional investors, and property owners with empirical transaction data, locality price trends, and deterministic valuation algorithms.
            </p>
          </div>

          {/* 99acres-Style Tabbed Search Bar */}
          <HeroSearchBar locations={locations} />

          {/* Live Platform Numbers from Database Styled Like Industrial Telemetry Monitored Gauges */}
          <div className="pt-4 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <div className="relative group bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60 hover:border-sky-500/50 hover:shadow-sky-500/20 transition-all duration-300 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-sky-500 to-transparent opacity-50 group-hover:opacity-100 transition-opacity" />
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
                <span>Verified Listings</span>
                <Building className="w-4 h-4 text-sky-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white">
                {formatNumber(totalProperties)}
              </div>
              <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 radar-dot"></span>
                <span>Active Database Records</span>
              </p>
            </div>

            <div className="relative group bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60 hover:border-emerald-500/50 hover:shadow-emerald-500/20 transition-all duration-300 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-emerald-500 to-transparent opacity-50 group-hover:opacity-100 transition-opacity" />
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
                <span>Average Property Price</span>
                <TrendingUp className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white">
                {formatCompactCurrency(averagePrice)}
              </div>
              <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 radar-dot"></span>
                <span>Arithmetic Market Mean</span>
              </p>
            </div>

            <div className="relative group bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60 hover:border-indigo-500/50 hover:shadow-indigo-500/20 transition-all duration-300 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent opacity-50 group-hover:opacity-100 transition-opacity" />
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
                <span>Average Built-Up Area</span>
                <Layers className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white">
                {formatNumber(averageArea)}{' '}
                <span className="text-sm font-medium text-slate-400">Sq.Ft</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 radar-dot"></span>
                <span>Carpet & Dimension Sync</span>
              </p>
            </div>

            <div className="relative group bg-slate-900/85 backdrop-blur-xl p-5 rounded-3xl border border-slate-800 shadow-xl shadow-black/60 hover:border-amber-500/50 hover:shadow-amber-500/20 transition-all duration-300 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent opacity-50 group-hover:opacity-100 transition-opacity" />
              <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
                <span>Average Rate / Sq.Ft</span>
                <BarChart4 className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white">
                ₹{averagePricePerSqFt.toLocaleString('en-IN')}
              </div>
              <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 radar-dot"></span>
                <span>Normalized Benchmark</span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Explore by Property Typology (99acres Visual Categories with Shady Hover) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-400 uppercase tracking-widest mb-1.5">
              <Zap className="w-3.5 h-3.5 text-sky-400" />
              <span>Property Portfolios</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Explore by Property Typology
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Browse residential apartments, luxury architectural villas, Grade-A IT offices, and commercial land plots.
            </p>
          </div>
          <Link
            href="/explore"
            className="btn-shady-dark px-4 py-2 text-xs gap-1.5"
          >
            <span>View all categories</span>
            <ArrowRight className="w-3.5 h-3.5 text-sky-400" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {typologies.map((t) => (
            <Link
              key={t.title}
              href={`/explore?propertyType=${encodeURIComponent(t.typeParam)}`}
              className="group relative rounded-3xl overflow-hidden shadow-2xl shadow-black/80 hover:shadow-sky-500/25 transition-all duration-500 border border-slate-800 hover:border-sky-500/50 bg-slate-950 flex flex-col justify-end aspect-[4/5]"
            >
              <img
                src={t.imageUrl}
                alt={t.title}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />

              <div className="relative p-5 space-y-2 z-10 text-white">
                <span className="inline-block px-3 py-1 rounded-full bg-sky-500/20 backdrop-blur-md border border-sky-400/30 text-[10px] font-extrabold uppercase tracking-wider text-sky-300 shadow-md">
                  {t.badge}
                </span>
                <h3 className="text-lg font-bold text-white group-hover:text-sky-300 transition-colors">
                  {t.title}
                </h3>
                <p className="text-xs text-slate-300 line-clamp-1">
                  {t.subtitle}
                </p>
                <div className="pt-2 flex items-center justify-between text-xs font-semibold text-slate-200 border-t border-slate-700/60">
                  <span>From {t.startingPrice}</span>
                  <span className="flex items-center gap-1 text-sky-400 group-hover:translate-x-1.5 transition-transform font-bold">
                    <span>Explore</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured & Verified Properties (99acres Visual Listing Grid) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-6 border-b border-slate-800/80 gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                Featured Verified Properties
              </h2>
              <span className="text-xs px-3 py-1 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-bold tracking-wide flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 radar-dot"></span>
                <span>RERA VERIFIED</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              Curated verified inventory across top tier metropolitan hubs backed by official registry benchmarks.
            </p>
          </div>
          <Link
            href="/explore"
            className="btn-shady-dark px-4 py-2 text-xs gap-1.5"
          >
            <span>Explore all {totalProperties} listings</span>
            <ExternalLink className="w-3.5 h-3.5 text-sky-400" />
          </Link>
        </div>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {recentProperties.map((prop: any) => (
            <PropertyCard key={prop.id} property={prop} />
          ))}
        </div>
      </section>

      {/* 99acres-Style Locality Price Trends Widget with Industrial Blueprint Container */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl p-6 sm:p-10 border border-slate-800/90 bg-slate-900/85 backdrop-blur-2xl shadow-2xl shadow-black/80 space-y-8 overflow-hidden">
          {/* Subtle Ambient Blueprint Grid Lines */}
          <div className="absolute inset-0 bg-industrial-blueprint opacity-40 pointer-events-none -z-10" />

          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-sky-400 block mb-1">
                Market Pulse & Intelligence
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Top Locality Price Trends (2026)
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                Annual appreciation rates, average square-foot valuations, and demand tiers across prime metropolitan micro-markets.
              </p>
            </div>
            <Link
              href="/analytics"
              className="btn-shady-dark px-4 py-2.5 text-xs gap-2"
            >
              <BarChart4 className="w-4 h-4 text-sky-400" />
              <span>Full Analytics Dashboard</span>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {localityTrends.map((loc) => (
              <div
                key={loc.locality}
                className="group bg-slate-950/80 rounded-2xl p-4 border border-slate-800 hover:border-sky-500/40 shadow-xl shadow-black/60 hover:shadow-sky-500/10 transition-all duration-300 flex items-center gap-4"
              >
                <img
                  src={loc.image}
                  alt={loc.locality}
                  className="w-20 h-20 rounded-xl object-cover shrink-0 group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between text-xs mb-0.5">
                    <span className="font-bold text-white truncate group-hover:text-sky-300 transition-colors">{loc.locality}</span>
                    <span className="font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded text-[10px]">
                      {loc.annualGrowth} YoY
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">{loc.city}</div>
                  <div className="mt-2 flex items-baseline justify-between text-xs">
                    <span className="font-black text-sky-300 text-sm">
                      ₹{loc.avgPricePerSqFt.toLocaleString('en-IN')}/sqft
                    </span>
                    <span className="text-[10px] text-slate-500 font-semibold uppercase">{loc.tier}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Commercial Algorithmic Valuation Teaser (99acres Priceometer Equivalent) with Shady Gold Accents */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-[#0c1a2e] p-8 sm:p-12 text-white shadow-2xl shadow-black/90 border border-sky-500/30">
          <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-15 pointer-events-none hidden md:block">
            <img
              src="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80"
              alt="Real Estate Analytics"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="relative z-10 max-w-2xl space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/15 border border-amber-400/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>Multi-Factor Econometric Engine</span>
            </div>

            <h3 className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight">
              Wondering What Your Property is Worth in Today's Market?
            </h3>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Our automated valuation engine calculates fair market valuation using 12+ real-world property dimensions: location price indices, carpet dimensions, structural age depreciation, floor height elevation, and road frontage.
            </p>

            <div className="pt-2 flex flex-wrap gap-4">
              <Link
                href="/predict"
                className="btn-shady-amber px-8 py-3.5 text-sm gap-2 shadow-xl shadow-amber-500/30"
              >
                <span>Calculate Fair Value Now</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/methodology"
                className="btn-shady-dark px-6 py-3.5 text-sm gap-2"
              >
                <span>Read Valuation Logic</span>
              </Link>
            </div>

            <div className="pt-3 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-slate-400 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Deterministic Model</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Zero Random Generation</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Instant PDF/Print Report</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Industrial & Enterprise Architecture Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-xs font-bold uppercase tracking-widest text-sky-400 mb-2">
            Enterprise Architecture
          </h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-white">
            Engineered for Precision, Data Rigor & High Throughput
          </p>
          <p className="text-sm text-slate-400 mt-2">
            Every feature connects directly to persistent relational storage, empirical sub-registrar records, and deterministic mathematical calculations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-900/85 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 shadow-xl shadow-black/60 hover:border-sky-500/40 transition-all duration-300 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/15 border border-sky-400/30 text-sky-400 flex items-center justify-center shadow-lg shadow-sky-500/20">
              <SlidersHorizontal className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">
              Transparent Hedonic Engine
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              No black-box or random outputs. Built on econometric principles adjusting for location coefficients, building age depreciation, floor height, locality score, and accessibility.
            </p>
            <div className="pt-2">
              <Link
                href="/methodology"
                className="inline-flex items-center text-xs font-bold text-sky-400 hover:text-sky-300 transition-colors"
              >
                <span>Inspect Mathematical Model</span>
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Link>
            </div>
          </div>

          <div className="bg-slate-900/85 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 shadow-xl shadow-black/60 hover:border-emerald-500/40 transition-all duration-300 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-400/30 text-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <BarChart4 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">
              Live Exploratory Data Analysis
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Interactive data visualizations displaying price distribution curves, bedroom-to-value correlation, and micro-market volatility recalculating automatically on database changes.
            </p>
            <div className="pt-2">
              <Link
                href="/analytics"
                className="inline-flex items-center text-xs font-bold text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                <span>Launch Analytics Dashboard</span>
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Link>
            </div>
          </div>

          <div className="bg-slate-900/85 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 shadow-xl shadow-black/60 hover:border-indigo-500/40 transition-all duration-300 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/15 border border-indigo-400/30 text-indigo-400 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">
              Transaction Registry Verification
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Structured database tracking deed transactions, timestamped registry entries, and audited lead conversions across 8 top metropolitan real estate corridors.
            </p>
            <div className="pt-2">
              <Link
                href="/explore"
                className="inline-flex items-center text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors"
              >
                <span>Explore Property Dataset</span>
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

import React from 'react';
import Link from 'next/link';
import {
  BookOpen,
  ArrowDown,
  Database,
  CheckCircle,
  Cpu,
  BarChart3,
  Calculator,
  Scale,
  GitBranch,
  ShieldCheck,
  AlertTriangle,
  Lightbulb,
} from 'lucide-react';

const WORKFLOW_STEPS = [
  {
    step: '01',
    title: 'Data Collection',
    desc: 'Aggregating structured housing records encompassing location indices, physical footprint (area, bedrooms, bathrooms, floors), construction age, and municipal ratings.',
    icon: Database,
  },
  {
    step: '02',
    title: 'Data Cleaning',
    desc: 'Auditing missing attributes, eliminating negative or nonsensical numerical values, filtering typographical duplicates, and sanitizing textual categories.',
    icon: CheckCircle,
  },
  {
    step: '03',
    title: 'Data Preprocessing',
    desc: 'Normalizing square footage metrics, encoding ordinal categorical variables (furnishing, nearby facilities), and computing city baseline unit densities.',
    icon: Scale,
  },
  {
    step: '04',
    title: 'Exploratory Data Analysis (EDA)',
    desc: 'Computing central tendencies (mean, median), evaluating variance across metropolitan cities, plotting scatter distributions, and uncovering covariance.',
    icon: BarChart3,
  },
  {
    step: '05',
    title: 'Feature Selection & Weighting',
    desc: 'Isolating prime drivers: square footage (area), geographic coefficient, locality tier rating, structural age depreciation, and layout utility modifiers.',
    icon: GitBranch,
  },
  {
    step: '06',
    title: 'Model / Prediction Logic',
    desc: 'Calibrating a multi-attribute hedonic regression formula blending empirical database statistics with macroeconomic real-estate coefficients.',
    icon: Cpu,
  },
  {
    step: '07',
    title: 'Price Prediction Execution',
    desc: 'Deterministic evaluation generating point valuations, confidence intervals (±5.5%), and transparent multi-factor attribution summaries.',
    icon: Calculator,
  },
  {
    step: '08',
    title: 'Result Analysis & Validation',
    desc: 'Storing timestamped prediction records into the database audit log for retrospective tracking and comparative assessment by administrators.',
    icon: ShieldCheck,
  },
];

export default function MethodologyPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header */}
      <div className="border-b border-slate-200 pb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold uppercase tracking-wider mb-2">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Analytical Framework</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Valuation Methodology & Algorithmic Pipeline
        </h1>
        <p className="text-slate-600 text-sm mt-1 max-w-3xl leading-relaxed">
          Comprehensive documentation of the theoretical framework, algorithmic pipeline, hedonic regression formulation, and the architecture distinguishing the demo valuation engine from external machine learning pipelines.
        </p>
      </div>

      {/* Distinction Banner */}
      <div className="bg-amber-50/80 border border-amber-300/80 rounded-2xl p-6 sm:p-7 shadow-xs">
        <div className="flex items-start gap-4">
          <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-2 text-xs sm:text-sm">
            <h3 className="font-bold text-amber-900 text-base">
              System Architecture: Hedonic Baseline Valuation Engine vs. External ML Microservice
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 text-slate-700">
              <div className="bg-white/80 p-4 rounded-xl border border-amber-200">
                <span className="font-bold text-slate-900 block mb-1">
                  1. Current Production Engine (Dataset-Calibrated Hedonic Valuation)
                </span>
                <p className="text-slate-600 leading-relaxed text-xs">
                  This system executes a <strong>dataset-calibrated hedonic pricing regression algorithm</strong>. It dynamically calculates live city baseline price densities from the database and multiplies them by deterministic coefficients (locality rating, area, age depreciation, room layout, parking). It does NOT fabricate synthetic ML accuracy scores or pretend an ML model was trained when it wasn’t.
                </p>
              </div>
              <div className="bg-white/80 p-4 rounded-xl border border-amber-200">
                <span className="font-bold text-slate-900 block mb-1">
                  2. External ML Model Integration (Modular Expansion)
                </span>
                <p className="text-slate-600 leading-relaxed text-xs">
                  The modular architecture cleanly isolates <code className="bg-amber-100 px-1 py-0.5 rounded text-[11px]">lib/predictionEngine.ts</code>. This can be directly interfaced with or replaced by an external Python API running trained algorithms (such as <em>XGBoost, Random Forest Regressor, or Gradient Boosting</em>) trained on extensive land registry deeds.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Visual Workflow Steps (01 -> 08) */}
      <div className="space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <span className="text-xs uppercase font-bold text-sky-600 tracking-wider">
            Standard Operating Procedure
          </span>
          <h2 className="text-2xl font-bold text-slate-900">
            End-to-End Analytical Pipeline
          </h2>
          <p className="text-xs text-slate-500">
            Formal execution flow from initial ingestion to verified prediction storage.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {WORKFLOW_STEPS.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={step.step}
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:border-sky-300 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-lg border border-sky-100">
                      STEP {step.step}
                    </span>
                    <Icon className="w-5 h-5 text-slate-400" />
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm mb-2">{step.title}</h3>
                  <p className="text-slate-600 text-xs leading-relaxed">{step.desc}</p>
                </div>
                {idx < WORKFLOW_STEPS.length - 1 && (
                  <div className="pt-4 text-center text-slate-300 hidden lg:block">
                    {/* Visual spacer */}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Mathematical Hedonic Valuation Formulation */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="border-b border-slate-100 pb-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-sky-600" />
            <span>Mathematical Hedonic Pricing Formulation</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Hedonic pricing decomposes property valuation into separate functional characteristics.
          </p>
        </div>

        <div className="bg-slate-900 text-slate-100 p-6 rounded-xl font-mono text-xs sm:text-sm overflow-x-auto leading-loose">
          <div className="text-sky-400 font-bold mb-2">// Hedonic Valuation Function</div>
          <div>Estimated Price = Area × R<sub>effective</sub> + ParkingAssetValue</div>
          <div className="text-slate-400 mt-2">// Where Effective Sq.Ft Rate:</div>
          <div>
            R<sub>effective</sub> = BaseRate(City) × C<sub>Type</sub> × M<sub>Rating</sub> × D<sub>Road</sub> × δ<sub>Age</sub> × F<sub>Furnish</sub> × U<sub>Layout</sub>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
            <span className="font-bold text-slate-800 block text-sm">
              Locality Rating Multiplier (M<sub>Rating</sub>)
            </span>
            <p>
              Linear scaling calibrated at index 5.0 = 1.00x. Formula: <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200">0.65 + (Rating × 0.07)</code>. A 8.0/10 rating yields a 1.21x premium (+21%).
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
            <span className="font-bold text-slate-800 block text-sm">
              Structural Age Depreciation (δ<sub>Age</sub>)
            </span>
            <p>
              Structures depreciate at 0.75% per annum, capped at 30% ceiling. Plot/Land assets are non-depreciating asset classes with depreciation set to 0.0%.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
            <span className="font-bold text-slate-800 block text-sm">
              Arterial Road Proximity (D<sub>Road</sub>)
            </span>
            <p>
              Applies a proximity discount of 1.8% per kilometer away from primary arterial transit roads, capped at a maximum 20% discount.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
            <span className="font-bold text-slate-800 block text-sm">
              Empirical Database Calibration
            </span>
            <p>
              When database records exist for a specified location, base prices dynamically blend 60% empirical database arithmetic mean with 40% calibrated regional priors.
            </p>
          </div>
        </div>
      </div>

      {/* Call to action */}
      <div className="flex justify-between items-center bg-slate-100 p-6 rounded-2xl border border-slate-200">
        <div>
          <h4 className="font-bold text-slate-900 text-sm">Ready to test the pipeline?</h4>
          <p className="text-xs text-slate-600">Run a live valuation to observe the model calculating in real-time.</p>
        </div>
        <Link
          href="/predict"
          className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors"
        >
          Open Predictor
        </Link>
      </div>
    </div>
  );
}

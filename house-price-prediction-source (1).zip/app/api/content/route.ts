import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    let content = await prisma.websiteContent.findUnique({
      where: { id: 'default' },
    });

    if (!content) {
      content = await prisma.websiteContent.create({
        data: {
          id: 'default',
          heroTitle: 'HOUSE & LAND PRICE PREDICTION ANALYSIS',
          heroSubtitle:
            'A data-driven real estate valuation platform that estimates residential and commercial property values using robust multi-factor regression analysis.',
          aboutProject:
            'This property valuation and predictive analytics platform demonstrates an end-to-end full-stack valuation system. It integrates dataset management, exploratory data analysis, interactive visual analytics, and an extensible prediction engine.',
          methodologyText:
            'The system implements a rigorous multi-stage analytical workflow: Data Collection -> Data Cleaning -> Preprocessing -> Exploratory Data Analysis (EDA) -> Feature Engineering -> Statistical Regression & Weighted Valuation Engine -> Prediction Delivery & Analytics.',
          contactEmail: 'support@propvalanalytics.com',
          contactPhone: '+91 98765 43210',
          contactAddress:
            'PropVal Analytics Operations Hub, Tech Park, Sector 5',
          featureDescriptions: JSON.stringify([
            {
              title: 'Statistical Hedonic Engine',
              desc: 'Deterministic multi-factor algorithm calibrating baseline location values with physical characteristics.',
            },
            {
              title: 'Dynamic Dataset Analytics',
              desc: 'Live recalculation of statistical distributions, correlations, and geospatial metrics upon any dataset change.',
            },
            {
              title: 'Complete Admin Management',
              desc: 'Secure management portal for dataset curation, prediction audit logs, and dynamic web content modification.',
            },
            {
              title: 'Valuation Methodology',
              desc: 'Designed according to rigorous empirical valuation standards comparing statistical baselines with ML pipelines.',
            },
          ]),
        },
      });
    }

    let parsedFeatures = [];
    try {
      parsedFeatures = JSON.parse(content.featureDescriptions || '[]');
    } catch {
      parsedFeatures = [];
    }

    return NextResponse.json({
      ...content,
      features: parsedFeatures,
    });
  } catch (error) {
    console.error('Error fetching website content:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve website content' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json(
      { error: 'Unauthorized: Admin privileges required' },
      { status: 401 }
    );
  }

  try {
    const body = await request.json();
    const {
      heroTitle,
      heroSubtitle,
      aboutProject,
      methodologyText,
      contactEmail,
      contactPhone,
      contactAddress,
      features,
    } = body;

    const updated = await prisma.websiteContent.upsert({
      where: { id: 'default' },
      update: {
        heroTitle: heroTitle || undefined,
        heroSubtitle: heroSubtitle || undefined,
        aboutProject: aboutProject || undefined,
        methodologyText: methodologyText || undefined,
        contactEmail: contactEmail || undefined,
        contactPhone: contactPhone || undefined,
        contactAddress: contactAddress || undefined,
        featureDescriptions: features ? JSON.stringify(features) : undefined,
      },
      create: {
        id: 'default',
        heroTitle: heroTitle || 'HOUSE & LAND PRICE PREDICTION ANALYSIS',
        heroSubtitle: heroSubtitle || '',
        aboutProject: aboutProject || '',
        methodologyText: methodologyText || '',
        contactEmail: contactEmail || '',
        contactPhone: contactPhone || '',
        contactAddress: contactAddress || '',
        featureDescriptions: features ? JSON.stringify(features) : '[]',
      },
    });

    return NextResponse.json({
      message: 'Website content updated successfully',
      content: updated,
    });
  } catch (error: any) {
    console.error('Error updating content:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to update website content' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import { LeadStatusUpdateSchema } from '@/validation';
import { AuditService } from '@/services/auditService';

export const dynamic = 'force-dynamic';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 401 });
  }

  try {
    const id = parseInt(params.id, 10);
    if (isNaN(id)) {
      return NextResponse.json({ error: 'Invalid lead ID' }, { status: 400 });
    }

    const body = await request.json();
    const validated = LeadStatusUpdateSchema.safeParse(body);
    if (!validated.success) {
      return NextResponse.json(
        { error: 'Invalid lead update payload', details: validated.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const { status, notes, assignedToId } = validated.data;

    const updatedLead = await prisma.lead.update({
      where: { id },
      data: {
        status,
        notes: notes !== undefined ? notes : undefined,
        assignedToId: assignedToId !== undefined ? assignedToId : undefined,
      },
    });

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'LEAD_STATUS_CHANGE',
      entity: 'Lead',
      entityId: id,
      metadata: { newStatus: status, notes },
    });

    return NextResponse.json({
      success: true,
      message: 'Lead updated successfully',
      lead: updatedLead,
    });
  } catch (error: any) {
    console.error('Error updating lead:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to update lead' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const admin = verifyAdminRequest(request, ['SUPER_ADMIN', 'ADMIN']);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Insufficient privileges' }, { status: 403 });
  }

  try {
    const id = parseInt(params.id, 10);
    if (isNaN(id)) {
      return NextResponse.json({ error: 'Invalid lead ID' }, { status: 400 });
    }

    await prisma.lead.delete({ where: { id } });

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'LEAD_DELETE',
      entity: 'Lead',
      entityId: id,
    });

    return NextResponse.json({
      success: true,
      message: 'Lead purged successfully',
    });
  } catch (error: any) {
    console.error('Error deleting lead:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to delete lead' },
      { status: 500 }
    );
  }
}

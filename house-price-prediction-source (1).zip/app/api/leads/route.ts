import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import { AuditService } from '@/services/auditService';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.max(1, Math.min(100, parseInt(searchParams.get('limit') || '15', 10)));
    const search = searchParams.get('search') || '';
    const status = searchParams.get('status') || '';

    const where: any = {};
    if (status && status !== 'ALL') {
      where.status = status;
    }

    if (search.trim()) {
      const s = search.trim();
      where.OR = [
        { leadCode: { contains: s } },
        { name: { contains: s } },
        { email: { contains: s } },
        { phone: { contains: s } },
      ];
    }

    const total = await prisma.lead.count({ where });
    const leads = await prisma.lead.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        property: true,
        valuationRequest: {
          include: { prediction: true },
        },
        assignedTo: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    return NextResponse.json({
      leads,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error: any) {
    console.error('Error fetching leads:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to fetch leads' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, phone, email, notes, source, propertyId } = body;

    if (!name || !phone || !email) {
      return NextResponse.json(
        { error: 'Name, phone, and email are required to create a lead' },
        { status: 400 }
      );
    }

    const leadCode = `LEAD-${Date.now().toString(36).toUpperCase()}-${Math.floor(10 + Math.random() * 90)}`;

    const newLead = await prisma.lead.create({
      data: {
        leadCode,
        name: name.trim(),
        phone: phone.trim(),
        email: email.trim().toLowerCase(),
        source: source || 'Contact Form',
        status: 'NEW',
        notes: notes || null,
        propertyId: propertyId ? parseInt(String(propertyId), 10) : null,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Lead registered successfully',
      lead: newLead,
    });
  } catch (error: any) {
    console.error('Error creating lead:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to register lead' },
      { status: 500 }
    );
  }
}

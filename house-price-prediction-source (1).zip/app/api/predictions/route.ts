import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json(
      { error: 'Unauthorized: Admin privileges required' },
      { status: 401 }
    );
  }

  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.max(1, Math.min(100, parseInt(searchParams.get('limit') || '15', 10)));
    const search = searchParams.get('search') || '';

    const where: any = {};
    if (search.trim()) {
      const s = search.trim();
      where.valuationRequest = {
        OR: [
          { requestRef: { contains: s } },
          { localityText: { contains: s } },
          { propertyType: { contains: s } },
          { contactName: { contains: s } },
        ],
      };
    }

    const total = await prisma.prediction.count({ where });
    const predictions = await prisma.prediction.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        valuationRequest: true,
      },
    });

    const parsedPredictions = predictions.map((pred) => {
      let factors = [];
      let comparables = [];
      try {
        factors = JSON.parse(pred.factorsJson || '[]');
      } catch {
        factors = [];
      }
      try {
        comparables = JSON.parse(pred.comparablesJson || '[]');
      } catch {
        comparables = [];
      }
      const req = pred.valuationRequest;
      return {
        ...pred,
        predictionId: req?.requestRef || `VAL-${pred.id}`,
        predictedPrice: pred.estimatedPrice,
        propertyType: req?.propertyType || 'Apartment',
        location: req?.localityText || 'Metro',
        area: req?.areaSqFt || 0,
        bedrooms: req?.bedrooms || 0,
        bathrooms: req?.bathrooms || 0,
        floors: req?.totalFloors || 1,
        propertyAge: req?.propertyAge || 0,
        parking: req?.parking || 'Yes',
        furnishing: req?.furnishing || 'Semi-Furnished',
        nearbyFacilities: 'Good',
        distanceFromMainRoad: 1.0,
        localityRating: 8.0,
        factors,
        comparables,
      };
    });

    return NextResponse.json({
      predictions: parsedPredictions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching predictions:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve prediction records' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json(
      { error: 'Unauthorized: Admin privileges required' },
      { status: 401 }
    );
  }

  try {
    const { searchParams } = new URL(request.url);
    const predictionId = searchParams.get('predictionId');

    if (predictionId) {
      const numId = parseInt(predictionId, 10);
      if (!isNaN(numId)) {
        await prisma.prediction.delete({
          where: { id: numId },
        });
      } else {
        const vReq = await prisma.valuationRequest.findUnique({
          where: { requestRef: predictionId },
          include: { prediction: true },
        });
        if (vReq?.prediction) {
          await prisma.prediction.delete({
            where: { id: vReq.prediction.id },
          });
        }
      }
      return NextResponse.json({
        message: `Prediction ${predictionId} deleted successfully`,
      });
    }

    // If query is ?action=clearAll
    const action = searchParams.get('action');
    if (action === 'clearAll') {
      const deleted = await prisma.prediction.deleteMany({});
      return NextResponse.json({
        message: `All ${deleted.count} prediction records cleared`,
      });
    }

    return NextResponse.json(
      { error: 'Specify predictionId or action=clearAll' },
      { status: 400 }
    );
  } catch (error: any) {
    console.error('Error deleting prediction:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to delete prediction' },
      { status: 500 }
    );
  }
}

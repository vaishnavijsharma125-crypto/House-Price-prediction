import { NextRequest, NextResponse } from 'next/server';
import { ValuationService } from '@/services/valuationService';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const normalizedInput = {
      propertyType: body.propertyType === 'House' ? 'Villa/House' : body.propertyType || 'Apartment',
      city: body.location || body.city || 'Mumbai',
      locality: body.locality || body.location || 'Bandra West',
      pincode: body.pincode || '',
      areaSqFt: parseFloat(String(body.area || body.areaSqFt || 1000)),
      bedrooms: parseInt(String(body.bedrooms ?? 1), 10),
      bathrooms: parseInt(String(body.bathrooms ?? 1), 10),
      balconies: parseInt(String(body.balconies ?? 0), 10),
      propertyAge: parseInt(String(body.propertyAge ?? 0), 10),
      floor: parseInt(String(body.floor ?? 1), 10),
      totalFloors: parseInt(String(body.floors ?? body.totalFloors ?? 1), 10),
      parking: body.parking === true || body.parking === 'Yes' || body.parking === 'yes' ? 'Yes' : 'No',
      furnishing: body.furnishing || 'Semi-Furnished',
      constructionStatus: body.constructionStatus || 'Ready to Move',
      amenities: Array.isArray(body.amenities) ? body.amenities : [],
      contactName: body.contactName || 'Valuation Customer',
      contactEmail: body.contactEmail || 'customer@propval.com',
      contactPhone: body.contactPhone || '9876543210',
    };

    const result = await ValuationService.calculateValuation(normalizedInput as any);

    return NextResponse.json({
      success: true,
      predictionId: result.requestRef,
      predictedPrice: result.estimatedPrice,
      priceRangeMin: result.lowEstimate,
      priceRangeMax: result.highEstimate,
      pricePerSqFt: result.pricePerSqFt,
      confidenceLevel: result.confidenceLevel,
      factors: result.factors,
      comparables: result.comparables,
      algorithm: result.modelVersion,
      timestamp: result.valuationDate,
      inputSummary: {
        propertyType: normalizedInput.propertyType,
        location: `${normalizedInput.locality}, ${normalizedInput.city}`,
        area: normalizedInput.areaSqFt,
        bedrooms: normalizedInput.bedrooms,
        bathrooms: normalizedInput.bathrooms,
        floors: normalizedInput.totalFloors,
        propertyAge: normalizedInput.propertyAge,
        parking: normalizedInput.parking,
        furnishing: normalizedInput.furnishing,
      },
    });
  } catch (error: any) {
    console.error('Prediction API error:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to calculate valuation' },
      { status: 500 }
    );
  }
}

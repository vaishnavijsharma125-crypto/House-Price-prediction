import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const totalProperties = await prisma.property.count({
      where: { isDeleted: false },
    });
    const totalPredictions = await prisma.prediction.count();
    const totalValuations = await prisma.valuationRequest.count();
    const totalLeads = await prisma.lead.count();

    if (totalProperties === 0) {
      return NextResponse.json({
        totalProperties: 0,
        averagePrice: 0,
        averageArea: 0,
        averagePricePerSqFt: 0,
        highestPrice: 0,
        lowestPrice: 0,
        totalPredictions,
        totalValuations,
        totalLeads,
        recentProperties: [],
        recentPredictions: [],
      });
    }

    const aggregations = await prisma.property.aggregate({
      where: { isDeleted: false },
      _avg: {
        expectedPrice: true,
        areaSqFt: true,
      },
      _max: {
        expectedPrice: true,
      },
      _min: {
        expectedPrice: true,
      },
    });

    const averagePrice = Math.round(aggregations._avg.expectedPrice || 0);
    const averageArea = Math.round(aggregations._avg.areaSqFt || 0);
    const averagePricePerSqFt =
      averageArea > 0 ? Math.round(averagePrice / averageArea) : 0;
    const highestPrice = aggregations._max.expectedPrice || 0;
    const lowestPrice = aggregations._min.expectedPrice || 0;

    const recentProps = await prisma.property.findMany({
      where: { isDeleted: false },
      orderBy: { createdAt: 'desc' },
      take: 6,
      include: { location: true },
    });

    const formattedRecentProps = recentProps.map((p) => ({
      ...p,
      propertyId: p.propertyCode,
      price: p.expectedPrice,
      area: p.areaSqFt,
      location: p.location ? `${p.location.locality}, ${p.location.city}` : 'Metro',
    }));

    const recentPredictions = await prisma.prediction.findMany({
      orderBy: { createdAt: 'desc' },
      take: 6,
      include: {
        valuationRequest: true,
      },
    });

    const formattedRecentPreds = recentPredictions.map((p) => ({
      id: p.id,
      predictionId: p.valuationRequest?.requestRef || `PRED-${p.id}`,
      propertyType: p.valuationRequest?.propertyType || 'Apartment',
      location: p.valuationRequest?.localityText || 'Metro',
      area: p.valuationRequest?.areaSqFt || 1000,
      predictedPrice: p.estimatedPrice,
      pricePerSqFt: p.pricePerSqFt,
      createdAt: p.createdAt,
    }));

    return NextResponse.json({
      totalProperties,
      averagePrice,
      averageArea,
      averagePricePerSqFt,
      highestPrice,
      lowestPrice,
      totalPredictions: Math.max(totalPredictions, totalValuations),
      totalValuations,
      totalLeads,
      recentProperties: formattedRecentProps,
      recentPredictions: formattedRecentPreds,
    });
  } catch (error: any) {
    console.error('Error fetching statistics:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to compute database statistics' },
      { status: 500 }
    );
  }
}

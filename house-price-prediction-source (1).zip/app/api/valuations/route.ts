import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { ValuationWizardSchema } from '@/validation';
import { ValuationService } from '@/services/valuationService';
import { verifyAdminRequest } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Map input fields if coming from simplified predictor or wizard
    const normalizedInput = {
      propertyType: body.propertyType || 'Apartment',
      city: body.city || body.location || 'Mumbai',
      locality: body.locality || body.location || 'Bandra West',
      pincode: body.pincode || '',
      areaSqFt: parseFloat(String(body.areaSqFt || body.area || 1000)),
      bedrooms: parseInt(String(body.bedrooms ?? 1), 10),
      bathrooms: parseInt(String(body.bathrooms ?? 1), 10),
      balconies: parseInt(String(body.balconies ?? 0), 10),
      propertyAge: parseInt(String(body.propertyAge ?? 0), 10),
      floor: parseInt(String(body.floor ?? 1), 10),
      totalFloors: parseInt(String(body.totalFloors ?? body.floors ?? 1), 10),
      parking: body.parking === true || body.parking === 'Yes' || body.parking === 'yes' ? 'Yes' : 'No',
      furnishing: body.furnishing || 'Semi-Furnished',
      constructionStatus: body.constructionStatus || 'Ready to Move',
      amenities: Array.isArray(body.amenities) ? body.amenities : [],
      contactName: body.contactName || body.name || 'Property Valuation Customer',
      contactEmail: body.contactEmail || body.email || 'customer@propval.com',
      contactPhone: body.contactPhone || body.phone || '9876543210',
    };

    const validated = ValuationWizardSchema.safeParse(normalizedInput);
    if (!validated.success) {
      return NextResponse.json(
        {
          error: 'Validation failed. Please verify your property specifications.',
          details: validated.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const result = await ValuationService.calculateValuation(validated.data as any);

    return NextResponse.json({
      success: true,
      ...result,
    });
  } catch (error: any) {
    console.error('Valuation calculation error:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to process valuation request' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.max(1, Math.min(100, parseInt(searchParams.get('limit') || '15', 10)));
    const search = searchParams.get('search') || '';

    const where: any = {};
    if (search.trim()) {
      const s = search.trim();
      where.OR = [
        { requestRef: { contains: s } },
        { localityText: { contains: s } },
        { contactName: { contains: s } },
        { contactEmail: { contains: s } },
      ];
    }

    const total = await prisma.valuationRequest.count({ where });
    const requests = await prisma.valuationRequest.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        prediction: true,
        lead: true,
        location: true,
      },
    });

    const parsed = requests.map((r) => {
      let factors = [];
      let comparables = [];
      try {
        factors = JSON.parse(r.prediction?.factorsJson || '[]');
        comparables = JSON.parse(r.prediction?.comparablesJson || '[]');
      } catch {}
      return {
        ...r,
        prediction: r.prediction
          ? {
              ...r.prediction,
              factors,
              comparables,
            }
          : null,
      };
    });

    return NextResponse.json({
      valuations: parsed,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error: any) {
    console.error('Error fetching valuations:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to fetch valuations' },
      { status: 500 }
    );
  }
}

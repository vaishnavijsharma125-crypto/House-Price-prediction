import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import { TransactionSchema } from '@/validation';
import { AuditService } from '@/services/auditService';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.max(1, Math.min(100, parseInt(searchParams.get('limit') || '15', 10)));
    const search = searchParams.get('search') || '';

    const where: any = {};
    if (search.trim()) {
      const s = search.trim();
      where.OR = [
        { transactionRef: { contains: s } },
        { localityName: { contains: s } },
        { propertyType: { contains: s } },
        { source: { contains: s } },
      ];
    }

    const total = await prisma.propertyTransaction.count({ where });
    const transactions = await prisma.propertyTransaction.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { transactionDate: 'desc' },
      include: { location: true },
    });

    return NextResponse.json({
      transactions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error: any) {
    console.error('Error fetching transactions:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to fetch transactions' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const admin = verifyAdminRequest(request, ['SUPER_ADMIN', 'ADMIN', 'ANALYST']);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const validated = TransactionSchema.safeParse(body);
    if (!validated.success) {
      return NextResponse.json(
        { error: 'Invalid transaction record', details: validated.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const data = validated.data;
    const pricePerSqFt = Math.round(data.transactionPrice / Math.max(1, data.areaSqFt));
    const ref = `TXN-${Date.now().toString(36).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

    const createdTxn = await prisma.propertyTransaction.create({
      data: {
        transactionRef: ref,
        propertyType: data.propertyType,
        localityName: data.localityName,
        areaSqFt: data.areaSqFt,
        bedrooms: data.bedrooms,
        bathrooms: data.bathrooms,
        propertyAge: data.propertyAge,
        floor: data.floor,
        furnishing: data.furnishing,
        transactionPrice: data.transactionPrice,
        pricePerSqFt,
        transactionDate: new Date(data.transactionDate),
        source: data.source,
        verified: true,
      },
    });

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'TRANSACTION_CREATE',
      entity: 'PropertyTransaction',
      entityId: createdTxn.id,
      metadata: { ref: createdTxn.transactionRef, price: createdTxn.transactionPrice },
    });

    return NextResponse.json({
      success: true,
      message: 'Transaction created successfully',
      transaction: createdTxn,
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating transaction:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to create transaction' },
      { status: 500 }
    );
  }
}

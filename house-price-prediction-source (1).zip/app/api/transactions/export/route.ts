import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import Papa from 'papaparse';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 401 });
  }

  try {
    const transactions = await prisma.propertyTransaction.findMany({
      orderBy: { transactionDate: 'desc' },
    });

    const csvData = transactions.map((t) => ({
      transactionRef: t.transactionRef,
      propertyType: t.propertyType,
      localityName: t.localityName,
      areaSqFt: t.areaSqFt,
      bedrooms: t.bedrooms,
      bathrooms: t.bathrooms,
      propertyAge: t.propertyAge,
      floor: t.floor,
      furnishing: t.furnishing,
      transactionPrice: t.transactionPrice,
      pricePerSqFt: t.pricePerSqFt,
      transactionDate: t.transactionDate.toISOString().split('T')[0],
      source: t.source,
      verified: t.verified ? 'true' : 'false',
    }));

    const csv = Papa.unparse(csvData);

    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="historical_transactions_${Date.now()}.csv"`,
      },
    });
  } catch (error: any) {
    console.error('Error exporting transactions:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to export transactions' },
      { status: 500 }
    );
  }
}

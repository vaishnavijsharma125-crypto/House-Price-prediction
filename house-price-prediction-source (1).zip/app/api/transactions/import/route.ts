import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import Papa from 'papaparse';
import { AuditService } from '@/services/auditService';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  const admin = verifyAdminRequest(request, ['SUPER_ADMIN', 'ADMIN', 'ANALYST']);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 401 });
  }

  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    let csvText = '';

    if (file) {
      csvText = await file.text();
    } else {
      const raw = formData.get('csvText') as string | null;
      if (raw) csvText = raw;
    }

    if (!csvText || !csvText.trim()) {
      return NextResponse.json({ error: 'No CSV content provided' }, { status: 400 });
    }

    const parsed = Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
    });

    if (parsed.errors.length > 0 && parsed.data.length === 0) {
      return NextResponse.json(
        { error: 'Malformed CSV format', details: parsed.errors },
        { status: 400 }
      );
    }

    const rows = parsed.data as Record<string, string>[];
    const validRows: any[] = [];
    const validationErrors: string[] = [];

    const requiredFields = ['propertyType', 'localityName', 'areaSqFt', 'transactionPrice'];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowNum = i + 2;

      // Check required columns
      const missing = requiredFields.filter((col) => !row[col] || row[col].trim() === '');
      if (missing.length > 0) {
        validationErrors.push(`Row ${rowNum}: Missing mandatory columns (${missing.join(', ')})`);
        continue;
      }

      const areaSqFt = parseFloat(row.areaSqFt);
      const transactionPrice = parseFloat(row.transactionPrice);

      if (isNaN(areaSqFt) || areaSqFt <= 0) {
        validationErrors.push(`Row ${rowNum}: Area must be a positive number`);
        continue;
      }

      if (isNaN(transactionPrice) || transactionPrice <= 0) {
        validationErrors.push(`Row ${rowNum}: Transaction Price must be a positive number`);
        continue;
      }

      const pricePerSqFt = Math.round(transactionPrice / areaSqFt);
      const ref =
        row.transactionRef && row.transactionRef.trim()
          ? row.transactionRef.trim()
          : `TXN-${Date.now().toString(36).toUpperCase()}-${i + 1}`;

      const date = row.transactionDate ? new Date(row.transactionDate) : new Date();

      validRows.push({
        transactionRef: ref,
        propertyType: row.propertyType.trim(),
        localityName: row.localityName.trim(),
        areaSqFt,
        bedrooms: parseInt(row.bedrooms || '0', 10) || 0,
        bathrooms: parseInt(row.bathrooms || '0', 10) || 0,
        propertyAge: parseInt(row.propertyAge || '0', 10) || 0,
        floor: parseInt(row.floor || '0', 10) || 0,
        furnishing: row.furnishing ? row.furnishing.trim() : 'Semi-Furnished',
        transactionPrice,
        pricePerSqFt,
        transactionDate: isNaN(date.getTime()) ? new Date() : date,
        source: row.source ? row.source.trim() : 'Registry Import',
        verified: true,
      });
    }

    if (validRows.length === 0) {
      return NextResponse.json(
        {
          error: 'No valid transaction records found in uploaded file',
          validationErrors,
        },
        { status: 400 }
      );
    }

    let inserted = 0;
    let updated = 0;

    for (const item of validRows) {
      const existing = await prisma.propertyTransaction.findUnique({
        where: { transactionRef: item.transactionRef },
      });

      if (existing) {
        await prisma.propertyTransaction.update({
          where: { id: existing.id },
          data: item,
        });
        updated++;
      } else {
        await prisma.propertyTransaction.create({
          data: item,
        });
        inserted++;
      }
    }

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'TRANSACTION_IMPORT',
      entity: 'PropertyTransaction',
      metadata: { inserted, updated, rejected: validationErrors.length },
    });

    return NextResponse.json({
      success: true,
      message: `Batch import complete: ${inserted} inserted, ${updated} updated.`,
      stats: { inserted, updated, rejected: validationErrors.length },
      validationErrors: validationErrors.slice(0, 10),
    });
  } catch (error: any) {
    console.error('Error importing transactions:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to import transaction dataset' },
      { status: 500 }
    );
  }
}

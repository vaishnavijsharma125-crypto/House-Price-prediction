import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, phone, email, subject, message } = body;

    if (!name || !email) {
      return NextResponse.json(
        { error: 'Name and email are mandatory' },
        { status: 400 }
      );
    }

    const leadCode = `LEAD-${Date.now().toString(36).toUpperCase()}-${Math.floor(10 + Math.random() * 90)}`;

    const lead = await prisma.lead.create({
      data: {
        leadCode,
        name: name.trim(),
        phone: (phone || '').trim(),
        email: email.trim().toLowerCase(),
        source: 'Contact Form',
        status: 'NEW',
        notes: subject ? `Subject: ${subject}\nMessage: ${message}` : message,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Inquiry received. A representative will contact you shortly.',
      leadId: lead.id,
      leadCode: lead.leadCode,
    });
  } catch (error: any) {
    console.error('Contact submission error:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to submit inquiry' },
      { status: 500 }
    );
  }
}

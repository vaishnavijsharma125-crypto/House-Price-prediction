import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const [properties, transactions, valuations, leads] = await Promise.all([
      prisma.property.findMany({
        where: { isDeleted: false },
        include: { location: true },
      }),
      prisma.propertyTransaction.findMany({
        orderBy: { transactionDate: 'desc' },
      }),
      prisma.valuationRequest.findMany({
        include: { prediction: true },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.lead.findMany(),
    ]);

    const totalCount = properties.length;

    // 1. Average Price by Location & Average Price/Sq.Ft by Location
    const locationMap: Record<string, { totalPrice: number; totalArea: number; count: number }> = {};
    properties.forEach((p) => {
      const locKey = p.location?.city || 'Metro';
      if (!locationMap[locKey]) locationMap[locKey] = { totalPrice: 0, totalArea: 0, count: 0 };
      locationMap[locKey].totalPrice += p.expectedPrice;
      locationMap[locKey].totalArea += p.areaSqFt;
      locationMap[locKey].count += 1;
    });

    const priceByLocation = Object.entries(locationMap).map(([loc, data]) => ({
      location: loc,
      avgPrice: Math.round(data.totalPrice / Math.max(1, data.count)),
      avgPricePerSqFt: Math.round(data.totalPrice / Math.max(1, data.totalArea)),
      count: data.count,
    }));

    const pricePerSqFtByLocation = priceByLocation.map((item) => ({
      location: item.location,
      avgPricePerSqFt: item.avgPricePerSqFt,
      count: item.count,
    }));

    // 2. Price vs Area (Scatter plot)
    const priceVsArea = properties.map((p) => ({
      propertyId: p.propertyCode,
      area: p.areaSqFt,
      price: Math.round(p.expectedPrice / 100000), // in Lakhs
      rawPrice: p.expectedPrice,
      propertyType: p.propertyType,
      location: p.location?.locality || 'Metro',
    }));

    // 3. Price by Property Type
    const typeMap: Record<string, { totalPrice: number; count: number }> = {};
    properties.forEach((p) => {
      if (!typeMap[p.propertyType]) typeMap[p.propertyType] = { totalPrice: 0, count: 0 };
      typeMap[p.propertyType].totalPrice += p.expectedPrice;
      typeMap[p.propertyType].count += 1;
    });

    const priceByPropertyType = Object.entries(typeMap).map(([type, d]) => ({
      name: type,
      avgPrice: Math.round(d.totalPrice / d.count),
      count: d.count,
      percentage: Number(((d.count / Math.max(1, totalCount)) * 100).toFixed(1)),
    }));

    // 4. Price by Bedroom Count
    const bedroomMap: Record<number, { totalPrice: number; count: number }> = {};
    properties.forEach((p) => {
      const bhk = p.bedrooms;
      if (!bedroomMap[bhk]) bedroomMap[bhk] = { totalPrice: 0, count: 0 };
      bedroomMap[bhk].totalPrice += p.expectedPrice;
      bedroomMap[bhk].count += 1;
    });

    const bedroomVsPrice = Object.entries(bedroomMap)
      .map(([bhk, d]) => ({
        bedrooms: Number(bhk),
        label: Number(bhk) === 0 ? 'Commercial/Plot' : `${bhk} BHK`,
        avgPrice: Math.round(d.totalPrice / d.count),
        count: d.count,
      }))
      .sort((a, b) => a.bedrooms - b.bedrooms);

    // 5. Price by Property Age
    const ageBins = [
      { label: '0-2 Yrs (New)', min: 0, max: 2, total: 0, count: 0 },
      { label: '3-5 Yrs', min: 3, max: 5, total: 0, count: 0 },
      { label: '6-10 Yrs', min: 6, max: 10, total: 0, count: 0 },
      { label: '11+ Yrs', min: 11, max: 999, total: 0, count: 0 },
    ];
    properties.forEach((p) => {
      for (const bin of ageBins) {
        if (p.propertyAge >= bin.min && p.propertyAge <= bin.max) {
          bin.total += p.expectedPrice;
          bin.count += 1;
          break;
        }
      }
    });

    const propertyAgeVsPrice = ageBins.map((bin) => ({
      ageGroup: bin.label,
      avgPrice: bin.count > 0 ? Math.round(bin.total / bin.count) : 0,
      count: bin.count,
    }));

    // 6. Monthly Transaction Trends (from verified historical transactions)
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthlyMap: Record<string, { volume: number; totalValue: number }> = {};

    transactions.forEach((t) => {
      const d = new Date(t.transactionDate);
      const key = `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
      if (!monthlyMap[key]) monthlyMap[key] = { volume: 0, totalValue: 0 };
      monthlyMap[key].volume += 1;
      monthlyMap[key].totalValue += t.transactionPrice;
    });

    const monthlyTransactionTrends = Object.entries(monthlyMap).map(([month, d]) => ({
      month,
      volume: d.volume,
      avgPrice: Math.round(d.totalValue / d.volume),
    }));

    // 7. Property Supply by Location
    const supplyByLocation = Object.entries(locationMap).map(([loc, d]) => ({
      location: loc,
      supplyCount: d.count,
    }));

    // 8. Lead Conversion Funnel
    const leadStatusCounts: Record<string, number> = {
      NEW: 0,
      CONTACTED: 0,
      QUALIFIED: 0,
      SITE_VISIT: 0,
      NEGOTIATION: 0,
      CONVERTED: 0,
      CLOSED: 0,
    };
    leads.forEach((l) => {
      if (leadStatusCounts[l.status] !== undefined) {
        leadStatusCounts[l.status] += 1;
      }
    });

    const leadConversionFunnel = Object.entries(leadStatusCounts).map(([status, count]) => ({
      stage: status.replace('_', ' '),
      count,
    }));

    return NextResponse.json({
      totalCount,
      priceByLocation,
      pricePerSqFtByLocation,
      priceVsArea,
      priceByPropertyType,
      propertyTypeDistribution: priceByPropertyType, // backwards compatible key
      bedroomVsPrice,
      propertyAgeVsPrice,
      furnishingVsPrice: [], // provided as empty array if none
      monthlyTransactionTrends,
      supplyByLocation,
      leadConversionFunnel,
      totalValuations: valuations.length,
      totalLeads: leads.length,
    });
  } catch (error: any) {
    console.error('Error generating commercial analytics:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to generate analytics' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const locality = searchParams.get('locality');

    if (!locality || !locality.trim()) {
      // Return high-level summary across top localities
      const topLocalities = await prisma.location.findMany({
        where: { isActive: true },
        take: 8,
        include: {
          properties: { where: { isDeleted: false, status: 'ACTIVE' } },
          transactions: true,
        },
      });

      const insights = topLocalities.map((loc) => {
        const propCount = loc.properties.length;
        const txnCount = loc.transactions.length;

        if (propCount === 0 && txnCount === 0) {
          return {
            locality: loc.locality,
            city: loc.city,
            hasData: false,
            message: 'Insufficient data for reliable market insight.',
          };
        }

        const avgPrice =
          propCount > 0
            ? Math.round(loc.properties.reduce((a, b) => a + b.expectedPrice, 0) / propCount)
            : loc.avgPricePerSqFt * 1200;

        return {
          locality: loc.locality,
          city: loc.city,
          marketTier: loc.marketTier,
          avgPrice,
          avgPricePerSqFt: loc.avgPricePerSqFt,
          availableListings: propCount,
          recordedTransactions: txnCount,
          hasData: true,
        };
      });

      return NextResponse.json({ insights });
    }

    // Single locality deep analysis
    const loc = await prisma.location.findFirst({
      where: { locality: { contains: locality.trim() }, isActive: true },
      include: {
        properties: { where: { isDeleted: false, status: 'ACTIVE' } },
        transactions: { orderBy: { transactionDate: 'desc' } },
      },
    });

    if (!loc || (loc.properties.length === 0 && loc.transactions.length === 0)) {
      return NextResponse.json({
        locality,
        hasData: false,
        message: 'Insufficient data for reliable market insight.',
      });
    }

    const propPrices = loc.properties.map((p) => p.expectedPrice);
    const minPrice = propPrices.length > 0 ? Math.min(...propPrices) : loc.avgPricePerSqFt * 800;
    const maxPrice = propPrices.length > 0 ? Math.max(...propPrices) : loc.avgPricePerSqFt * 2500;
    const avgPrice =
      propPrices.length > 0
        ? Math.round(propPrices.reduce((a, b) => a + b, 0) / propPrices.length)
        : loc.avgPricePerSqFt * 1400;

    return NextResponse.json({
      hasData: true,
      locality: loc.locality,
      city: loc.city,
      marketTier: loc.marketTier,
      avgPrice,
      avgPricePerSqFt: loc.avgPricePerSqFt,
      minPrice,
      maxPrice,
      availableInventory: loc.properties.length,
      historicalTransactionsCount: loc.transactions.length,
      recentTransactions: loc.transactions.slice(0, 5),
    });
  } catch (error: any) {
    console.error('Market insight error:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to generate market insights' },
      { status: 500 }
    );
  }
}

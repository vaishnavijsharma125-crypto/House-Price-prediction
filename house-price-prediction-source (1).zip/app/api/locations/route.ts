import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import { AuditService } from '@/services/auditService';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const city = searchParams.get('city');

    const where: any = { isActive: true };
    if (city && city !== 'All') {
      where.city = city;
    }

    const locations = await prisma.location.findMany({
      where,
      orderBy: [{ city: 'asc' }, { locality: 'asc' }],
    });

    // Also group by city for dropdown structures
    const cities = Array.from(new Set(locations.map((l) => l.city)));

    return NextResponse.json({
      locations,
      cities,
    });
  } catch (error: any) {
    console.error('Error fetching locations:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to fetch locations' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const admin = verifyAdminRequest(request, ['SUPER_ADMIN', 'ADMIN']);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin access required' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { city, area, locality, pincode, state, avgPricePerSqFt, marketTier } = body;

    if (!city || !locality) {
      return NextResponse.json({ error: 'City and locality are mandatory' }, { status: 400 });
    }

    const location = await prisma.location.upsert({
      where: {
        city_locality: { city: city.trim(), locality: locality.trim() },
      },
      update: {
        area: area ? area.trim() : city.trim(),
        pincode: pincode ? pincode.trim() : null,
        state: state ? state.trim() : 'Maharashtra',
        avgPricePerSqFt: avgPricePerSqFt ? parseFloat(String(avgPricePerSqFt)) : undefined,
        marketTier: marketTier || 'Tier 1',
      },
      create: {
        city: city.trim(),
        area: area ? area.trim() : city.trim(),
        locality: locality.trim(),
        pincode: pincode ? pincode.trim() : null,
        state: state ? state.trim() : 'Maharashtra',
        avgPricePerSqFt: avgPricePerSqFt ? parseFloat(String(avgPricePerSqFt)) : 8500,
        marketTier: marketTier || 'Tier 1',
        isActive: true,
      },
    });

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'LOCATION_UPSERT',
      entity: 'Location',
      entityId: location.id,
      metadata: { city: location.city, locality: location.locality },
    });

    return NextResponse.json({
      success: true,
      location,
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating location:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to create location' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import Papa from 'papaparse';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json(
      { error: 'Unauthorized: Admin privileges required' },
      { status: 401 }
    );
  }

  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    let csvText = '';

    if (file) {
      csvText = await file.text();
    } else {
      const rawText = formData.get('csvText') as string | null;
      if (rawText) {
        csvText = rawText;
      }
    }

    if (!csvText || !csvText.trim()) {
      return NextResponse.json(
        { error: 'No CSV content provided for import' },
        { status: 400 }
      );
    }

    const parsed = Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
    });

    if (parsed.errors.length > 0 && parsed.data.length === 0) {
      return NextResponse.json(
        { error: 'Failed to parse CSV format', details: parsed.errors },
        { status: 400 }
      );
    }

    const rows = parsed.data as Record<string, string>[];
    const validRows: any[] = [];
    const errors: string[] = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowNum = i + 2;

      const pType = row.propertyType || row.type || 'Apartment';
      const locText = row.locality || row.location || row.city || 'Bandra West';
      const city = row.city || 'Mumbai';
      const rawArea = row.areaSqFt || row.area;
      const rawPrice = row.expectedPrice || row.price;

      if (!rawArea || !rawPrice) {
        errors.push(`Row ${rowNum}: Area and Price are mandatory`);
        continue;
      }

      const areaSqFt = parseFloat(rawArea);
      const expectedPrice = parseFloat(rawPrice);

      if (isNaN(areaSqFt) || areaSqFt <= 0) {
        errors.push(`Row ${rowNum}: Area must be a positive number`);
        continue;
      }
      if (isNaN(expectedPrice) || expectedPrice <= 0) {
        errors.push(`Row ${rowNum}: Price must be a positive number`);
        continue;
      }

      const propertyCode =
        row.propertyCode?.trim() ||
        row.propertyId?.trim() ||
        `PROP-${Date.now().toString(36).toUpperCase()}-${i + 1}`;

      const bedrooms = parseInt(row.bedrooms || '0', 10);
      const bathrooms = parseInt(row.bathrooms || '0', 10);
      const balconies = parseInt(row.balconies || '1', 10);
      const floor = parseInt(row.floor || row.floors || '1', 10);
      const totalFloors = parseInt(row.totalFloors || '10', 10);
      const propertyAge = parseInt(row.propertyAge || '0', 10);
      const parking = row.parking && (row.parking.toLowerCase() === 'yes' || row.parking === '1') ? 'Yes' : 'No';
      const furnishing = row.furnishing ? row.furnishing.trim() : 'Semi-Furnished';
      const title = row.title || `${bedrooms > 0 ? `${bedrooms} BHK ` : ''}${pType} in ${locText}`;
      const address = row.address || `${locText}, ${city}`;

      validRows.push({
        propertyCode: propertyCode.toUpperCase(),
        title,
        description: row.description || 'Verified commercial property listing with full specifications.',
        city,
        locality: locText,
        address,
        propertyType: pType,
        listingType: 'SALE',
        areaSqFt,
        bedrooms: isNaN(bedrooms) ? 0 : bedrooms,
        bathrooms: isNaN(bathrooms) ? 0 : bathrooms,
        balconies: isNaN(balconies) ? 0 : balconies,
        floor: isNaN(floor) ? 1 : floor,
        totalFloors: isNaN(totalFloors) ? 1 : totalFloors,
        propertyAge: isNaN(propertyAge) ? 0 : propertyAge,
        parking,
        furnishing,
        constructionStatus: 'Ready to Move',
        expectedPrice,
        status: 'ACTIVE',
      });
    }

    if (validRows.length === 0) {
      return NextResponse.json(
        {
          error: 'No valid property records found in CSV file',
          validationErrors: errors,
        },
        { status: 400 }
      );
    }

    let inserted = 0;
    let updated = 0;

    for (const item of validRows) {
      // Find or create location
      let location = await prisma.location.findFirst({
        where: {
          OR: [
            { locality: item.locality },
            { city: item.city },
          ],
        },
      });

      if (!location) {
        location = await prisma.location.create({
          data: {
            city: item.city,
            area: item.locality,
            locality: item.locality,
            state: 'Maharashtra',
            avgPricePerSqFt: Math.round(item.expectedPrice / item.areaSqFt),
            marketTier: 'Tier 1',
            isActive: true,
          },
        });
      }

      const existing = await prisma.property.findUnique({
        where: { propertyCode: item.propertyCode },
      });

      const propertyData = {
        propertyCode: item.propertyCode,
        title: item.title,
        description: item.description,
        propertyType: item.propertyType,
        listingType: item.listingType,
        locationId: location.id,
        address: item.address,
        areaSqFt: item.areaSqFt,
        bedrooms: item.bedrooms,
        bathrooms: item.bathrooms,
        balconies: item.balconies,
        floor: item.floor,
        totalFloors: item.totalFloors,
        propertyAge: item.propertyAge,
        parking: item.parking,
        furnishing: item.furnishing,
        constructionStatus: item.constructionStatus,
        expectedPrice: item.expectedPrice,
        status: item.status,
      };

      if (existing) {
        await prisma.property.update({
          where: { id: existing.id },
          data: propertyData,
        });
        updated++;
      } else {
        await prisma.property.create({
          data: propertyData,
        });
        inserted++;
      }
    }

    return NextResponse.json({
      success: true,
      message: `Import processed: ${inserted} records created, ${updated} records updated.`,
      stats: { inserted, updated, skipped: errors.length },
      errors: errors.slice(0, 10),
    });
  } catch (error: any) {
    console.error('Error importing CSV:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to import CSV dataset' },
      { status: 500 }
    );
  }
}

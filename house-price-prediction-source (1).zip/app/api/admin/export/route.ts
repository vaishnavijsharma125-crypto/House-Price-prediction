import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import Papa from 'papaparse';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json(
      { error: 'Unauthorized: Admin privileges required' },
      { status: 401 }
    );
  }

  try {
    const properties = await prisma.property.findMany({
      where: { isDeleted: false },
      orderBy: { id: 'asc' },
      include: { location: true },
    });

    const csvData = properties.map((p) => ({
      propertyCode: p.propertyCode,
      title: p.title,
      propertyType: p.propertyType,
      city: p.location?.city || 'Mumbai',
      locality: p.location?.locality || 'Bandra West',
      address: p.address,
      areaSqFt: p.areaSqFt,
      bedrooms: p.bedrooms,
      bathrooms: p.bathrooms,
      balconies: p.balconies,
      floor: p.floor,
      totalFloors: p.totalFloors,
      propertyAge: p.propertyAge,
      parking: p.parking,
      furnishing: p.furnishing,
      expectedPrice: p.expectedPrice,
      status: p.status,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    }));

    const csv = Papa.unparse(csvData);

    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="property_dataset_${Date.now()}.csv"`,
      },
    });
  } catch (error: any) {
    console.error('Error exporting dataset:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to export dataset' },
      { status: 500 }
    );
  }
}

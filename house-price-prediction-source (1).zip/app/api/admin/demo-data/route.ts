import { NextRequest, NextResponse } from 'next/server';
import { verifyAdminRequest } from '@/lib/auth';
import { seedDatabase } from '@/lib/seedUtil';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  const admin = verifyAdminRequest(request);
  if (!admin) {
    return NextResponse.json(
      { error: 'Unauthorized: Admin privileges required' },
      { status: 401 }
    );
  }

  try {
    const { searchParams } = new URL(request.url);
    const reset = searchParams.get('reset') === 'true';

    const result = await seedDatabase(reset);

    return NextResponse.json({
      success: true,
      message: `Demo dataset imported successfully (${result.insertedCount} records added).`,
      count: result.insertedCount,
    });
  } catch (error: any) {
    console.error('Error importing demo data:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to import demo data' },
      { status: 500 }
    );
  }
}

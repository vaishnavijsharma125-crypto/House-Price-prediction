import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import { PropertySchema } from '@/validation';
import { AuditService } from '@/services/auditService';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.max(1, Math.min(100, parseInt(searchParams.get('limit') || '12', 10)));
    const search = searchParams.get('search') || '';
    const city = searchParams.get('city') || '';
    const locality = searchParams.get('locality') || '';
    const propertyType = searchParams.get('propertyType') || '';
    const minPrice = searchParams.get('minPrice') ? parseFloat(searchParams.get('minPrice')!) : undefined;
    const maxPrice = searchParams.get('maxPrice') ? parseFloat(searchParams.get('maxPrice')!) : undefined;
    const bedrooms = searchParams.get('bedrooms') ? parseInt(searchParams.get('bedrooms')!, 10) : undefined;
    const sortBy = searchParams.get('sortBy') || 'createdAt';
    const sortOrder = searchParams.get('sortOrder') === 'asc' ? 'asc' : 'desc';

    const where: any = {
      isDeleted: false,
    };

    if (search.trim()) {
      const s = search.trim();
      where.OR = [
        { propertyCode: { contains: s } },
        { title: { contains: s } },
        { address: { contains: s } },
        { location: { city: { contains: s } } },
        { location: { locality: { contains: s } } },
      ];
    }

    if (city && city !== 'All') {
      where.location = { ...where.location, city };
    }

    if (locality && locality !== 'All') {
      where.location = { ...where.location, locality };
    }

    if (propertyType && propertyType !== 'All') {
      where.propertyType = propertyType;
    }

    if (bedrooms !== undefined && bedrooms > 0) {
      where.bedrooms = bedrooms;
    }

    if (minPrice !== undefined || maxPrice !== undefined) {
      where.expectedPrice = {};
      if (minPrice !== undefined) where.expectedPrice.gte = minPrice;
      if (maxPrice !== undefined) where.expectedPrice.lte = maxPrice;
    }

    const validSortFields = ['expectedPrice', 'areaSqFt', 'propertyAge', 'createdAt'];
    const orderByField = validSortFields.includes(sortBy) ? sortBy : 'createdAt';

    const total = await prisma.property.count({ where });
    const properties = await prisma.property.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { [orderByField]: sortOrder },
      include: {
        location: true,
        images: true,
      },
    });

    const distinctLocations = await prisma.location.findMany({
      where: { isActive: true },
      select: { city: true, locality: true, id: true },
      orderBy: { city: 'asc' },
    });

    // Format response properties for clean client consumption
    const formatted = properties.map((p) => ({
      ...p,
      price: p.expectedPrice,
      area: p.areaSqFt,
      location: p.location ? `${p.location.locality}, ${p.location.city}` : 'Metro',
    }));

    return NextResponse.json({
      properties: formatted,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      filters: {
        cities: Array.from(new Set(distinctLocations.map((l) => l.city))),
        localities: distinctLocations.map((l) => ({ id: l.id, city: l.city, locality: l.locality })),
        propertyTypes: ['Apartment', 'Villa/House', 'Plot/Land', 'Commercial', 'Penthouse'],
      },
    });
  } catch (error: any) {
    console.error('Error fetching properties:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to retrieve properties' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const admin = verifyAdminRequest(request, ['SUPER_ADMIN', 'ADMIN']);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 401 });
  }

  try {
    const body = await request.json();

    // Find or create default location if locationId was passed as city/locality string
    let locationId = body.locationId ? parseInt(String(body.locationId), 10) : 0;

    if (!locationId || isNaN(locationId)) {
      const cityName = body.city || body.location || 'Mumbai';
      const localityName = body.locality || 'Bandra West';
      const existingLoc = await prisma.location.findFirst({
        where: {
          OR: [{ locality: localityName }, { city: cityName }],
        },
      });
      locationId = existingLoc ? existingLoc.id : 1;
    }

    const payloadToValidate = {
      title: body.title || `${body.bedrooms || 2} BHK ${body.propertyType || 'Apartment'} in ${body.location || 'Metro'}`,
      description: body.description || 'Premium commercial real-estate listing with verified specifications.',
      propertyType: body.propertyType === 'House' ? 'Villa/House' : body.propertyType || 'Apartment',
      listingType: body.listingType || 'SALE',
      locationId,
      address: body.address || `${body.location || 'Central'}, City`,
      areaSqFt: parseFloat(String(body.areaSqFt || body.area || 1000)),
      bedrooms: parseInt(String(body.bedrooms ?? 0), 10),
      bathrooms: parseInt(String(body.bathrooms ?? 0), 10),
      balconies: parseInt(String(body.balconies ?? 0), 10),
      floor: parseInt(String(body.floor ?? 0), 10),
      totalFloors: parseInt(String(body.totalFloors ?? body.floors ?? 1), 10),
      propertyAge: parseInt(String(body.propertyAge ?? 0), 10),
      parking: body.parking === true || body.parking === 'Yes' || body.parking === 'yes' ? 'Yes' : 'No',
      furnishing: body.furnishing || 'Semi-Furnished',
      constructionStatus: body.constructionStatus || 'Ready to Move',
      amenities: Array.isArray(body.amenities) ? body.amenities : [],
      expectedPrice: parseFloat(String(body.expectedPrice || body.price || 10000000)),
      status: body.status || 'ACTIVE',
      isFeatured: body.isFeatured === true,
    };

    const validated = PropertySchema.safeParse(payloadToValidate);
    if (!validated.success) {
      return NextResponse.json(
        { error: 'Validation error', details: validated.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const code =
      body.propertyCode && body.propertyCode.trim()
        ? body.propertyCode.trim().toUpperCase()
        : `PROP-${Date.now().toString(36).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

    const createdProperty = await prisma.property.create({
      data: {
        propertyCode: code,
        ...validated.data,
        amenities: JSON.stringify(validated.data.amenities),
      },
      include: { location: true },
    });

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'PROPERTY_CREATE',
      entity: 'Property',
      entityId: createdProperty.id,
      metadata: { code: createdProperty.propertyCode, price: createdProperty.expectedPrice },
    });

    return NextResponse.json(
      {
        message: 'Property created successfully',
        property: {
          ...createdProperty,
          propertyId: createdProperty.propertyCode,
          price: createdProperty.expectedPrice,
          area: createdProperty.areaSqFt,
          location: createdProperty.location?.locality || 'Metro',
        },
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error('Error creating property:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to create property' },
      { status: 500 }
    );
  }
}

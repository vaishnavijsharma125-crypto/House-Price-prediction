import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import { AuditService } from '@/services/auditService';

export const dynamic = 'force-dynamic';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const idParam = params.id;
    const numericId = parseInt(idParam, 10);

    const property = isNaN(numericId)
      ? await prisma.property.findUnique({
          where: { propertyCode: idParam },
          include: { location: true, images: true },
        })
      : await prisma.property.findFirst({
          where: {
            OR: [{ id: numericId }, { propertyCode: idParam }],
            isDeleted: false,
          },
          include: { location: true, images: true },
        });

    if (!property) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 });
    }

    let parsedAmenities = [];
    try {
      parsedAmenities = JSON.parse(property.amenities || '[]');
    } catch {}

    return NextResponse.json({
      property: {
        ...property,
        amenities: parsedAmenities,
        price: property.expectedPrice,
        area: property.areaSqFt,
        location: property.location ? `${property.location.locality}, ${property.location.city}` : 'Metro',
      },
    });
  } catch (error: any) {
    console.error('Error fetching property:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to retrieve property' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const admin = verifyAdminRequest(request, ['SUPER_ADMIN', 'ADMIN']);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 401 });
  }

  try {
    const idParam = params.id;
    const numericId = parseInt(idParam, 10);

    const existing = isNaN(numericId)
      ? await prisma.property.findUnique({ where: { propertyCode: idParam } })
      : await prisma.property.findFirst({
          where: { OR: [{ id: numericId }, { propertyCode: idParam }] },
        });

    if (!existing) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 });
    }

    const body = await request.json();

    const updated = await prisma.property.update({
      where: { id: existing.id },
      data: {
        title: body.title || undefined,
        description: body.description || undefined,
        propertyType: body.propertyType ? (body.propertyType === 'House' ? 'Villa/House' : body.propertyType) : undefined,
        listingType: body.listingType || undefined,
        address: body.address || undefined,
        areaSqFt: body.areaSqFt !== undefined ? parseFloat(String(body.areaSqFt)) : body.area !== undefined ? parseFloat(String(body.area)) : undefined,
        bedrooms: body.bedrooms !== undefined ? parseInt(String(body.bedrooms), 10) : undefined,
        bathrooms: body.bathrooms !== undefined ? parseInt(String(body.bathrooms), 10) : undefined,
        balconies: body.balconies !== undefined ? parseInt(String(body.balconies), 10) : undefined,
        floor: body.floor !== undefined ? parseInt(String(body.floor), 10) : undefined,
        totalFloors: body.totalFloors !== undefined ? parseInt(String(body.totalFloors), 10) : body.floors !== undefined ? parseInt(String(body.floors), 10) : undefined,
        propertyAge: body.propertyAge !== undefined ? parseInt(String(body.propertyAge), 10) : undefined,
        parking: body.parking !== undefined ? (body.parking === true || body.parking === 'Yes' || body.parking === 'yes' ? 'Yes' : 'No') : undefined,
        furnishing: body.furnishing || undefined,
        constructionStatus: body.constructionStatus || undefined,
        expectedPrice: body.expectedPrice !== undefined ? parseFloat(String(body.expectedPrice)) : body.price !== undefined ? parseFloat(String(body.price)) : undefined,
        status: body.status || undefined,
        isFeatured: body.isFeatured !== undefined ? body.isFeatured : undefined,
      },
      include: { location: true },
    });

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'PROPERTY_UPDATE',
      entity: 'Property',
      entityId: existing.id,
      metadata: { code: existing.propertyCode, updatedFields: Object.keys(body) },
    });

    return NextResponse.json({
      message: 'Property updated successfully',
      property: {
        ...updated,
        propertyId: updated.propertyCode,
        price: updated.expectedPrice,
        area: updated.areaSqFt,
        location: updated.location?.locality || 'Metro',
      },
    });
  } catch (error: any) {
    console.error('Error updating property:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to update property' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const admin = verifyAdminRequest(request, ['SUPER_ADMIN', 'ADMIN']);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 401 });
  }

  try {
    const idParam = params.id;
    const numericId = parseInt(idParam, 10);

    const existing = isNaN(numericId)
      ? await prisma.property.findUnique({ where: { propertyCode: idParam } })
      : await prisma.property.findFirst({
          where: { OR: [{ id: numericId }, { propertyCode: idParam }] },
        });

    if (!existing) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 });
    }

    // Soft delete property to preserve transaction relationships
    await prisma.property.update({
      where: { id: existing.id },
      data: { isDeleted: true, status: 'INACTIVE' },
    });

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'PROPERTY_DELETE',
      entity: 'Property',
      entityId: existing.id,
      metadata: { code: existing.propertyCode },
    });

    return NextResponse.json({
      message: `Property ${existing.propertyCode} deleted successfully`,
      deletedId: existing.id,
      propertyId: existing.propertyCode,
    });
  } catch (error: any) {
    console.error('Error deleting property:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to delete property' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyAdminRequest } from '@/lib/auth';
import { AuditService } from '@/services/auditService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    let settings = await prisma.websiteSetting.findUnique({
      where: { id: 'default' },
    });

    if (!settings) {
      settings = await prisma.websiteSetting.create({
        data: {
          id: 'default',
          brandName: 'PropVal Analytics',
          heroTitle: 'Enterprise Real Estate Valuation & Market Analytics',
          heroSubtitle: 'Institutional-grade property pricing intelligence combining empirical transactions, hedonic calibration, and locality benchmarks.',
          aboutText: 'PropVal Analytics delivers commercial-grade property valuation and real estate data intelligence for buyers, sellers, brokers, and institutional investors.',
          contactEmail: 'contact@propvalanalytics.com',
          contactPhone: '+91 98765 43210',
          contactAddress: 'Tech Hub Tower, Level 8, Sector 5, Bangalore 560100',
          disclaimerText: 'This valuation estimate is generated from available transaction records and statistical regression heuristics. It does not constitute a formal chartered surveyor legal appraisal.',
        },
      });
    }

    return NextResponse.json({ settings });
  } catch (error: any) {
    console.error('Error fetching settings:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to fetch settings' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  const admin = verifyAdminRequest(request, ['SUPER_ADMIN', 'ADMIN']);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const {
      brandName,
      heroTitle,
      heroSubtitle,
      aboutText,
      contactEmail,
      contactPhone,
      contactAddress,
      disclaimerText,
      activeTheme,
    } = body;

    const updated = await prisma.websiteSetting.upsert({
      where: { id: 'default' },
      update: {
        brandName: brandName || undefined,
        heroTitle: heroTitle || undefined,
        heroSubtitle: heroSubtitle || undefined,
        aboutText: aboutText || undefined,
        contactEmail: contactEmail || undefined,
        contactPhone: contactPhone || undefined,
        contactAddress: contactAddress || undefined,
        disclaimerText: disclaimerText || undefined,
        activeTheme: activeTheme || undefined,
      },
      create: {
        id: 'default',
        brandName: brandName || 'PropVal Analytics',
        heroTitle: heroTitle || 'Enterprise Real Estate Valuation & Market Analytics',
        heroSubtitle: heroSubtitle || '',
        aboutText: aboutText || '',
        contactEmail: contactEmail || 'contact@propvalanalytics.com',
        contactPhone: contactPhone || '+91 98765 43210',
        contactAddress: contactAddress || '',
        disclaimerText: disclaimerText || '',
        activeTheme: activeTheme || 'obsidian-gold',
      },
    });

    await AuditService.log({
      userId: admin.userId,
      userEmail: admin.email,
      action: 'SETTINGS_UPDATE',
      entity: 'WebsiteSetting',
      metadata: { brandName, heroTitle },
    });

    return NextResponse.json({
      success: true,
      message: 'Website settings updated successfully',
      settings: updated,
    });
  } catch (error: any) {
    console.error('Error updating settings:', error);
    return NextResponse.json(
      { error: error?.message || 'Failed to update settings' },
      { status: 500 }
    );
  }
}

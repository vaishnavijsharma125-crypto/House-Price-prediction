'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Building2,
  Calculator,
  Database,
  BarChart3,
  BookOpen,
  Info,
  Mail,
  Menu,
  X,
  TrendingUp,
  Sparkles,
} from 'lucide-react';

import ThemeSwitcher from './ThemeSwitcher';

const NAV_LINKS = [
  { name: 'Home', href: '/', icon: Building2 },
  { name: 'Prediction', href: '/predict', icon: Calculator },
  { name: 'Explore Dataset', href: '/explore', icon: Database },
  { name: 'Data Analysis', href: '/analytics', icon: BarChart3 },
  { name: 'Methodology', href: '/methodology', icon: BookOpen },
  { name: 'About Platform', href: '/about', icon: Info },
  { name: 'Contact', href: '/contact', icon: Mail },
];

export default function Navbar() {
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-slate-950/85 backdrop-blur-xl border-b border-slate-800/80 shadow-2xl shadow-black/60 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-17">
          {/* Logo & Brand */}
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-yellow-600 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/25 group-hover:shadow-amber-500/50 group-hover:scale-105 transition-all border border-amber-400/40 font-black">
              <TrendingUp className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="font-extrabold text-white leading-tight tracking-tight flex items-center gap-2">
                <span className="group-hover:text-amber-300 transition-colors">PROPVAL</span>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-400/30 shadow-xs">
                  ANALYTICS
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Valuation & Market Intelligence</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {NAV_LINKS.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                    isActive
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-sm shadow-amber-500/20'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60 hover:border-slate-700/60 border border-transparent'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-400 group-hover:text-slate-200'}`} />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>

          {/* Action CTA Button & Theme Switcher */}
          <div className="hidden lg:flex items-center space-x-2.5">
            <ThemeSwitcher />
            <Link
              href="/predict"
              className="btn-shady-primary px-4 py-2 text-xs uppercase tracking-wider gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-slate-950" />
              <span>Estimate Value</span>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center space-x-2">
            <ThemeSwitcher />
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800 focus:outline-none"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-800 bg-slate-950/95 backdrop-blur-2xl px-4 pt-3 pb-5 space-y-1 shadow-2xl">
          {NAV_LINKS.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center space-x-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                  isActive
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold'
                    : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                <span>{item.name}</span>
              </Link>
            );
          })}
          <div className="pt-3 border-t border-slate-800/80">
            <Link
              href="/predict"
              onClick={() => setMobileMenuOpen(false)}
              className="btn-shady-primary w-full py-3 text-xs uppercase tracking-wider gap-2 shadow-lg"
            >
              <Calculator className="w-4 h-4 text-slate-950" />
              <span>Estimate Value</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

import React from 'react';
import Link from 'next/link';
import { Building2, ShieldAlert, Cpu, ArrowUpRight, TrendingUp } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="mt-auto bg-slate-950 text-slate-400 border-t border-slate-800/80 text-sm relative overflow-hidden">
      {/* Subtle Ambient Industrial Light at Footer Top */}
      <div className="absolute top-0 left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-sky-400/40 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Col 1: Platform Info */}
          <div className="space-y-4 md:col-span-2">
            <div className="flex items-center space-x-3 text-white font-extrabold text-lg">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-sky-500/30">
                <TrendingUp className="w-4 h-4" />
              </div>
              <span className="tracking-tight">HOUSE & LAND PRICE PREDICTION ANALYSIS</span>
            </div>
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-md">
              Institutional-grade property pricing intelligence combining empirical registry transactions, hedonic econometric calibration, and live locality benchmarks across prime Indian real estate corridors.
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-sky-500/20 text-sky-300 text-xs shadow-md">
              <ShieldAlert className="w-4 h-4 text-sky-400 shrink-0" />
              <span>MARKET VALUATION NOTICE: Deterministic econometric modeling benchmarked against verified transactions.</span>
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div>
            <h4 className="text-white font-bold mb-4 text-xs uppercase tracking-widest flex items-center gap-1.5 text-sky-400">
              <span>Platform Terminal</span>
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <Link href="/" className="hover:text-sky-300 hover:translate-x-1 transition-all inline-block">
                  Market Home
                </Link>
              </li>
              <li>
                <Link href="/predict" className="hover:text-sky-300 hover:translate-x-1 transition-all inline-block">
                  Valuation Engine
                </Link>
              </li>
              <li>
                <Link href="/explore" className="hover:text-sky-300 hover:translate-x-1 transition-all inline-block">
                  Explore Dataset
                </Link>
              </li>
              <li>
                <Link href="/analytics" className="hover:text-sky-300 hover:translate-x-1 transition-all inline-block">
                  Market Analytics
                </Link>
              </li>
              <li>
                <Link href="/methodology" className="hover:text-sky-300 hover:translate-x-1 transition-all inline-block">
                  Methodology & Science
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Company & Information */}
          <div>
            <h4 className="text-white font-bold mb-4 text-xs uppercase tracking-widest flex items-center gap-1.5 text-sky-400">
              <span>Corporate Info</span>
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <Link href="/about" className="hover:text-sky-300 hover:translate-x-1 transition-all inline-block">
                  About Platform
                </Link>
              </li>
              <li>
                <Link href="/methodology" className="hover:text-sky-300 hover:translate-x-1 transition-all inline-block">
                  Hedonic Regression Pipeline
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-sky-300 hover:translate-x-1 transition-all inline-block">
                  Institutional Inquiries
                </Link>
              </li>
              <li className="pt-2 text-[11px] text-slate-500 font-mono">
                Architecture: Next.js 14 • React • TypeScript • Prisma • PostgreSQL / SQLite • Tailwind
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} House & Land Price Prediction Analysis. Commercial Enterprise Intelligence.
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 radar-dot"></span>
            <span className="text-slate-400 font-medium">Real-Time Database Synchronization Active</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

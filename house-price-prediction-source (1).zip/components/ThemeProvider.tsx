'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export interface ThemeOption {
  id: string;
  name: string;
  subtitle: string;
  badge: string;
  primaryColor: string;
  secondaryColor: string;
  bgGradient: string;
  previewClass: string;
}

export const THEMES: ThemeOption[] = [
  {
    id: 'obsidian-gold',
    name: 'Obsidian & Luxe Gold',
    subtitle: 'Industrial dark obsidian with champagne gold & warm bronze accents',
    badge: 'Recommended • Luxury Real Estate',
    primaryColor: '#f59e0b',
    secondaryColor: '#d97706',
    bgGradient: 'from-amber-500 via-amber-400 to-yellow-500',
    previewClass: 'border-amber-400 bg-amber-500/15 text-amber-300',
  },
  {
    id: 'cyber-emerald',
    name: 'Cyber Emerald & Carbon',
    subtitle: 'Deep carbon slate with vibrant neon emerald & matrix green',
    badge: 'Eco Corridors & Smart Cities',
    primaryColor: '#10b981',
    secondaryColor: '#059669',
    bgGradient: 'from-emerald-500 via-teal-500 to-emerald-600',
    previewClass: 'border-emerald-400 bg-emerald-500/15 text-emerald-300',
  },
  {
    id: 'crimson-titanium',
    name: 'Midnight Titanium & Ruby',
    subtitle: 'Charcoal titanium with rich crimson ruby & rose red accents',
    badge: 'High-Velocity Commercial Hubs',
    primaryColor: '#f43f5e',
    secondaryColor: '#e11d48',
    bgGradient: 'from-rose-500 via-red-600 to-pink-600',
    previewClass: 'border-rose-400 bg-rose-500/15 text-rose-300',
  },
  {
    id: 'neon-violet',
    name: 'Neon Ultraviolet & Cosmos',
    subtitle: 'Deep cosmos dark slate with electric purple & neon ultraviolet',
    badge: 'Futuristic PropTech AI',
    primaryColor: '#8b5cf6',
    secondaryColor: '#7c3aed',
    bgGradient: 'from-purple-500 via-violet-600 to-indigo-600',
    previewClass: 'border-purple-400 bg-purple-500/15 text-purple-300',
  },
  {
    id: 'platinum-steel',
    name: 'Architectural Steel & Ice Cyan',
    subtitle: 'Industrial cold dark steel with ice cyan & brushed platinum highlights',
    badge: 'Precision CAD Architecture',
    primaryColor: '#38bdf8',
    secondaryColor: '#0284c7',
    bgGradient: 'from-cyan-400 via-sky-500 to-blue-600',
    previewClass: 'border-cyan-400 bg-cyan-500/15 text-cyan-300',
  },
];

interface ThemeContextType {
  theme: string;
  setTheme: (themeId: string) => void;
  themes: ThemeOption[];
  currentThemeConfig: ThemeOption;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: 'obsidian-gold',
  setTheme: () => {},
  themes: THEMES,
  currentThemeConfig: THEMES[0],
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<string>('obsidian-gold');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // 1. Check localStorage first
    const saved = localStorage.getItem('propval_theme');
    if (saved && THEMES.some((t) => t.id === saved)) {
      setThemeState(saved);
      document.documentElement.setAttribute('data-theme', saved);
      return;
    }

    // 2. Fetch activeTheme from backend settings
    fetch('/api/settings')
      .then((res) => res.json())
      .then((data) => {
        if (data.settings?.activeTheme && THEMES.some((t) => t.id === data.settings.activeTheme)) {
          const t = data.settings.activeTheme;
          setThemeState(t);
          document.documentElement.setAttribute('data-theme', t);
          localStorage.setItem('propval_theme', t);
        } else {
          document.documentElement.setAttribute('data-theme', 'obsidian-gold');
        }
      })
      .catch(() => {
        document.documentElement.setAttribute('data-theme', 'obsidian-gold');
      });
  }, []);

  const setTheme = (themeId: string) => {
    if (!THEMES.some((t) => t.id === themeId)) return;
    setThemeState(themeId);
    localStorage.setItem('propval_theme', themeId);
    document.documentElement.setAttribute('data-theme', themeId);
  };

  const currentThemeConfig = THEMES.find((t) => t.id === theme) || THEMES[0];

  return (
    <ThemeContext.Provider value={{ theme, setTheme, themes: THEMES, currentThemeConfig }}>
      <div data-theme={theme} className="contents">
        {children}
      </div>
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}

'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Search,
  Building2,
  Home,
  Briefcase,
  MapPin,
  Sparkles,
  ArrowRight,
  ChevronDown,
} from 'lucide-react';

interface HeroSearchBarProps {
  locations?: { city: string; locality: string }[];
}

export default function HeroSearchBar({ locations = [] }: HeroSearchBarProps) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<'BUY' | 'RENT' | 'COMMERCIAL' | 'PLOTS' | 'VALUATION'>('BUY');
  const [selectedCity, setSelectedCity] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [budget, setBudget] = useState('All');

  const popularCities = ['Mumbai', 'Bangalore', 'Delhi', 'Pune', 'Hyderabad', 'Chennai', 'Kolkata', 'Ahmedabad'];

  const popularSearches = [
    { label: 'Bandra West', city: 'Mumbai' },
    { label: 'Indiranagar', city: 'Bangalore' },
    { label: 'DLF Phase 5', city: 'Delhi' },
    { label: 'Whitefield', city: 'Bangalore' },
    { label: 'Gachibowli', city: 'Hyderabad' },
    { label: 'Koregaon Park', city: 'Pune' },
    { label: 'Worli', city: 'Mumbai' },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();

    if (activeTab === 'VALUATION') {
      const params = new URLSearchParams();
      if (selectedCity && selectedCity !== 'All') params.set('location', selectedCity);
      router.push(`/predict?${params.toString()}`);
      return;
    }

    const params = new URLSearchParams();
    if (selectedCity && selectedCity !== 'All') params.set('location', selectedCity);
    if (searchQuery.trim()) params.set('search', searchQuery.trim());

    if (activeTab === 'COMMERCIAL') {
      params.set('propertyType', 'Commercial');
    } else if (activeTab === 'PLOTS') {
      params.set('propertyType', 'Plot/Land');
    }

    if (budget === 'under50') {
      params.set('maxPrice', '5000000');
    } else if (budget === '50to1cr') {
      params.set('minPrice', '5000000');
      params.set('maxPrice', '10000000');
    } else if (budget === '1to3cr') {
      params.set('minPrice', '10000000');
      params.set('maxPrice', '30000000');
    } else if (budget === 'above3cr') {
      params.set('minPrice', '30000000');
    }

    router.push(`/explore?${params.toString()}`);
  };

  const handleQuickTagClick = (tag: { label: string; city: string }) => {
    router.push(`/explore?location=${encodeURIComponent(tag.city)}&search=${encodeURIComponent(tag.label)}`);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* 99acres-Style Tabbed Header with Shady Industrial Glass */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-3 p-1.5 bg-slate-950/80 backdrop-blur-xl rounded-2xl w-fit mx-auto border border-slate-800 shadow-2xl shadow-black/60">
        <button
          type="button"
          onClick={() => setActiveTab('BUY')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold tracking-wide transition-all ${
            activeTab === 'BUY'
              ? 'btn-shady-primary'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/80'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Buy</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('RENT')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold tracking-wide transition-all ${
            activeTab === 'RENT'
              ? 'btn-shady-primary'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/80'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Rent</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('COMMERCIAL')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold tracking-wide transition-all ${
            activeTab === 'COMMERCIAL'
              ? 'btn-shady-primary'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/80'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span>Commercial</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('PLOTS')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold tracking-wide transition-all ${
            activeTab === 'PLOTS'
              ? 'btn-shady-primary'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/80'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Plots / Land</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('VALUATION')}
          className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold tracking-wide transition-all ${
            activeTab === 'VALUATION'
              ? 'btn-shady-amber'
              : 'text-amber-400 hover:text-amber-300 hover:bg-amber-500/10'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Instant Valuation</span>
          <span className="ml-1 text-[9px] bg-slate-950/40 border border-current px-1.5 py-0.5 rounded-full uppercase tracking-wider font-black">
            AI Engine
          </span>
        </button>
      </div>

      {/* Main Industrial Glass Search Panel */}
      <div className="relative rounded-3xl p-4 sm:p-5 bg-slate-900/90 backdrop-blur-2xl border border-slate-700/80 shadow-2xl shadow-black/80">
        {/* Subtle Ambient Top Border Highlight */}
        <div className="absolute top-0 left-10 right-10 h-px bg-gradient-to-r from-transparent via-sky-400/50 to-transparent pointer-events-none" />

        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          {/* City Selector */}
          <div className="md:col-span-3">
            <label className="block text-[11px] font-bold text-sky-400/80 uppercase tracking-widest px-1 mb-1.5">
              City / Metro
            </label>
            <div className="relative group">
              <MapPin className="w-4 h-4 text-sky-400 absolute left-3.5 top-3.5 group-hover:scale-110 transition-transform" />
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full pl-10 pr-8 py-3 bg-slate-950/70 hover:bg-slate-950 rounded-xl text-sm font-semibold text-slate-100 border border-slate-700/80 focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20 cursor-pointer transition-all outline-none"
              >
                <option value="All" className="bg-slate-900 text-white">All Metropolitan Hubs</option>
                {popularCities.map((city) => (
                  <option key={city} value={city} className="bg-slate-900 text-white">
                    {city}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Search Query / Locality */}
          <div className="md:col-span-5">
            <label className="block text-[11px] font-bold text-sky-400/80 uppercase tracking-widest px-1 mb-1.5">
              Locality, Project or Landmark
            </label>
            <div className="relative group">
              <Search className="w-4 h-4 text-sky-400 absolute left-3.5 top-3.5 group-hover:scale-110 transition-transform" />
              <input
                type="text"
                placeholder={
                  activeTab === 'VALUATION'
                    ? 'Enter locality (e.g. Bandra West, Indiranagar)...'
                    : 'Search society, builder, BHK or landmark...'
                }
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-950/70 hover:bg-slate-950 rounded-xl text-sm text-slate-100 placeholder-slate-500 border border-slate-700/80 focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20 transition-all outline-none"
              />
            </div>
          </div>

          {/* Budget Range / Model Selection */}
          <div className="md:col-span-2">
            <label className="block text-[11px] font-bold text-sky-400/80 uppercase tracking-widest px-1 mb-1.5">
              {activeTab === 'VALUATION' ? 'Hedonic Model' : 'Budget'}
            </label>
            {activeTab === 'VALUATION' ? (
              <div className="py-3 px-3 rounded-xl bg-amber-500/10 border border-amber-400/30 text-xs font-bold text-amber-300 flex items-center justify-between">
                <span>Hedonic v1.2</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              </div>
            ) : (
              <select
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full px-3 py-3 bg-slate-950/70 hover:bg-slate-950 rounded-xl text-sm font-semibold text-slate-100 border border-slate-700/80 focus:border-sky-400 focus:ring-4 focus:ring-sky-500/20 cursor-pointer transition-all outline-none"
              >
                <option value="All" className="bg-slate-900 text-white">Any Budget</option>
                <option value="under50" className="bg-slate-900 text-white">Under ₹50 Lakh</option>
                <option value="50to1cr" className="bg-slate-900 text-white">₹50 L - ₹1.0 Cr</option>
                <option value="1to3cr" className="bg-slate-900 text-white">₹1.0 Cr - ₹3.0 Cr</option>
                <option value="above3cr" className="bg-slate-900 text-white">₹3.0 Cr & Above</option>
              </select>
            )}
          </div>

          {/* Shady Action Button */}
          <div className="md:col-span-2">
            <label className="hidden md:block text-[11px] font-bold text-transparent px-1 mb-1.5">
              Action
            </label>
            <button
              type="submit"
              className={
                activeTab === 'VALUATION'
                  ? 'btn-shady-amber w-full py-3.5 px-4 text-sm gap-2'
                  : 'btn-shady-primary w-full py-3.5 px-4 text-sm gap-2'
              }
            >
              <span>{activeTab === 'VALUATION' ? 'Value Property' : 'Search'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>

        {/* Popular Searches Pill Row */}
        <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex flex-wrap items-center gap-1.5 text-xs text-slate-400">
          <span className="font-bold text-sky-400/80 mr-1 text-[11px] uppercase tracking-wider">Trending:</span>
          {popularSearches.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => handleQuickTagClick(item)}
              className="px-3 py-1 rounded-lg bg-slate-950/60 hover:bg-sky-500/15 text-slate-300 hover:text-sky-300 text-[11px] font-medium border border-slate-800 hover:border-sky-500/40 transition-all shadow-xs"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Palette, Check, ChevronDown } from 'lucide-react';
import { useTheme, THEMES } from './ThemeProvider';

export default function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const activeTheme = THEMES.find((t) => t.id === theme) || THEMES[0];

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 text-xs font-semibold shadow-md transition-all"
        title="Change Platform Visual Theme"
      >
        <span
          className="w-2.5 h-2.5 rounded-full shadow-xs shrink-0"
          style={{ backgroundColor: activeTheme.primaryColor }}
        />
        <Palette className="w-3.5 h-3.5 text-slate-400" />
        <span className="hidden sm:inline-block">{activeTheme.name.split('&')[0].trim()}</span>
        <ChevronDown className="w-3 h-3 text-slate-400" />
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-slate-950/95 backdrop-blur-2xl border border-slate-800 shadow-2xl shadow-black z-50 p-2 space-y-1 animate-in fade-in duration-150">
          <div className="px-3 py-2 border-b border-slate-800/80 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 block">
              Active Visual Theme (5 Styles)
            </span>
            <span className="text-xs text-slate-300 font-medium">
              Select your preferred color profile
            </span>
          </div>

          {THEMES.map((t) => {
            const isSelected = t.id === theme;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  setTheme(t.id);
                  setOpen(false);
                }}
                className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center justify-between gap-3 text-xs ${
                  isSelected
                    ? 'bg-slate-900 border border-slate-700/80 font-bold text-white shadow-sm'
                    : 'text-slate-300 hover:bg-slate-900/60 hover:text-white border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="w-4 h-4 rounded-full border border-white/20 shrink-0 shadow-sm"
                    style={{ backgroundColor: t.primaryColor }}
                  />
                  <div className="min-w-0">
                    <div className="truncate text-xs font-bold">{t.name}</div>
                    <div className="text-[10px] text-slate-500 truncate">{t.badge.split('•')[0].trim()}</div>
                  </div>
                </div>

                {isSelected && (
                  <Check
                    className="w-4 h-4 shrink-0"
                    style={{ color: t.primaryColor }}
                  />
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

'use client';

import React from 'react';
import Link from 'next/link';
import {
  MapPin,
  Bed,
  Bath,
  Maximize2,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  Camera,
} from 'lucide-react';
import { formatCompactCurrency, formatNumber, getPropertyImageUrl } from '@/lib/utils';

interface PropertyCardProps {
  property: any;
  onView?: (prop: any) => void;
}

export default function PropertyCard({ property, onView }: PropertyCardProps) {
  const price = property.expectedPrice ?? property.price ?? 0;
  const area = property.areaSqFt ?? property.area ?? 1;
  const pricePerSqFt = area > 0 ? Math.round(price / area) : 0;
  const code = property.propertyCode ?? property.propertyId ?? `PROP-${property.id}`;
  
  const locality = property.location?.locality || (typeof property.location === 'string' ? property.location : 'Metro Prime');
  const city = property.location?.city || '';
  const fullLoc = city ? `${locality}, ${city}` : locality;
  
  const imageUrl = getPropertyImageUrl(property);
  const imageCount = property.images && property.images.length > 0 ? property.images.length : 2;

  let amenitiesList: string[] = [];
  try {
    if (typeof property.amenities === 'string') {
      amenitiesList = JSON.parse(property.amenities);
    } else if (Array.isArray(property.amenities)) {
      amenitiesList = property.amenities;
    }
  } catch {
    amenitiesList = [];
  }

  return (
    <div className="group relative bg-slate-900/90 rounded-3xl border border-slate-800/90 shadow-2xl shadow-black/80 hover:border-sky-500/50 hover:shadow-sky-500/20 transition-all duration-500 flex flex-col justify-between overflow-hidden backdrop-blur-xl">
      {/* Ambient Top Light Line on Hover */}
      <div className="absolute top-0 left-6 right-6 h-px bg-gradient-to-r from-transparent via-sky-400/0 to-transparent group-hover:via-sky-400/60 transition-all duration-500 pointer-events-none z-20" />

      <div>
        {/* Visual Real Estate Image with Badges */}
        <div className="relative aspect-[16/10] overflow-hidden bg-slate-950">
          <img
            src={imageUrl}
            alt={property.title || 'Property listing'}
            className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700 ease-out"
            loading="lazy"
          />

          {/* Deep Cinematic Shady Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-slate-950/30 pointer-events-none" />

          {/* Top Overlaid Badges */}
          <div className="absolute top-3.5 left-3.5 flex flex-wrap items-center gap-1.5 z-10">
            <span className="inline-flex items-center px-2.5 py-1 rounded-lg bg-emerald-950/85 backdrop-blur-md border border-emerald-500/40 text-emerald-300 text-[11px] font-bold uppercase tracking-wider shadow-lg">
              <span className="w-2 h-2 rounded-full bg-emerald-400 radar-dot mr-1.5"></span>
              <span>RERA Verified</span>
            </span>

            {property.isFeatured && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/90 backdrop-blur-md text-slate-950 text-[11px] font-black uppercase tracking-wider shadow-lg">
                <Sparkles className="w-3 h-3 text-slate-950 fill-current" />
                <span>Featured</span>
              </span>
            )}
          </div>

          {/* Top Right: Image Count */}
          <div className="absolute top-3.5 right-3.5 z-10">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-950/80 backdrop-blur-md border border-slate-700/60 text-slate-300 text-[11px] font-medium shadow-md">
              <Camera className="w-3 h-3 text-sky-400" />
              <span>{imageCount} Photos</span>
            </span>
          </div>

          {/* Bottom Overlay: Price on Image */}
          <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between text-white z-10">
            <div>
              <div className="text-2xl font-black tracking-tight text-white drop-shadow-md">
                {formatCompactCurrency(price)}
              </div>
              <div className="text-[11px] text-sky-300/90 font-medium">
                ₹{pricePerSqFt.toLocaleString('en-IN')} / sq.ft
              </div>
            </div>
            <span className="px-3 py-1 rounded-xl bg-sky-500/20 backdrop-blur-md border border-sky-400/30 text-sky-300 text-xs font-bold tracking-wide">
              {property.propertyType}
            </span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-3.5">
          {/* Title & Locality */}
          <div>
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-1">
              <span className="text-sky-400/90 font-semibold">{code}</span>
              <span className="text-emerald-400 font-semibold">{property.constructionStatus || 'Ready to Move'}</span>
            </div>
            <h3 className="text-base font-bold text-white line-clamp-1 group-hover:text-sky-300 transition-colors">
              {property.title || `${property.bedrooms || 2} BHK ${property.propertyType} in ${locality}`}
            </h3>
            <div className="flex items-center gap-1 text-xs text-slate-400 mt-1 font-medium">
              <MapPin className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="line-clamp-1 text-slate-300">{fullLoc}</span>
            </div>
          </div>

          {/* Key Property Specs Row with Dark Industrial Glass */}
          <div className="grid grid-cols-3 gap-2 py-2.5 px-3 bg-slate-950/70 rounded-2xl text-xs text-slate-300 border border-slate-800">
            <div className="flex items-center gap-1.5">
              <Bed className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="font-semibold text-slate-200">{property.bedrooms > 0 ? `${property.bedrooms} Beds` : 'Plot'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Bath className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="font-semibold text-slate-200">{property.bathrooms > 0 ? `${property.bathrooms} Baths` : '1 Bath'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Maximize2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="font-semibold text-slate-200">{formatNumber(area)} sqft</span>
            </div>
          </div>

          {/* Floor & Parking Info */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
            <span>
              Floor: <strong className="text-slate-200">{property.floor > 0 ? `${property.floor} of ${property.totalFloors || 10}` : 'Ground'}</strong>
            </span>
            <span>
              Parking: <strong className="text-slate-200">{property.parking || 'Yes'}</strong>
            </span>
            <span>
              Age: <strong className="text-slate-200">{property.propertyAge || 0} yrs</strong>
            </span>
          </div>

          {/* Amenities Tags */}
          {amenitiesList.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {amenitiesList.slice(0, 3).map((amenity, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-400 text-[10px] font-medium"
                >
                  {amenity}
                </span>
              ))}
              {amenitiesList.length > 3 && (
                <span className="px-1.5 py-0.5 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-500 text-[10px] font-medium">
                  +{amenitiesList.length - 3}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Card Footer Actions with Shady Animated Buttons */}
      <div className="p-5 pt-0 border-t border-slate-800/80 grid grid-cols-2 gap-2.5 mt-2">
        {onView ? (
          <button
            type="button"
            onClick={() => onView(property)}
            className="btn-shady-dark py-2.5 px-3 text-xs"
          >
            <span>View Details</span>
          </button>
        ) : (
          <Link
            href="/explore"
            className="btn-shady-dark py-2.5 px-3 text-xs"
          >
            <span>View Details</span>
          </Link>
        )}

        <Link
          href={`/predict?propertyType=${encodeURIComponent(property.propertyType)}&area=${area}&bedrooms=${property.bedrooms || 2}&bathrooms=${property.bathrooms || 2}&location=${encodeURIComponent(city || 'Mumbai')}&locality=${encodeURIComponent(locality)}`}
          className="btn-shady-primary py-2.5 px-3 text-xs gap-1.5 shadow-md shadow-sky-500/20"
        >
          <span>Fair Value</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
}
